
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class LaunchSeeTest2 {
	
	/** Author: Devi
	 * Creation Date:
	 * Purpose: This program will Launch the specified application. It will take two params 
	 * first param:path
	 * Second Param: application to launch
	 */
	
	public void applicationLaunch(String path,String program) throws IOException

	{ 
		
		Runtime runtime = Runtime.getRuntime(); 
		Scanner scanner = new Scanner(System.in);
    	String[] startcmd = new String[] {path+"\\"+program +".exe"};
    	 
    	 try{
	        Process process = runtime.exec(startcmd); 
	        if(process.isAlive())
	        	System.out.println("Process is starting.. Wait");
	        
    	 	}catch(Exception e)
    	 {
    	 		System.err.println("************The specified application or path is invalid********\n");
    	 		try {
					Thread.sleep(100);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    	 		System.out.println("Enter correct file Path: ");
    	    	path = scanner.next();;
    	    	System.out.print("Enter correct program to launch: ");
    	    	program = scanner.next();;
    	    	applicationLaunch(path,program);
    	 }
    	 
	
	}

	

	public static void main(String args[]) throws IOException
	{
		LaunchSeeTest2 l1=new LaunchSeeTest2();
		System.out.println("Please provide two parameters \n1:Path \n2:Application To launch\nExample:C:\\Progra~2\\Notepad++ notepad++");
			if(args.length==2)
			l1.applicationLaunch(args[0],args[1]);
			else
				{
					System.out.println("please provide parameters correctly");
					
				}
	}

}
