package com.abbott.project37375iOS.main;

import java.io.File;

import org.junit.Test;


public class jenkins {
	String filepath;
	@Test
	public void smaple()

	{
	filepath = "C:\\DVT\\project37375iOS\\Reports\\reports\\AverageGlucose_T002_DataAvailable\\United Kingdom\\2017-12-01_170524\\test0";
		File oldFile=new File("C:\\DVT\\project37375iOS\\Reports\\reports\\AverageGlucose_T002_DataAvailable\\United Kingdom\\2017-12-01_170524\\test0"+ "\\2.pdf");
		File newFile=new File("C:\\DVT\\project37375iOS\\Reports\\reports\\AverageGlucose_T002_DataAvailable\\United Kingdom\\2017-12-01_170524\\test0" +"\\"+getTestName()+"\\"+getClass().getSimpleName()+".pdf");
		System.out.println(oldFile);
		System.out.println(newFile);
		boolean success=oldFile.renameTo(newFile);
		System.out.println(success);
		if(success) {
			
			System.out.println("Rename the report");
			
		}
		else
		{
			System.out.println("Failed to rename the report");
		}
		
		/*File folder = new File("\\DVT\\project37375iOS\\Reports\\reports\\AverageGlucose_T002_DataAvailable\\United Kingdom\\2017-12-01_170524\\test0\\");
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {

            if (listOfFiles[i].isFile()) {

                File f = new File("c:\\DVT\\project37375iOS\\Reports\\reports\\AverageGlucose_T002_DataAvailable\\United Kingdom\\2017-12-01_170524\\test0\\"+listOfFiles[i].getName()); 

                f.renameTo(new File("c:\\DVT\\project37375iOS\\Reports\\reports\\AverageGlucose_T002_DataAvailable\\United Kingdom\\2017-12-01_170524\\test0\\"+i+".pdf"));
                System.out.println(f);
               
            }
        }

     */
	}

	private Object getTestName() {
		// TODO Auto-generated method stub
		return null;
	}

}
