package com.abbott.project37375iOS.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import javax.xml.parsers.ParserConfigurationException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import static java.time.temporal.ChronoUnit.DAYS;
import jxl.read.biff.BiffException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.xml.sax.SAXException;
import com.experitest.client.Client;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

public class BaseHelper {

	
	private int port;
	private String host;
	protected MyClient client = null;
	protected String usedDeviceName = null;
	protected Map<String, String> data = null;
	protected int dataIndex = 0;
	protected boolean didFail = false;
	protected Throwable exception = null;
	Date date = new Date();
	private String ipaPackage;
	String testStartTimeStamp = null;
	private String deviceOSVer = null;
	private String email = null;

	private String stepID;
	private String language;
	private String countrycode;
	private String ipaFileName;
	private String units;
	private String appversion;
	private String appudi;

	private String estimatedA1c;
	private String texttospeech;
	private String safety;
	private String naIcon;
	private String quickRef;
	private String quickStart;
	private String aboutInfo;

	private String direction = null;
	private String languagefilename;

	private static String ValueFilpath;
	private static String FinalLocation;
	private static String ConvertedFilename="";

	private String defaulttimezone;
	private String countryOfExecution;
	private String defaultCOEtimezone;
	private String timezone;
	private String pstformat;
	private String mstformat;
	private String akdtformat;
	private String estformat;
	private String cstformat;
	
	private String testcountryKeyCode;
	private String testbuildType;
	private String reportLocation;
	private String testerinitial;
	private String docReferenceNumber;

	

	//getters and setters for initial 
	public String gettesterinitial() {
		return testerinitial;
	}
	public void settesterinitial(String testerinitial) {
		this.testerinitial = testerinitial;
	}
	//getters and setters for document referernce 
	public String getdocReferenceNumber() {
		return docReferenceNumber;
	}
	public void setdocReferenceNumber(String docReferenceNumber) {
		this.docReferenceNumber = docReferenceNumber;
	}
	public String gettestcountryKeyCode() {
		return testcountryKeyCode;
	}

	public void settestcountryKeyCode(String testcountryKeyCode) {
		this.testcountryKeyCode = testcountryKeyCode;
	}
	public String gettestbuildType() {
		return testbuildType;
	}
	public void settestbuildType(String testbuildType) {
		this.testbuildType = testbuildType;
	}
	public String getReportLocation() {
		return reportLocation;
	}

	public void setReportLocation(String reportLocation) {
		this.reportLocation = reportLocation;
	}
	
	public String getipaPackage() {
		return ipaPackage;
	}

	public void setipaPackage(String ipaPackage) {
		this.ipaPackage = ipaPackage;
	}

	public String getipaFileName() {
		return ipaFileName;
	}

	public void setipaFileName(String ipaFileName) {
		this.ipaFileName = ipaFileName;
	}

	public String getDeviceOSVer() {
		return deviceOSVer;
	}

	public void setDeviceOSVer(String deviceOSVer) {
		this.deviceOSVer = deviceOSVer;
	}
	public String getStepID() {
		return stepID;
	}

	public void setStepID(String stepID) {
		this.stepID = stepID;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCountryCode() {
		return countrycode;
	}

	public void setCountryCode(String countrycode) {
		this.countrycode = countrycode;
	}
	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getAppversion() {
		return appversion;
	}

	public void setAppversion(String appversion) {
		this.appversion = appversion;
	}
	public String getAppudi() {
		return appudi;
	}

	public void setAppudi(String appudi) {
		this.appudi = appudi;
	}

	public String getLanguageFileName() {
		return languagefilename;
	}

	public void setLanguageFileName(String languagefilename) {
		this.languagefilename = languagefilename;
	}

	public String getDefaultTimeZone() {
		return defaulttimezone;
	}
	
	public void setDefaultCOETimeZone(String defaultCOEtimezone) {
		this.defaultCOEtimezone = defaultCOEtimezone;
	}

	public String getDefaultCOETimeZone() {
		return defaultCOEtimezone;
	}

	public void setDefaultTimeZone(String defaulttimezone) {
		this.defaulttimezone = defaulttimezone;
	}

	public String getCountryofExecution() {
		return countryOfExecution;
	}

	public void setCountryofExecution(String countryOfExecution) {
		this.countryOfExecution = countryOfExecution;
	}

	public String getTimeZone() {
		return timezone;
	}

	public void setTimeZone(String timezone) {
		this.timezone = timezone;
	}

	public String getPstformat() {
		return pstformat;
	}

	public void setPstformat(String pstformat) {
		this.pstformat = pstformat;
	}

	public String getMstformat() {
		return mstformat;
	}

	public void setMstformat(String mstformat) {
		this.mstformat = mstformat;
	}

	public String getAkdtformat() {
		return akdtformat;
	}

	public void setAkdtformat(String akdtformat) {
		this.akdtformat = akdtformat;
	}

	public String getEstformat() {
		return estformat;
	}

	public void setEstformat(String estformat) {
		this.estformat = estformat;
	}

	public String getCstformat() {
		return cstformat;
	}

	public void setCstformat(String cstformat) {
		this.cstformat = cstformat;
	}

	public long diffInDays(LocalDate a, LocalDate b) {
		return DAYS.between(a, b);
	}

	public String getEstimatedA1c() {
		return estimatedA1c;
	}
	public void setEstimatedA1c(String estimatedA1c) {
		this.estimatedA1c = estimatedA1c;
	}
	public String getTextToSpeech() {
		return texttospeech;
	}
	public void setTextToSpeech(String texttospeech) {
		this.texttospeech = texttospeech;
	}

	public String getSafetyConfig() {
		return safety;
	}
	public void setSafetyConfig(String safety) {
		this.safety = safety;
	}

	public String getNAIconConfig() {
		return naIcon;
	}
	public void setNAIconConfig(String naIcon) {
		this.naIcon = naIcon;
	}

	public String getQuickRefConfig() {
		return quickRef;
	}
	public void setQuickRefConfig(String quickRef) {
		this.quickRef = quickRef;
	}

	public String getQuickStartConfig() {
		return quickStart;
	}
	public void setQuickStartConfig(String quickStart) {
		this.quickStart = quickStart;
	}
	
	public String getAboutInfo() {
		return aboutInfo;
	}
	public void setAboutInfo(String aboutInfo) {
		this.aboutInfo = aboutInfo;
	}
	
		public void setEmail() {
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		SimpleDateFormat sampledate = new SimpleDateFormat("HHmmMMddYY");
		String MMDDYY = sampledate.format(c.getTime());
		String Email = "auto" + MMDDYY + "@gmail.com";
		this.email = Email;
	}

	public String getEmail() {
		return email;
	}

	@Before
	public void setUp() throws Exception  {
		setValues();
		initClientAndDevice();	
		client.setShowReport(false);
		System.out.println(usedDeviceName);
		client.setDevice(usedDeviceName);
		client.openDevice();
		System.out.println(getTestName());

		String DeviceVer = client.getDeviceProperty("device.version");
		setDeviceOSVer(DeviceVer);
		if( !getTestName().contains("PreRequisite")){
			setInputLanguage(client,getLanguageFileName());
			launch(client);
			allowNotifications(client);
			if((!getTestName().contains("ReleaseBuild"))){
				if( (!getTestName().contains("FirstTime")) && (!getTestName().contains("AccountSettings"))){
					clickDevUser(client);
					selectSkipForDebugging(client);
					allowNotifications(client);
				}else{
					selectNetworkMode(client,"USE REAL SERVERS");
				}
			}

		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to allow the notifications
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 */

	public void allowNotifications(Client client){
		if(client.isElementFound("NATIVE", "nixpath=//*[contains(@text,'Notifications')]", 0)){
			client.click("NATIVE", "xpath=//*[@text='Allow']", 0, 1);
			waitFor(client,1);
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to select Real server network mode
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param networkMode
	 * 			set the network mode(USE REAL SERVERS/MOCK)
	 *        
	 * 
	 */

	public void selectNetworkMode(Client client, String networkMode){
		openDebugDrawer(client);

		if(client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='ScanBannerDownArrow' and ./preceding-sibling::*[@accessibilityLabel='Network Mode']]", 0)){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='ScanBannerDownArrow' and ./preceding-sibling::*[@accessibilityLabel='Network Mode']]", 0, 1);
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@text='"+networkMode+"' and @class='UITableViewCell']", 0, 1);
			waitFor(client,3);
			closeDebugDrawer(client);
			waitForProgress(client);
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to set the values from Setup Property File
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * 
	 */

	public void setValues() throws IOException, ParserConfigurationException, SAXException{
		String DataFilePath = getProperty("user.dir") +getProperty("test.buildConfigFilePath");
		if(null!=System.getenv("test.countryKeyCode")) {
			settestcountryKeyCode(System.getenv("test.countryKeyCode"));
		}else {
			settestcountryKeyCode(getProperty("test.countryKeyCode"));
		}
		if(null!=System.getenv("test.buildType")) {
			settestbuildType(System.getenv("test.buildType"));
		}else {
			settestbuildType(getProperty("test.buildType"));
		}
		if(null!=System.getenv("test.softwareVersion")) {
			setAppversion(System.getenv("test.softwareVersion"));
		}else {
			setAppversion(getProperty("test.softwareVersion"));
		}

		if(null!=System.getenv("test.countryofExecution"))
		{
			setCountryofExecution(System.getenv("test.countryofExecution"));
		}else {
			setCountryofExecution(getProperty("test.countryofExecution"));
			
		}
		//TODO for testerinitial 
		if(null!=System.getenv("tester.initial")) {
			
			settesterinitial(System.getenv("tester.initial"));
			
		}else {
			settesterinitial(getProperty("tester.initial"));
		}
		ArrayList<ArrayList<Object>> dataFromExcel=ReadExcelData(DataFilePath,"ConfigSheet",gettestcountryKeyCode());
		String[] configData = dataFromExcel.get(0).toArray(new String[dataFromExcel.get(0).size()]);
		setCountryCode(configData[0]);
		setipaFileName(configData[1]+"-"+gettestbuildType()+".ipa");
		setLanguage(configData[2]);
		setLanguageFileName(configData[3]);
		setipaPackage(configData[4]);
		setUnits(configData[5]);
		setAppudi(configData[6]+ getAppversion());
		setEstimatedA1c(configData[7]);
		setTextToSpeech(configData[8]);
		setSafetyConfig(configData[9]);
		setNAIconConfig(configData[10]);
		setQuickRefConfig(configData[11]);
		setQuickStartConfig(configData[12]);
		setAboutInfo(configData[13]);
		for(int i =0; i<dataFromExcel.get(0).size();i++) {
			System.out.println("configData["+i+"]==>"+ configData[i]);
		}

		if (getCountryofExecution().contains("US")) {
			setDefaultTimeZone(LibrelinkConstants.USZone);
			setDefaultCOETimeZone(LibrelinkConstants.US);
		} else {
			setDefaultTimeZone(LibrelinkConstants.IndiaZone);
			setDefaultCOETimeZone(LibrelinkConstants.India);
		}
		String[] testzone;

		if(getTimeZoneValue(LibrelinkConstants.US).contains("GMT-7")){
			testzone= getProperty("test.timezoneformat.1").split(";");
		}else{
			testzone= getProperty("test.timezoneformat.0").split(";");
		}


		setPstformat(testzone[0]);
		setMstformat(testzone[1]);
		setEstformat(testzone[2]);
		setAkdtformat(testzone[3]);
		setCstformat(testzone[4]);
		
		String DataFilePath1 = getProperty("user.dir") +getProperty("test.footerDetails");
		ArrayList<ArrayList<Object>> dataFromExcel1=ReadExcelData(DataFilePath1,"Sheet1",getClass().getSimpleName());
		String[] configData1 = dataFromExcel1.get(0).toArray(new String[dataFromExcel1.get(0).size()]);
		setdocReferenceNumber(configData1[0]);
		//todo - read excel and find classname match and set the docnoreference
				
		//test.footerDetails
		
	}
	

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Select skip for debugging option for time settings
	 * 
	 * @param client
	 *       Integrate SeeTestAutomation      
	 */

	public void selectSkipForDebugging(Client client){
		client.waitForElement("NATIVE", "xpath=//*[contains(@accessibilityLabel,'Update Date')]",0, 10000);
		if(client.isElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'Update Date')]",0)){
			client.click("NATIVE", "accessibilityLabel=SKIP FOR DEBUGGING!", 0, 1);
			waitFor(client,1);
		}
	}

	/**
	 * Author: Shabina Sherif
	 * 
	 * Method to Set Input Language
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 *  @param language        
	 *         set the Language file name  
	 */
	public void setInputLanguage(Client client, String language) {
		String appLanguageFilePath = getProperty("user.dir") + getProperty("Languagefile") +  language + ".properties";
		System.out.println("<--- SETTING APP LANGUAGE FILE --- " + appLanguageFilePath + " --->");
		client.setLanguagePropertiesFile(appLanguageFilePath);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Tear down method to handle exceptions and generate reports
	 * 
	 */

	public void tearDown()  {
		if (didFail) {
			System.out.println("<--- FAIL --- " + exception.toString()
			+ " --->");

			if ((getStepID() != null) || (exception != null)) {
				capturescreenshot(client,
						getStepID() + "----------EXCEPTION----------"
								+ exception.toString(), false);
			} else {
				capturescreenshot(client,
						"No information on exception occurred", false);
			}
			if( !getTestName().contains("PreRequisite") && (!getTestName().contains("ReleaseBuild"))){
				closePhoneSettings(client);
				try {
					currentSystemTime(client);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}			
			}

		} else {
			System.out.println("<--- SUCCESS --- " + usedDeviceName + " --- "
					+ getTestName() + " --->");
		}
		
		if( !getTestName().contains("PreRequisite") && (!getTestName().contains("ReleaseBuild"))){
			launch(client);
			selectingSASMode(client, "DEFAULT");
			logOutUser(client);
			if((getTestName().contains("FirstTime") || getTestName().contains("AccountSettings"))){
				selectNetworkMode(client,"MOCK");
			}
		}
		client.generateReport(true);
		// TODO if getdoc no reference is NA then call below method
		if(getdocReferenceNumber().equalsIgnoreCase("NA")) {
		changeReportName();	
		}else {
			
				try {
					addPdfFooter ();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
			
		// else call new method and change the respective variables
		didFail = false;
		exception = null;
	
		}
	public void addPdfFooter() throws IOException, DocumentException{
	  String DEST = getReportLocation() +"\\"+getClass().getSimpleName()+".pdf";
        File file = new File(DEST);
	        file.getParentFile().mkdirs();
	        manipulatePdf(getReportLocation()+ "\\index.pdf", DEST);
	}
	 public void manipulatePdf(String src, String dest) throws IOException, DocumentException {
		 PdfReader reader = new PdfReader(src);
	        int n = reader.getNumberOfPages();
	        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
	        
	        PdfContentByte pagecontent;
	        for (int i = 0; i < n; ) {
	            pagecontent = stamper.getOverContent(++i);
	            float x = reader.getPageSize(i).getRight(100);
		        float y = reader.getPageSize(i).getBottom(100);
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
	                    new Phrase(String.format("Page %s of %s", i, n)), x,y, 0);
	          }
	       //gettester for DT 
	        for (int i = 0; i < n; ) {
	            pagecontent = stamper.getOverContent(++i);
	            float x = reader.getPageSize(i).getWidth() / 2;
		        float y = reader.getPageSize(i).getBottom(100);
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
	                    new Phrase(String.format(gettesterinitial())), x,y, 0);
	          }
//getters and setters for documentaion name from excel if it NA we have to use method from report location 
	        for (int i = 0; i < n; ) {
	            pagecontent = stamper.getOverContent(++i);
	            float x = reader.getPageSize(i).getLeft(100);
		        float y = reader.getPageSize(i).getBottom(100);
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
	            		new Phrase(String.format(getdocReferenceNumber())), x,y, 0);
	          }
	        stamper.close();
	        reader.close();
	    }


		
		/**
		 * Author : Devi
		 * 
		 * Method to change Report Name
		 */
	
	public  void changeReportName() {
		
		File oldFile=new File(getReportLocation()+ "\\index.pdf");
		File newFile=new File(getReportLocation() +"\\"+getClass().getSimpleName()+".pdf");
		boolean success=oldFile.renameTo(newFile);
		if(success) {
			System.out.println("Rename the report");
		}else {
			System.out.println("Failed to rename the report");
		}
	}
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Initialize driver and device
	 * 
	 * @throws NumberFormatException
	 * 		Throws this exception for host no
	 * @throws BiffException
	 * 		Throws this exception for file transfer or conversions
	 * @throws Exception
	 * 		Throws this exception for all other generic issues
	 */

	public void initClientAndDevice() throws NumberFormatException,
	BiffException, Exception {
		try {
			writeConsole();
		} catch (IOException e) {

			e.printStackTrace();
		}
		initHost();
		initPort();
		client = new MyClient(host, port);
		initDevice();
		initProjectBaseDirectory();
		initReport();

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to setup host name
	 * 
	 */

	private void initHost() {
		if (host == null) {
			host = getProperty("seetest.client.host");
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to set up port number
	 * 
	 */

	private void initPort() {
		if (port == 0) {
			port = Integer.valueOf(getProperty("seetest.client.port"));
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to set up device
	 * 
	 */

	private void initDevice() {
		if (usedDeviceName != null) {
			return;
		}
		usedDeviceName = getProperty("device.name").contains(":") ? getProperty("device.name")
				: client.waitForDevice(getProperty("device.name"), 300000);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to set up object repository
	 * 
	 */

	private void initProjectBaseDirectory() {
		String projectBaseDirectory = getProperty("user.dir")
				+ getProperty("project.base.directory");
		client.setProjectBaseDirectory(projectBaseDirectory);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to set up report location
	 * 
	 */

	private void initReport() {
		testStartTimeStamp = new SimpleDateFormat("yyyy-MM-dd_HHmmss").format(Calendar.getInstance().getTime()); // Get current datetime as string.	
		String reportFolder = getProperty("user.dir") + "\\Reports\\reports\\"+  getTestName()+"\\" +getCountryCode() +"\\"+testStartTimeStamp ;
		client.setReporter("pdf", reportFolder,getReportName());
		setReportLocation(reportFolder+"\\test0");
	}

	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to get the test name
	 * 
	 * @return TestName
	 * 		Returns the test name
	 */

	public String getTestName() {
		String[] klassNameSplit = this.getClass().getName().split("\\.");
		return klassNameSplit[klassNameSplit.length - 1];

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to get the report name
	 * 
	 * @return reportName
	 * 		Returns reportname
	 */

	public String getReportName() {
		String testname =  getTestName();
		testname = testname.replaceAll("_", " ");
		return testname;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to look for exceptions
	 * 
	 */

	@Rule
	public TestWatcher rule = new TestWatcher() {
		protected void failed(Throwable e, Description description) {
			didFail = true;
			exception = e;

			tearDown();

		}

		protected void succeeded(Description description) {
			tearDown();
		}
	};

	/**
	 * Author: Shabina
	 * 
	 * Method To write the console to a file
	 * 
	 * @throws IOException 
	 * 		Throws IO Exception for file transfer or conversions
	 */

	public void writeConsole() throws IOException{

		System.setOut(new PrintStream(new FileOutputStream(getProperty("user.dir") + "\\Reports\\consoleOutput\\"+getTestName()+"_"+getCountryCode()+".txt")));
		System.out.println("This is the console output");

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method to Capture screen shot
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *            
	 * @param string
	 *            screen name
	 *            
	 * @param status
	 *            true to take screen shot
	 *            
	 */

	public void capturescreenshot(Client client, String string, boolean status) {
		waitFor(client,1);
		client.setShowReport(true);
		client.report(string, status);
		client.setShowReport(false);
		waitFor(client,5);
	}

	/**
	 * Author: Shabina
	 * 
	 * Move App to background
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 */

	public void moveApptoBackground(Client client) {
		client.deviceAction("Home");
	}

	/**
	 * Author: Shabina
	 * 
	 * Method to Get Property from property file
	 * 
	 * @param property
	 *         set the property file name
	 * @return propertyValue
	 * 		Returns the propertyValue
	 */

	public static String getProperty(String property) {
		if (System.getProperty(property) != null) {
			return System.getProperty(property);
		}
		File setupPropFile = new File("setup.properties");
		if (setupPropFile.exists()) {
			Properties prop = new Properties();
			FileReader reader;
			try {
				reader = new FileReader(setupPropFile);
				prop.load(reader);
				reader.close();
				return prop.getProperty(property);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * Author: Shabina
	 * 
	 * Method to Install application
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation  
	 *            
	 */

	public void install(Client client) {
		client.install(getProperty("user.dir") + getProperty("ipalocation")+getipaFileName(), true, false);
	}

	/**
	 * Author: Shabina
	 * 
	 * Method to Launch application
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation     
	 */

	public void launch(Client client) {
		client.launch(getipaPackage(), true, true);
		waitForProgress(client);

	}

	/**
	 * Author: Shabina
	 * 
	 * Method to Wait for the progress to be completed
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation     
	 */

	public void waitForProgress(Client client) {
		client.waitForElementToVanish(
				"NATIVE",
				"xpath=//*[@class='UIImageView' and ./parent::*[@accessibilityLabel='In progress'] and @top='true']",
				0, 80000);
	}

	/**
	 * Author: Shabina
	 * 
	 * Method to UnInstall application
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation    
	 */

	public void unInstall(Client client) {
		client.uninstall(getipaPackage());
	}


	/**
	 * Author: Shabina
	 * 
	 * Method to Move to Homescreen using DevUser Option
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation    
	 */

	public void clickDevUser(Client client) {
		if(!client.isElementFound("NATIVE", "accessibilityLabel=DevUser", 0)){
			logOutUser(client);
		}
		client.click("NATIVE", "accessibilityLabel=DevUser", 0, 1);
		allowNotifications(client);
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo' and @top='true']", 0, 10000);
	}


	/**
	 * Author: Shabina
	 * 
	 * Method to click on Add Note
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation   
	 */

	public void clickAddNote(Client client) {
		if (getLanguage().contains("English (U.S.)")&& getCountryCode().contains("United States")) {
			client.click("NATIVE", "accessibilityLabel=EditIconLarger", 0, 1);
		} else {
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='ADD NOTE']", 0, 1);
		}

		waitFor(client, 1);
	}

	/**
	 * Author: Shabina
	 * 
	 * Method to Startup to navigate to HomeScreen
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation 
	 */

	public void startUp(Client client) {

		unInstall(client);
		install(client);
		launch(client);
		clickDevUser(client);
	}

	/**
	 * Author: Rini
	 * 
	 * Method To convert string files to property files
	 * 
	 */

	public static void createPropertyFiles() {
		ValueFilpath=getProperty("user.dir") +"\\stringfiles";
		FinalLocation=getProperty("user.dir") +"\\languagefiles";
		File finalPath = new File(FinalLocation);
		if (!finalPath.exists())
			finalPath.mkdir();
		else {
			/*
			 * Empty existing files
			 */
			File[] tempFiles = finalPath.listFiles();
			for (File tempFile : tempFiles) {
				tempFile.delete();
			}
		}
		convertAll(new File(ValueFilpath));
	}

	public static void convertAll(File node) {
		String propertyContent = "";
		if (node.isDirectory() && !(node.getName().equalsIgnoreCase("languagefiles")) && !(node.getName().equalsIgnoreCase("converted"))) {
			System.out.println(node.getAbsoluteFile());
			String[] subNote = node.list();
			for (String filename : subNote) {
				convertAll(new File(node, filename));
			}
		} else {
			if (node.isFile()  && !(node.getName().equalsIgnoreCase("README.txt"))) {
				System.out.println(node.getAbsoluteFile());                          
				propertyContent = convertFiles(node);                         

				ConvertedFilename = node.getParentFile().getName();
				ConvertedFilename = ConvertedFilename.replaceAll(".lproj", "");

				File finalPath = new File(FinalLocation);
				if (!finalPath.exists())
					finalPath.mkdir();
				try {

					File file = new File(FinalLocation, ConvertedFilename + ".properties");
					file.createNewFile();                                  
					BufferedWriter bw1 = new BufferedWriter(new OutputStreamWriter(
							new FileOutputStream(file), "UTF-8"));                                                      
					bw1.write(propertyContent);
					bw1.close();

				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}

	public static String convertFiles(File inputFile) {
		String fileContent = "";
		if(inputFile.getParentFile().isDirectory()) {				
			try (BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(inputFile), "UTF-8"))) {				    
				String line;
				while ((line = br.readLine()) != null) {
					if(line != null && !line.contains("/*") && !line.contains("*/") && (!line.equals(""))) {//Exclude comments
						line = line.replaceAll("\";", "");
						line = line.replaceAll("\" = \"", " = ");
						line = line.replaceAll("\"", "");

						System.out.println(line);
						line += "\n";
						fileContent += line;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return fileContent;

	}

	/**
	 * Author: Chandra Arumugam
	 * 
	 * Method to Change Phone time format to 12/24 hours
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param hourFormat
	 * 				change Time Format to 12/24 Hours
	 * 
	 */

	public void changePhoneHourTimeFormat(Client client, String hourFormat) {
		openDateTimeSettings(client);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Date & Time']", 0, 5000);
		if (hourFormat.equals("12")) {
			if (!client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'0')]",
							0)) {
				client.click(
						"NATIVE",
						"xpath=//*[@text='24-Hour Time' and @class='UIASwitch']",
						0, 1);
			}
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'0')]",
					0);
		} else if (hourFormat.equals("24")) {
			if (!client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
							0)) {
				client.click(
						"NATIVE",
						"xpath=//*[@text='24-Hour Time' and @class='UIASwitch']",
						0, 1);
			}
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
					0);
		}
		closePhoneSettings(client);

	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Close Application
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void closeApplication(Client client) {
		client.applicationClose(getipaPackage());
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Wait for n secs
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param secs    
	 *        set the time for sleep          
	 */

	public void waitFor(Client client, int secs) {
		secs = secs * 1000;
		client.sleep(secs);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Close Device Setting
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */

	public void closePhoneSettings(Client client) {
		client.applicationClose("com.apple.Preferences");
		waitFor(client,2);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Open phone settings
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 */

	public void openPhoneSettings(Client client) {
		openSettings(client);
		client.elementSwipeWhileNotFound(
				"NATIVE",
				"xpath=//*[@class='UIATable']",
				"Up",
				400,
				1000,
				"NATIVE",
				"xpath=//*[@placeholder='Search' and @top='true' and @onScreen='true']",
				0, 1000, 2, false);
		waitFor(client,2);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Open Settings in Device
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */

	public void openDateTimeSettings(Client client) {
		openSubOptionsInSettings(client,"Date ");
	}

	/**
	 * Author: Amaresh/Shabina
	 * 
	 * Method to Navigate To Screen
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param Screen
	 *            Navigate to Screens
	 * 
	 */

	public void navigateToScreen(Client client, String Screen) {
		clickOnMenu(client);
		waitFor(client,1);
		if(!client.isElementFound("NATIVE", "xpath=//*[@text='Home' and @class='LibreLink.RegularLabel' and @top='true']", 0)){
			client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and ./child::*[@accessibilityIdentifier='MenuHomeButton']]", 0, "Up", 0, 1000);

		}
		client.elementSwipeWhileNotFound(
				"NATIVE",
				"xpath=//*[@class='UITableView' and ./child::*[@accessibilityIdentifier='MenuHomeButton']]",
				"Down", 100, 1000, "NATIVE", "xpath=//*[@accessibilityLabel='"
						+ Screen + "']", 0, 1000, 5,
						false);
		waitFor(client,2);
		client.click("NATIVE", "xpath=//*[@text='"+Screen+"' and @class='LibreLink.RegularLabel']", 0, 1);
		waitFor(client,1);
		if (Screen.equals("Home")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo']",
					0);
		} else if (Screen.equals("Home") || Screen.equals("Logbook")
				|| Screen.equals("Reminders") || Screen.equals("Help")
				|| Screen.equals("Settings") || Screen.equals("About")) {
			verifyPageTitles(client, Screen);
		} else {
			String report = Screen.toUpperCase();
			verifyPageTitles(client, report);


		}
	}
	
	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Page title gets displayed
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param title
	 *            Enter page title
	 *            
	 */

	public void verifyPageTitles(Client client, String title) {
		client.verifyElementFound("NATIVE", "text=" + title, 0);
	}

	/**
	 * Author: Amaresh/Shabina
	 * 
	 * Method to Click on Menu
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 */

	public void clickOnMenu(Client client) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='SliderMenuIcon' and @onScreen='true']",
				0, 10000);
		if (!client.isElementFound("NATIVE",
				"xpath=//*[@class='LibreLink.MenuTableCell' and @onScreen='true']", 0)) {
			client.click(
					"NATIVE",
					"xpath=//*[@accessibilityLabel='SliderMenuIcon' and @onScreen='true']",
					0, 1);
			waitFor(client,1);
		}
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='UITableView' and @backgroundColor='0xF2F4F5' and @onScreen='true']", 0);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Home Page title
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyHomePage(Client client) {
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SliderMenuIcon']", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set Current System Time in device
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 */

	public void currentSystemTime(Client client) throws ParseException {
		openDateTimeSettings(client);
		if (!client
				.isElementFound(
						"NATIVE",
						"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
						0)) {
			client.click(
					"NATIVE",
					"xpath=//*[@text='24-Hour Time' and @class='UIASwitch']",
					0, 1);
			waitFor(client,2);
		}
		automaticDateAndTime(client, true);
		closePhoneSettings(client);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Enable/disable Automatic DateAndTime
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param on
	 *            true to on
	 *            
	 */

	public void automaticDateAndTime(Client client, boolean on) {
		client.waitForElement("NATIVE",
				"xpath=//*[@text='Date & Time' and @XCElementType='XCUIElementTypeNavigationBar']", 0, 5000);
		waitFor(client,1);
		if (on) {
			if (!client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@text='Set Automatically' and @class='UIASwitch' and @value='1']",
							0)) {
				clickSetAutomaticDateAndTime(client);
			}
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Set Automatically' and @class='UIASwitch' and @value='1']",
					0);

		} else {
			if (!client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@text='Set Automatically' and @class='UIASwitch' and @value='0']",
							0)) {
				clickSetAutomaticDateAndTime(client);
			}
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Set Automatically' and @class='UIASwitch' and @value='0']",
					0);
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to click set Automatic date and time
	 * 
	 * @param client
	 *             Integrate SeeTestAutomation
	 *            
	 */

	public void clickSetAutomaticDateAndTime(Client client) {
		try{
			client.click(
					"NATIVE",
					"xpath=//*[@text='Set Automatically' and @class='UIASwitch']",
					0, 1);
			waitFor(client,3);
		}catch(Exception e){
			client.launch("com.apple.Preferences", true, false);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set The Date And Time In Phone Date Settings
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param day
	 *            Selecting Date from Device Settings
	 *            
	 * @param month
	 *            Selecting month from Device Settings
	 *            
	 * @param year
	 *            Selecting year from Device Settings
	 *            
	 * @param time
	 *            Selecting time from Device Settings
	 *            
	 * @throws ParseException
	 * 			Throws Parse Exception for setting date
	 */

	public void setTheDateAndTime(Client client, int day, int month, int year, String time) throws ParseException {
		openDateTimeSettings(client);
		if (!client
				.isElementFound(
						"NATIVE",
						"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
						0)) {
			client.click(
					"NATIVE",
					"xpath=//*[@text='24-Hour Time' and @class='UIASwitch']",
					0, 1);
		}
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
				0);
		automaticDateAndTime(client, true);
		automaticDateAndTime(client, false);
		openDeviceDatePicker(client);
		if(day!=0 && month !=0 && year !=0){
			String months,days;
			if (month<=9){
				months= "0"+String.valueOf(month);
			}
			else{
				months= String.valueOf(month);
			}
			if (day<=9){
				days= "0"+String.valueOf(day);
			}
			else{
				days= String.valueOf(day);
			}
			String date = year +"-"+months+"-"+days;
			setDate(client, date);

		}
		if(time!=null){
			setTime(client, time);}

		closePhoneSettings(client);
		launch(client);
		waitFor(client,3);
		selectSkipForDebugging(client);
		System.out.println("System Date:"+(client.getDeviceProperty("device.time").substring(0, 10)));

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set The Device Date
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 * @param date
	 *        set the date
	 *        
	 * @throws ParseException
	 * 			Throws parse exception for setting date
	 */

	public void setDate(Client client, String date)
			throws ParseException {

		String strdeviceDate = client.getDeviceProperty("device.time").substring(0, 10);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate deviceDate = LocalDate.parse(strdeviceDate, formatter);
		LocalDate newDate = LocalDate.parse(date, formatter);
		long noofdays = diffInDays(newDate,deviceDate);

		if(noofdays!=0){
			direction = "down";
			if(noofdays<0){
				direction = "up";
				noofdays = diffInDays(deviceDate,newDate);
			}

			System.out.println("Days Difference " + noofdays);

			long divisble = (noofdays/250);
			long balance = (noofdays%250);
			int i=0;
			try{
				for ( i=0; i< divisble;i++){
					client.setPickerValues("NATIVE", "xpath=//*[@class='UIAPicker']",
							0, 0, direction + ":250");
					waitFor(client,2);
				}
				client.setPickerValues("NATIVE", "xpath=//*[@class='UIAPicker']",
						0, 0, direction + ":" + balance);
				waitFor(client,1);
			}
			catch(Exception e){
				waitFor(client,3);
				client.launch("com.apple.Preferences", true, true);
				waitFor(client,2);
				if(!client.isElementFound("NATIVE", "xpath=//*[@text='Date & Time' and @name='Date & Time']",0)){
					openDateTimeSettings(client);
				}
				openDeviceDatePicker(client);
				setDate(client, date);
			}
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set The Time Alone
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 * @param time
	 *        set the time
	 * @throws ParseException
	 * 		Throws parse exception for setting date        
	 * 
	 */	
	public void setTheTimeAlone(Client client, String time) throws ParseException{
		openDateTimeSettings(client);
		automaticDateAndTime(client, false);
		openDeviceDatePicker(client);
		if(time!=null){
			setTime(client, time);}

		closePhoneSettings(client);
		reLaunch(client);
		waitFor(client,3);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set The Device time
	 * 
	 * @param client
	 * 		  Integrate SeeTestAutomation
	 * 
	 * @param time
	 * 		  set the time
	 * @throws ParseException
	 * 			Throws parse exception for setting date
	 */

	public void setTime(Client client, String time)
			throws ParseException {
		try{
			String inputTime[]= time.split(":");

			client.setPickerValues("NATIVE", "xpath=//*[@class='UIAPicker']",
					0, 2, inputTime[1]);
			client.setPickerValues("NATIVE", "xpath=//*[@class='UIAPicker']",
					0, 1, inputTime[0]);
			waitFor(client,1);
		}
		catch(Exception e){
			waitFor(client,3);
			client.launch("com.apple.Preferences", true, true);
			waitFor(client,2);
			if(!client.isElementFound("NATIVE", "xpath=//*[@text='Date & Time' and @name='Date & Time']",0)){
				openDateTimeSettings(client);
			}
			openDeviceDatePicker(client);
			setTime(client,time);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Open Device DatePicker
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void openDeviceDatePicker(Client client){
		client.click(
				"NATIVE",
				"xpath=//*[@XCElementType='XCUIElementTypeStaticText' and @knownSuperClass='UITableViewLabel' and contains(@text,':')]",
				0, 1);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Open Background Application
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void openBackgroundApp(Client client) {
		client.deviceAction("Home");
		waitFor(client,2);
		swipePage(client, "Left");
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='SpotlightSearchField']", 0,
				10000);
		if (!client.isElementFound("TEXT", "LibreLink", 0)) {
			client.elementSendText("NATIVE",
					"xpath=//*[@accessibilityLabel='SpotlightSearchField']", 0,
					"Libre");
			waitFor(client,2);

			client.click("TEXT", "LibreLink", 0, 1, 0, -100);
		} else {
			client.click("TEXT", "LibreLink", 0, 1, 0, -100);
		}

	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to swipe the page
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 * @param direction   
	 *        set the directions(Left/Right/Up/Down)     
	 * 
	 */

	public void swipePage(Client client, String direction) {
		client.swipe(direction, 0, 500);
		waitFor(client,2);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Select SAS mode from Debug drawer
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param sasmode
	 *            SAS mode name(Mock1/Mock2/Default)
	 *            
	 */

	public void selectingSASMode(Client client, String sasmode) {
		openDebugDrawer(client);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@tag='0' and @class='UILabel' and ./preceding-sibling::*[@accessibilityLabel='SAS Mode']]",
				0);
		String str0 = client
				.elementGetProperty(
						"NATIVE",
						"xpath=//*[@tag='0' and @class='UILabel' and ./preceding-sibling::*[@accessibilityLabel='SAS Mode']]",
						0, "text");
		if (str0.equalsIgnoreCase(sasmode)) {
			closeDebugDrawer(client);
		} else {
			client.click(
					"NATIVE",
					"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@accessibilityLabel='ScanBannerDownArrow' and ./preceding-sibling::*[@accessibilityLabel='SAS Mode']]]",
					0, 1);
			if (client.waitForElement("NATIVE",
					"xpath=//*[@accessibilityLabel='" + sasmode
					+ "' and @class='UITableViewLabel']", 0, 2000)) {
				client.click("NATIVE", "xpath=//*[@accessibilityLabel='"
						+ sasmode + "' and @class='UITableViewLabel']", 0, 1);
				waitFor(client,1);
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='"
								+ sasmode
								+ "' and ./preceding-sibling::*[@accessibilityLabel='SAS Mode']]",
								0);
				closeDebugDrawer(client);

			}
			waitFor(client,3);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Close Debug Drawer
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void closeDebugDrawer(Client client) {
		if (client
				.isElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='LibreLink Debug' and @onScreen='true']",
						0)) {
			swipePage(client, "Left");

		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Open Debug Drawer
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void openDebugDrawer(Client client) {
		if (!client
				.isElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='LibreLink Debug' and @onScreen='true']",
						0)) {
			if(client.isElementFound("NATIVE", "xpath=//*[@class='_UINavigationBarContentView']", 0)){
				client.elementSwipe("NATIVE",
						"xpath=//*[@class='_UINavigationBarContentView']", 0, "Right", 0, 500);

			}else {
				client.elementSwipe("NATIVE",
						"xpath=//*[@class='UIPageControl']", 0, "Right", 0, 500);
			}

		}
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='LibreLink Debug']", 0, 3000);
	}

	/**
	 * Author: Amaresh/Shabina
	 * 
	 * Method to Change System time or Device Time
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param hour
	 *            add or decrease hours
	 *            
	 * @param min
	 *            add or decrease minutes
	 *            
	 * @throws ParseException
	 * 		Throws parse exception for setting date
	 */

	public void advanceTime(Client client, int hour, int min)
			throws ParseException {
		openDateTimeSettings(client);
		if (!client
				.isElementFound(
						"NATIVE",
						"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
						0)) {
			client.click(
					"NATIVE",
					"xpath=//*[@text='24-Hour Time' and @class='UIASwitch']",
					0, 1);
		}
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
				0);

		automaticDateAndTime(client, false);
		openDeviceDatePicker(client);
		String deviceTime = client.getDeviceProperty("device.time").substring(0, 10);
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-mm-dd");
		Date orgDate = ft.parse(deviceTime);
		ft.applyPattern("mm-dd-yyyy");
		String devicedate = ft.format(orgDate);
		String[] dd = devicedate.split("-");
		int year = Integer.valueOf(dd[2]);
		int day = Integer.valueOf(dd[1]);
		int month = Integer.valueOf(dd[0]) - 1;
		String phonetime = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@XCElementType='XCUIElementTypeStaticText' and contains(@text,':')]",
						0);

		SimpleDateFormat sdf1 = new SimpleDateFormat("H:m");
		Date time = sdf1.parse(phonetime);
		String currenttime = sdf1.format(time);
		String[] hm = currenttime.split(":");
		Calendar c1 = Calendar.getInstance();
		c1.set(year, month, day, Integer.valueOf(hm[0]), Integer.valueOf(hm[1]));
		c1.add(Calendar.HOUR, hour);
		c1.add(Calendar.MINUTE, min);
		Date newDate = c1.getTime();
		int date = c1.get(Calendar.DATE);
		if (date != day) {
			direction = "up";
			if (newDate.before(orgDate)) {
				direction = "down";
			}

			if(direction=="down"){
				client.setPickerValues("NATIVE", "xpath=//*[@class='UIAPicker']",
						0, 0, direction + ":1");
			}else{

				System.out.println("Date in the loop :" + c1.getTime());
				String month_name =new SimpleDateFormat("MMM d").format(c1.getTime()).toString();
				client.elementSetProperty("NATIVE", "xpath=//*[@class='UIAPicker']", 0, "text", month_name);

			}
		}

		String timeDuration, requiredhour, requiredminute;

		if (c1.get(Calendar.MINUTE) > 9) {
			requiredminute = String.valueOf(c1.get(Calendar.MINUTE));
		} else {
			requiredminute = "0" + String.valueOf(c1.get(Calendar.MINUTE));
		}
		if (c1.get(Calendar.HOUR_OF_DAY) > 9) {
			requiredhour = String.valueOf(c1.get(Calendar.HOUR_OF_DAY));
		} else {
			requiredhour = "0" + String.valueOf(c1.get(Calendar.HOUR_OF_DAY));
		}

		timeDuration = requiredhour + ":" + requiredminute;

		System.out.println("timeDuration :" + timeDuration);
		setTime(client, timeDuration);
		closePhoneSettings(client);
	}


	/**
	 * Author: ShabinaSherif (Completed)
	 *            
	 * Method to Re launch the application
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */

	public void reLaunch(Client client) {
		client.launch(getipaPackage(), true, false);
		waitFor(client, 3);
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to Open Notification 
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */

	public void openNotification(Client client) {
		client.waitForElementToVanish("NATIVE", "xpath=//*[@accessibilityLabel='NotificationShortLookView']", 0, 5000);
		waitFor(client,2);
		client.swipe("Up", 0, 1000);
		waitFor(client,2);

	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to clear All Notifications
	 *  
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void clearAllNotification(Client client) {
		client.click("NATIVE", "xpath=//*[@label='Clear notifications']", 0, 1);
		waitFor(client,1);
		closeNotification(client);

	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to clear Single Notification 
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param notificationName
	 *           set and clear the notification
	 *            
	 */

	public void clearSingleNotification(Client client, String notificationName) {
		if(client.isElementFound("NATIVE", "xpath=//*[contains(@text,'"+notificationName+"')]",0)){
		client.elementSwipe("NATIVE", "xpath=//*[contains(@text,'"+notificationName+"')]", 0, "Right", 100, 500);
		waitFor(client,2);
		}
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to Close Notification screen
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void closeNotification(Client client) {
		client.swipe("Down", 0, 1000);
		waitFor(client,2);

	}

	/**
	 * Author: NagarajuKasarla
	 *
	 * Method to Navigate To Sub Menu Screens
	 *
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param subscreen
	 *         setting sub menu screen name
	 *
	 */

	public void navigateToSubMenuScreens(Client client,
			String subscreen) {
		client.waitForElement("NATIVE", "text=" + subscreen, 0, 1000);
		client.click("NATIVE", "text=" + subscreen, 0, 1);
		waitForProgress(client);
		client.verifyElementFound("NATIVE", "accessibilityLabel=" + subscreen,
				0);

	}

	/**
	 * Author: Shabina
	 * 
	 * Enter Value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param label
	 *            send the label value
	 *            
	 * @param value
	 *            send the String value
	 *            
	 */

	public void enterValue(Client client, String label, String value) {
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='"+ label+"']" , 0,
				value);
		client.closeKeyboard();
	}



	/**
	 * Author: ShabinaSherif
	 * 
	 * Method for Find Target Glucose Range
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param range
	 *            high/low glucose range
	 *            
	 * @return
	 * 			return target glucose
	 * 
	 */
	public double findTargetGlucose(Client client, int range) {
		double targetglucoseValue=0;
		String index = client
				.runNativeAPICall("NATIVE",
						"xpath=//*[@class='UIPickerColumnView']", range,
						"invokeMethod:'{\"selector\":\"selectionBarRow\",\"arguments\":[]}'");
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			if (range == 0) {
				targetglucoseValue = Double.parseDouble(index) + 70;
			} else {
				targetglucoseValue = Double.parseDouble(index) + 71;
			}
		}
		else if (getUnits().equalsIgnoreCase("mmol/L")) {
			if (range == 0) {
				targetglucoseValue =(Double.parseDouble(index) + 39)/10;
			} else {
				targetglucoseValue = (Double.parseDouble(index) + 40)/10;
			}
		}
		return targetglucoseValue;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Verify button status
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param option
	 *            NEXT, OK, SAVE , CANCEL , SUBMIT, ACCEPT, REJECT Buttons
	 *            
	 * @param enable
	 *           true/false
	 *           
	 */
	public void verifyButtonStatus (Client client, String option, boolean enable) {

		if (enable) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='" + option
					+ "' and @text='" + option
					+ "' and @textColor='0xFFFFFF']", 0);

		} else {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='" + option
					+ "' and @text='" + option
					+ "']", 0);

		}
		waitFor(client, 1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Click on Next or Save or Ok or Cancel Buttons
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param option
	 *            NEXT, OK, SAVE , CANCEL , SUBMIT, ACCEPT, REJECT, Radio Options like Grams and Servings
	 *            
	 * @param click
	 *          true/false
	 *          
	 */
	public void clickOnButtonOption(Client client, String option,
			boolean click) {

		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='" + option
				+ "' and @knownSuperClass='UIButton' and @onScreen='true']", 0);
		if (click){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + option
					+ "' and  @knownSuperClass='UIButton' and @onScreen='true']", 0,
					1);
		}

		waitForProgress(client);

	}

	/**
	 * Author: Amaresh/Shabina
	 *
	 * Method to Click on back icon
	 *
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void clickOnBackIcon(Client client) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='BackArrow' and @onScreen='true']",
				0, 5000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='BackArrow' and @onScreen='true']",
				0, 1);

		waitFor(client,1);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set The BG value for real or Historic with Static time
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param type
	 *            Select type
	 * 
	 * @param value
	 *            set the value
	 * 
	 * @param isTimeReqd
	 *            true to set the static time(true/false)           
	 *            
	 * @param hours
	 *            Select Hour
	 *            
	 * @param minutes
	 *            Select minutes           
	 * 
	 * */

	public void bgValueWithStaticTime(Client client, String type, String value, boolean isTimeReqd, 
			int hours, int minutes) {
		clickAddSensorDataMethod(client);
		client.click("NATIVE", "text=" + type, 0, 1);
		enterBGValue(client, value);
		if(isTimeReqd){
			try {
				enterStaticTime(client, hours, minutes);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		clickAddScannedValue(client);
	}

	/**
	 * @author Amaresh
	 * 
	 * Method to Click on ADD DATA Button
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void clickAddSensorDataMethod(Client client) {
		client.click("NATIVE", "accessibilityLabel=ADD DATA", 0, 1);
		waitFor(client,1);
	}

	/**
	 * @author Amaresh
	 * 
	 * Method to enter Blood Glucose value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param value
	 * 			text value to be entered
	 * 
	 */

	public void enterBGValue(Client client, String value) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='UITextField']",
				0, 10000);
		client.elementSendText(
				"NATIVE",
				"xpath=//*[@class='UITextField']",
				0, value);
		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='Done' and @text='Done']", 0, 1);
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='ADD']",
				0, 10000);
	}

	/**
	 * Author: Amaresh/Nagaraju
	 * 
	 * Method to Enter the scan and activation date and time
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param days
	 * 			days to be set
	 * 
	 * @param hours
	 * 			hours to be set
	 * 
	 * @param minutes
	 * 			minutes to be set
	 * @throws ParseException 
	 * 			Throws ParseException for settings date/time
	 */

	public void enterScanActivationDateAndTime(Client client,int days, int hours,
			int minutes) throws ParseException {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Calendar cal = Calendar.getInstance();
		String scanTime = client.elementGetText("NATIVE",
				"xpath=//*[@class='UIButtonLabel' and contains(@text,':')]", 0);
		String scanDate = client.elementGetText("NATIVE",
				"xpath=//*[@class='UIButtonLabel' and contains(@text,'-')]", 0);
		String[] date = scanDate.split("-");
		int x = Integer.parseInt(scanTime.substring(0, 2));
		int y = Integer.parseInt(scanTime.substring(3));
		int a = Integer.parseInt(date[0]);
		int b = Integer.parseInt(date[1]);
		int c = Integer.parseInt(date[2]);
		cal.set(Calendar.YEAR, a);
		cal.set(Calendar.MONTH, b-1);
		cal.set(Calendar.DATE, c);
		cal.set(Calendar.HOUR_OF_DAY, x);
		cal.set(Calendar.MINUTE, y);
		cal.set(Calendar.SECOND, 0);
		cal.add(Calendar.DAY_OF_MONTH, days);
		cal.add(Calendar.HOUR, hours);
		cal.add(Calendar.MINUTE, minutes);

		String dateTime = dateFormat.format(cal.getTime());
		String inputActivationDate = dateTime.replace("/", "-");
		String Date = inputActivationDate.substring(0, 10);
		String time = inputActivationDate.substring(11, 16);
		System.out.println(Date);
		String inputDate[] = Date.split("-");
		System.out.println(time);
		String inputTime[]= time.split(":");
		if (!scanDate.equals(Date)) {
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + scanDate
					+ "' and @class='UIButton']", 0, 1);
			client.waitForElement("NATIVE", "text=Select Scan Date:", 0, 5000);
			client.elementSetProperty("NATIVE",
					"xpath=//*[@class='UIDatePicker' and @hidden='false']", 0,
					"date", inputDate[2] + "." + inputDate[1] + "."
							+ inputDate[0]);
			waitFor(client, 2);
			client.click("NATIVE", "accessibilityLabel=OK", 0, 1);
			client.verifyElementFound("NATIVE", "text=" + Date, 0);

		}
		if (!scanTime.equals(time)) {
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + scanTime
					+ "' and @class='UIButton']", 0, 1);
			client.waitForElement("NATIVE", "text=Select Scan Time:", 0, 5000);

			if (getLanguage().contains("U.K.")
					&& getCountryCode().contains("United Kingdom")) {

				setHourandTimeforUKFormat(client, time);
			} else {
				client.elementSetProperty("NATIVE",
						"xpath=//*[@class='UIDatePicker' and @hidden='false']",
						0, "time", inputTime[0] + "." + inputTime[1]);
			}

			waitFor(client, 2);
			client.click("NATIVE",
					"xpath=//*[@accessibilityLabel='OK' and @tag='0']", 0, 1);
			System.out.println("======Time=======" + time);

		}
	}


	/**
	 * @author Amaresh
	 * 
	 * Method to Click on ADD for scan value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void clickAddScannedValue(Client client) {
		client.waitForElement("NATIVE", "text=ADD", 0, 10000);
		client.click("NATIVE", "text=ADD", 0, 1);
		waitFor(client,2);
	}

	/**
	 * Author: Amaresh/Nagaraju
	 * 
	 * Method to Scan Mock Sensor
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param errorCondition
	 *           Set the error condition 
	 * 
	 */

	public void scanMockSensor(Client client, String errorCondition) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='SCAN MOCK SENSOR']", 0, 10000);
		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='SCAN MOCK SENSOR']", 0, 1);
		if(errorCondition!=null){
			client.verifyElementFound("NATIVE", "xpath=//*[@tag='0' and @class='UIButton' and ./preceding-sibling::*[@accessibilityLabel='Error Condition:']]", 0);
			client.click("NATIVE", "xpath=//*[@tag='0' and @class='UIButton' and ./preceding-sibling::*[@accessibilityLabel='Error Condition:']]", 0, 1);
			client.waitForElement("NATIVE","xpath=//*[@accessibilityLabel='Select Error' and @text='Select Error']",0, 10000);
			waitFor(client, 2);
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@text]]", "Down", 0, 500, "NATIVE", "text="+errorCondition, 0, 1000, 3, false);
			client.click("NATIVE", "text="+errorCondition, 0, 1);
		}
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='SCAN NOW' and @text='SCAN NOW']",
				0, 10000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='SCAN NOW' and @text='SCAN NOW']",
				0, 1);
		waitFor(client,5);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Get the language value from property file
	 * 
	 * @param property
	 *         set the property file name
	 * 
	 * @return propertyvalue
	 * 			Returns the propertyvalue from String file
	 */
	public String getLangPropValue(String property) {
		if (System.getProperty(property) != null) {
			return System.getProperty(property);
		}
		File langPropFile = new File(getProperty("user.dir")
				+ getProperty("Languagefile") + getLanguageFileName()
				+ ".properties");
		if (langPropFile.exists()) {
			Properties prop = new Properties();
			FileReader reader;
			try {
				reader = new FileReader(langPropFile);
				prop.load(reader);
				reader.close();
				return prop.getProperty(property);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click on LOGOUT in debug drawer
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void logOutUser(Client client) {
		debugDrawerClearData(client);
		openDebugDrawer(client);
		client.verifyElementFound("NATIVE", "accessibilityLabel=LOGOUT", 0);
		client.click("NATIVE", "accessibilityLabel=LOGOUT", 0, 1);
		closeDebugDrawer(client);
		waitForProgress(client);
		client.waitForElement("NATIVE",
				"accessibilityIdentifier=Freestyle_logo", 0, 10000);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to create an default account
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param ageGroup
	 *        Set the Age group(Adult/Minor)         
	 *            
	 */
	public void createDefaultAccount(Client client, String ageGroup) {
		setEmail();
		logOutUser(client);
		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='GET STARTED NOW']", 0, 1);
		waitFor(client,1);
		clickOnButtonOption(client, "NEXT", true);
		clickAndAcceptPage(client, "Terms of Use");
		clickAndAcceptPage(client, "Privacy Notice");
		if (ageGroup.equalsIgnoreCase("Adult")) {
			createNewAccountDetails(client, "Tester", "Adult", "5", "17",
					"1960");
			clickOnButtonOption(client, "NEXT", true);
			adultLoginDetails(client, getEmail(),
					LibrelinkConstants.CURRENT_PASSWORD,
					LibrelinkConstants.CURRENT_PASSWORD, true);
		} else {
			createMinorAccountDetails(client, "Kid", "Minor");
			clickOnButtonOption(client, "NEXT", true);
			clickMinorMessageOk(client);
			minorLoginDetails(client, "ParentFirstName", "ParentLastName", getEmail(),
					LibrelinkConstants.CURRENT_PASSWORD,
					LibrelinkConstants.CURRENT_PASSWORD, true);
		}

		clickOnCreateAccount(client);
		defaultSettings(client,"grams");
		allowNotifications(client);
	}


	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Minor login details for Create an account
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param parentfname
	 *            Enter parent firstname
	 *            
	 * @param parentlname
	 *            Enter parent lastname
	 *            
	 * @param email
	 *            Enter email           
	 *            
	 * @param password
	 *            Enter password
	 *            
	 * @param confirmpassword
	 *            confirm password
	 * @param  click  
	 *         true to click     
	 */

	public void minorLoginDetails(Client client, String parentfname,
			String parentlname, String email, String password,
			String confirmpassword, boolean click) {
		client.elementSendText("NATIVE",
				"xpath=//*[@knownSuperClass='UITextField' and @placeholder='Parent/Legal Guardian First Name']", 0,
				parentfname);
		client.elementSendText("NATIVE",
				"xpath=//*[@knownSuperClass='UITextField' and @placeholder='Parent/Legal Guardian Last Name']", 0,
				parentlname);
		setEmailAndPassword(client, email, password, confirmpassword);
		client.click("NATIVE", "placeholder=Confirm Password", 0, 1);
		client.closeKeyboard();

		if (click) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']",
					0, 1);
		}
	}


	/**
	 * Author: Amaresh
	 *
	 * Method to Click 'OK' on Minor warning message
	 *
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void clickMinorMessageOk(Client client) {
		client.verifyElementFound("NATIVE", "xpath=//*[@text='OK']", 0);
		client.click("NATIVE", "xpath=//*[@text='OK']", 0, 1);
		waitForProgress(client);
	}


	/**
	 * Author: Amaresh
	 *
	 * Method to Create an Minor Account
	 *
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param fname
	 *            Enter fname as FirstName
	 *            
	 * @param lname
	 *            Enter lname as LastName
	 *            
	 *            
	 */

	public void createMinorAccountDetails(Client client, String fname,
			String lname) {
		setFirstAndLastName(client, fname, lname);

		String age = "12";
		if(getCountryCode().contains("United Kingdom")){
			age = "3";
		}
		enterAgePickDOB(client, age);
	}

	/**
	 * Author: Amaresh
	 *
	 * Method to Select Minor DOB "X" years from date picker
	 *
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param age
	 *            select age from calendar
	 *            
	 */

	public void enterAgePickDOB(Client client, String age) {
		clickDOB(client);
		waitFor(client,1);
		String dobSelected=null;
		int year = Integer.parseInt(age);
		SimpleDateFormat y = new SimpleDateFormat("d.MM.yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, -year);
		int yeartobeSet = cal.get(Calendar.YEAR);
		System.out.println("year" +yeartobeSet);
		if(age.contains("3")){
			yeartobeSet = yeartobeSet+1;
		}else{
			yeartobeSet = yeartobeSet-1;
		}
		String requiredYear = y.format(cal.getTime());
		try{
			client.elementSetProperty("NATIVE",
					"xpath=//*[@class='UIDatePicker' and @hidden='false']", 0,
					"date", requiredYear);
		}catch(Exception e){
			dobSelected = client.elementGetText("NATIVE", "xpath=//*[@placeholder='Date of Birth' and @knownSuperClass='UITextField']", 0);
			String[] yearSplit = dobSelected.split(",");
			dobSelected = yearSplit[1].replaceAll(" ", "");
			System.out.println("year" +Integer.parseInt(dobSelected));
			int diff=0;
			if(yeartobeSet>Integer.parseInt(dobSelected)){
				diff = yeartobeSet-Integer.parseInt(dobSelected);
				client.setPickerValues("NATIVE", "xpath=//*[@class='UIDatePicker']", 0, 2, "up:"+diff);
				client.elementSwipe("TEXT", Integer.toString(yeartobeSet), 0, "up", 100, 2000);

			}else{
				diff =Integer.parseInt(dobSelected)- yeartobeSet;
				client.setPickerValues("NATIVE", "xpath=//*[@class='UIDatePicker']", 0, 2, "down:"+diff);
				client.elementSwipe("TEXT", Integer.toString(yeartobeSet), 0, "Down", 100, 2000);

			}
		}
		waitFor(client,1);
		dobSelected = client.elementGetText("NATIVE", "xpath=//*[@placeholder='Date of Birth' and @knownSuperClass='UITextField']", 0);
		System.out.println("year" +dobSelected);


	}

	/**
	 * Author: Amaresh
	 * 
	 * Adult login details for Create an account
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 * @param email
	 *            email from getEmail          
	 *           
	 * @param password
	 *            Enter password
	 *            
	 * @param confirmpassword
	 *            confirm password
	 *            
	 * @param click
	 *            true/false
	 */

	public void adultLoginDetails(Client client, String email, String password,
			String confirmpassword, boolean click) {
		setEmailAndPassword(client, email, password, confirmpassword);
		waitFor(client,2);
		client.closeKeyboard();
		if (click) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']",
					0, 1);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set Email And Password
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param email
	 *            Enter email 
	 *                     
	 * @param password
	 *            Enter password
	 *            
	 * @param confirmpassword
	 *            enter confirm password
	 *            
	 */

	public void setEmailAndPassword(Client client, String email,
			String password, String confirmpassword) {
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Email']", 0, email);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.closeKeyboard();
		waitFor(client,1);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Confirm Password']",
				0, confirmpassword);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to  Click on CreateAccount page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void clickOnCreateAccount(Client client) {
		client.waitForElement("NATIVE", "text=CREATE ACCOUNT", 0, 10000);
		client.click("NATIVE", "text=CREATE ACCOUNT", 0, 1);
		waitForProgress(client);

	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Enter first name and last name details for Creat a New account
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param fname
	 *            Enter fname as FirstName
	 *            
	 * @param lname
	 *            Enter lname as LastName
	 *            
	 * @param day
	 *            Select day
	 *            
	 * @param month
	 *            Enter month
	 *            
	 * @param year
	 *            Enter year
	 * 
	 */

	public void createNewAccountDetails(Client client, String fname,
			String lname, String month, String day, String year) {
		setFirstAndLastName(client, fname, lname);
		String DOB = day+"."+month+"."+year;
		enterDOB(client, DOB);


	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Set the first and last name
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 * @param fname
	 *           first name
	 * 
	 * @param lname
	 *           last name
	 * 
	 */

	public void setFirstAndLastName(Client client, String fname, String lname) {
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField']", 0,
				fname);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField']", 1,
				lname);
		client.closeKeyboard();

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Select The DateOfBirth from Application Calendar for Create an account
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 * @param DOB
	 *            set the Date Of Birth
	 * 
	 * 
	 */

	public void enterDOB(Client client, String DOB) {
		clickDOB(client);
		client.elementSetProperty("NATIVE",
				"xpath=//*[@class='UIDatePicker' and @hidden='false']", 0,
				"date", DOB);
		waitFor(client,1);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Click on DOB
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 */
	public void clickDOB(Client client) {
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);
	}


	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Click on Sign In button
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param click
	 *            true to click
	 *            
	 */

	public void clickSignInButton(Client client, boolean click) {
		if (click) {
			client.waitForElement("NATIVE",
					"xpath=//*[@accessibilityIdentifier='Freestyle_logo']", 0,
					1000);
			client.click("NATIVE",
					"text=Already have a LibreView account? Sign In", 0, 1);
			client.waitForElement("NATIVE",
					"xpath=//*[@accessibilityLabel='Sign In']", 0, 10000);

		} else {
			client.verifyElementFound("NATIVE",
					"text=Already have a LibreView account? Sign In", 0);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Sign In functionality
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param Email
	 *            sending email id
	 *            
	 * @param Pwd
	 *            sending  password
	 *            
	 * @param clickSignIn
	 *            clicking on SignIn if it is true
	 *            
	 */

	public void signInClick(Client client, String Email, String Pwd,
			boolean clickSignIn) {
		client.verifyElementFound("NATIVE",
				"text=Please enter your LibreView account login.", 0);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField']", 0, Email);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField']", 1, Pwd);
		client.closeKeyboard();

		if (clickSignIn) {		
			submitSignIn(client);	
		}
	}

	public void submitSignIn(Client client) {
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='SIGN IN']", 0, 1);
		waitForProgress(client);
		if (client.isElementFound("NATIVE",
				"xpath=//*[@text and @accessibilityLabel='OK']", 0)) {
			clickOnButtonOption(client, "OK", true);

		}
		waitForProgress(client);
	}

	/**
	 * Author: Amaresh
	 * 
	 * click and Accept Terms of Use /Privacy Notice page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param page
	 *            terms of use or privacy notice page
	 *            
	 */

	public void clickAndAcceptPage (Client client, String page) {
		waitForProgress(client);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @knownSuperClass='UILabel']",
				0, 3000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @knownSuperClass='UILabel']",
				0, 1);
		waitFor(client,1);
		client.waitForElement("NATIVE",
				"xpath=//*[@text='I have read and explicitly accept the "
						+ page + ".']", 0, 5000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @class='LibreLink.LLDialogButton']",
				0, 1);
		waitFor(client,2);

	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Swipe Target Glucose Range
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param indexNo
	 *            Index value of glucose
	 * 
	 * @param range
	 *            low/high glucose range [0/1]
	 *            
	 */

	public void swipeTargetGlucose(Client client, int indexNo, int range) {
		client.runNativeAPICall("NATIVE",
				"xpath=//*[@class='UIPickerColumnView']", range,
				"invokeMethod:'{\"selector\":\"selectRow:animated:notify:\",\"arguments\":[\""
						+ indexNo + "\", \"true\", \"true\"]}'");
		waitFor(client,1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Close Running Browser
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void closeRunningBrowser(Client client) {
		String browser = client.getCurrentApplicationName();
		waitFor(client, 5);
		client.applicationClose(browser);
		waitFor(client, 5);

	}

	/**
	 * Author: Amaresh
	 *
	 * Method to Enter the static time
	 *
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param hours
	 *			hours to be set
	 *
	 * @param minutes
	 *			minutes to be set
	 * @throws ParseException 
	 * 		Throws ParseException on setting date/time
	 *
	 */

	public void enterStaticTime(Client client, int hours,
			int minutes) throws ParseException {
		String scanTime = client.elementGetText("NATIVE",
				"xpath=//*[@class='UIButtonLabel' and contains(@text,':')]", 0);
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + scanTime
				+ "' and @class='UIButton']", 0, 1);
		client.waitForElement("NATIVE", "text=Select Scan Time:", 0, 5000);
		String time = hours+":"+minutes;
		if (getLanguage().contains("U.K.")
				&& getCountryCode().contains("United Kingdom")) {

			setHourandTimeforUKFormat(client, time);

		}else {
			client.elementSetProperty("NATIVE",
					"xpath=//*[@class='UIDatePicker' and @hidden='false']", 0,
					"time", hours + "." + minutes);
		}

		waitFor(client, 2);
		client.click("NATIVE", "accessibilityLabel=OK", 0, 1);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Load Data File From SAS DB using Mock mode
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param sasmode
	 *            Selecting SASMode from Device Debug_sas_mode(Mock1/Mock2)
	 *            
	 * @param folder
	 *          selecting folder name(ADC/ OR Autodated/)           
	 *            
	 * @param jsonfile
	 *            Selecting jsonfile from DataSet list
	 * 
	 */

	public void loadTestData(Client client, String sasmode, String folder,
			String jsonfile) {
		debugDrawerClearData(client);
		openDebugDrawer(client);
		client.waitForElement("NATIVE",
				"accessibilityIdentifier=ScanBannerDownArrow", 0, 10000);
		client.click("NATIVE", "accessibilityIdentifier=ScanBannerDownArrow",
				0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@text='Select SAS mode:' and @onScreen='true']", 0,
				2000);
		client.click("NATIVE", "xpath=//*[@text='" + sasmode
				+ "' and @onScreen='true']", 0, 1);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='Edit_Icon' and @onScreen='true']",
				0, 2000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='Edit_Icon' and @onScreen='true']",
				0, 1);
		if (folder!=null){
			client.click("NATIVE", "xpath=//*[@text='"+folder+"/']", 0, 1);
			waitFor(client, 2);

		}
		client.elementSwipeWhileNotFound(
				"NATIVE",
				"xpath=//*[@class='UIView' and ./*[@text='Set Mock Data File']]",
				"Down", 400, 1800, "NATIVE", "xpath=//*[@text='" + jsonfile
				+ "' and @onScreen='true']", 0, 500, 10, false);
		waitFor(client,2);
		client.click("NATIVE", "xpath=//*[@text='" + jsonfile+ "']", 0, 1);
		client.waitForElementToVanish("NATIVE", "xpath=//*[@accessibilityLabel='LibreLink Debug' and @onScreen='true']", 0, 30000);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click On number of Days Data
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param noOfDays
	 *            Number of days Data
	 * 
	 */

	public void clickOnDays(Client client, int noOfDays) {

		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment" + noOfDays
				+ "Days']", 0);
		client.click("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment" + noOfDays
				+ "Days']", 0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment" + noOfDays
				+ "Days' and @backgroundColor='0xE0E0E0']", 0);
		waitFor(client,1);

	}



	/**
	 * Author: Amaresh/Nagaraju
	 * 
	 * Method to Verify default settings
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param Units
	 *            units
	 */
	public void defaultSettings(Client client, String Units) {
		verifyPageTitles(client,"Unit of Measurement");	
		clickOnButtonOption(client, "NEXT", true);
		verifyPageTitles(client,"Target Glucose Range");	
		clickOnButtonOption(client, "NEXT", true);
		verifyPageTitles(client,"Carbohydrate Units");
		if (Units.equals("grams")) {
			client.click("NATIVE", "text=grams", 0, 1);
		} else {
			client.click("NATIVE", "text=${servings}", 0, 1);
		}
		clickOnButtonOption(client, "DONE", true);
		verifyPageTitles(client,"Welcome!");	
		clickOnButtonOption(client, "NEXT", true);
		verifyPageTitles(client,"My Glucose");	
		clickOnButtonOption(client, "NEXT", true);
		client.verifyElementFound("NATIVE", "text=${backgroundGlucoseColorsTitle}", 0);	
		clickOnButtonOption(client, "NEXT", true);
		verifyPageTitles(client,"Glucose Trend Arrow");	
		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			clickOnButtonOption(client, "NEXT", true);
			verifyPageTitles(client,"Treatment Decisions");	
			clickOnButtonOption(client, "NEXT", true);
			verifyPageTitles(client,"Treatment Decisions");	
		}
		clickOnButtonOption(client, "DONE", true);
		waitForProgress(client);
	}	

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set TargetGlucose Range
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 * @param low
	 *            Set Target Glucose Low Range
	 * 
	 * @param high
	 *            Set Target Glucose high Range
	 * 
	 */

	public void setTargetGlucoseRange(Client client, double low, double high) {
		int lowindexvalue =0;
		int highindexvalue=0;
		lowindexvalue = findTGIndex(low,0);
		highindexvalue = findTGIndex(high,1);

		swipeTargetGlucose(client, lowindexvalue, 0);
		swipeTargetGlucose(client, highindexvalue, 1);

		Assert.assertEquals(low, findTargetGlucose(client, 0),0.0);
		Assert.assertEquals(high, findTargetGlucose(client, 1),0.0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Target glucose range value
	 * 
	 *         
	 * @param tgValue
	 *            Target Glucose Value
	 * 
	 * @param range
	 *            Target Glucose Range
	 * @return index
	 * 		Return the index value
	 */

	public int findTGIndex(double tgValue, int range) {
		int index =0;

		if(range==0){
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				index =  (int) (tgValue - 70);
			} else {
				tgValue = tgValue*10;
				System.out.println("tgValue:"+tgValue);
				index = (int)(tgValue - 39);
			}
		} else if(range==1){
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				index = (int) (tgValue - 71);
			} else {
				tgValue = tgValue*10;
				System.out.println("tgValue:"+tgValue);
				index =(int)(tgValue - 40);
			}
		}

		System.out.println("Int:"+index);

		return index;
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Target glucose range value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param low
	 *            Target Glucose Low Range
	 * 
	 * @param high
	 *            Target Glucose high Range
	 * @return verifyTG
	 * 		return true/false for TG validation
	 */

	public boolean verifyTargetGlucoseRange(Client client, double low,
			double high) {

		String lowValue,highValue;
		boolean alreadySet = false;
		if(getUnits().contains("mg")){
			lowValue = (int)low+"";
			highValue = (int)high+"";
		}else{
			lowValue = low+"";
			highValue = high+"";
		}
		System.out.println("'" + lowValue + " - " + highValue + " " + getUnits() + "'");
		if (client.isElementFound("NATIVE", "text=" + lowValue + " - " + highValue + " "
				+ getUnits(), 0)) {

			alreadySet = true;
		}

		return alreadySet;

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method ot Verify and if required Set TargetGlucose Range from Settings
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param low
	 *            Set Target Glucose Low Range
	 * 
	 * @param high
	 *            Set Target Glucose high Range
	 * 
	 */

	public void verifyandsetTGfromSettings(Client client, double low, double high) {
		boolean alreadyTGSet = verifyTargetGlucoseRange(client, low, high);
		if (!alreadyTGSet) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityLabel='Target Glucose Range']", 0,
					1);
			waitFor(client,1);
			setTargetGlucoseRange(client, low, high);
			waitFor(client,1);
			clickOnButtonOption(client, "SAVE", true);
			verifyTargetGlucoseRange(client, low, high);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click clear data in debug drawer
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void debugDrawerClearData(Client client) {
		openDebugDrawer(client);
		client.waitForElement("NATIVE",
				"xpath=//*[@text='CLEAR DATA' and @onScreen='true']", 0, 10000);
		client.click("NATIVE",
				"xpath=//*[@text='CLEAR DATA' and @onScreen='true']", 0, 1);
		waitFor(client,2);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Change Language and region in Device
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 */
	public void changeLanguageAndRegioninDevice(Client client) {
		changeLanguageinDevice(client,getLanguage());
		changeRegioninDevice(client);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Change Language in Device
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 */
	public void openSettings(Client client) {
		waitFor(client,2);
		client.launch("com.apple.Preferences", true, true);
		waitFor(client,5);
		client.waitForElement("NATIVE",
				"xpath=//*[@text='Settings' and @class='UIAView' and ./parent::*[@text='Settings']]", 0, 10000);
		if(!client.isElementFound("NATIVE", "xpath=//*[@text='Settings' and @class='UIAView' and ./parent::*[@text='Settings']]", 0)){
			closePhoneSettings(client);
			waitFor(client,2);
			client.launch("com.apple.Preferences", true, false);
			waitFor(client,5);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to search in Device settings 
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param searchKeyword    
	 *         search keyword name
	 */
	public void searchInSettings(Client client, String searchKeyword) {
		if(!client.isElementFound("NATIVE",
				"xpath=//*[@XCElementType='XCUIElementTypeSearchField']",0)){
			client.elementSwipeWhileNotFound(
					"NATIVE",
					"xpath=//*[@class='UIATable']",
					"Up",
					550,
					1000,
					"NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeSearchField']",
					0, 1000, 2, false);
			waitFor(client,2);
		}
		client.click("NATIVE",
				"xpath=//*[@knownSuperClass='UISearchBarTextField']",
				0, 1);
		client.elementSendText(
				"NATIVE",
				"xpath=//*[@knownSuperClass='UISearchBarTextField']",
				0, searchKeyword);
		waitFor(client,1);
		client.click("NATIVE",
				"xpath=//*[@XCElementType='XCUIElementTypeStaticText' and @knownSuperClass='UITableViewLabel' and @x>0]",
				0, 1);
		waitFor(client,2);
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Open Sub Options in Settings
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param subOption
	 *           Set and Navigate to Sub Option
	 */
	public void openSubOptionsInSettings(Client client, String subOption) {
		openSettings(client);
		if(!client.isElementFound("NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'"+subOption+"') and @XCElementType='XCUIElementTypeNavigationBar']",
				0)){
			searchInSettings(client,subOption);
		}
	}



	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Change Language in Device
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *            
	 * @param tobeSetLanguage
	 *          set the language            
	 */
	public void changeLanguageinDevice(Client client, String tobeSetLanguage) {
		openSubOptionsInSettings(client,"Language ");
		waitFor(client,1);
		client.click("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeCell']", 0, 1);
		waitFor(client,1);
		String language = client.elementGetText("NATIVE", "xpath=//*[@class='UIAStaticText' and ./following-sibling::*[@class='UIAButton']]", 0);

		if (!(language.equals(tobeSetLanguage))) {
			waitFor(client, 2);
			System.out.println("=========="+tobeSetLanguage);
			client.elementSendText(
					"NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeSearchField' and @class='UIATextField']",
					0, tobeSetLanguage);
			client.waitForElement("NATIVE", "xpath=//*[@text='" + tobeSetLanguage
					+ "']", 0, 10000);
			client.click("NATIVE", "xpath=//*[@text='" + tobeSetLanguage + "']", 0,
					1);
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@class='UIAButton' and @label='Done']", 0, 1);		


			if(client.isElementFound("NATIVE", "xpath=//*[@class='UIAButton' and @label='Continue']",0)){
				client.click("NATIVE", "xpath=//*[@class='UIAButton' and @label='Continue']", 0, 1);
			}else{
				client.waitForElement("NATIVE", "xpath=//*[@class='UIAView' and @height>0 and ./parent::*[@class='UIAView' and ./parent::*[./parent::*[./preceding-sibling::*[@class='UIAView']]]] and ./*[@class='UIAButton']]", 0, 10000);
				client.click("NATIVE", "xpath=//*[@class='UIAView' and @height>0 and ./parent::*[@class='UIAView' and ./parent::*[./parent::*[./preceding-sibling::*[@class='UIAView']]]] and ./*[@class='UIAButton']]", 0, 1);
			}
			waitFor(client,3);
			closePhoneSettings(client);
			waitFor(client,12);
			client.closeDevice();
			client.openDevice();

		}
		else{
			client.click("NATIVE", "xpath=//*[@class='UIAButton']", 0, 1);//CANCEL button
			closePhoneSettings(client);
		}


		System.out.println("*************Language Changed !!! *************");
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Change Region in Device
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 */
	public void changeRegioninDevice(Client client) {
		openSubOptionsInSettings(client,"Language ");
		String region = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@XCElementType='XCUIElementTypeStaticText' and @class='UIAStaticText' and ./preceding-sibling::*[@text='Region']]",
						0);
		String tobeSetRegion = getCountryCode();
		if(tobeSetRegion.contains("Germany")&& getUnits().contains("mg")){
			tobeSetRegion = "United States";
		}else if(tobeSetRegion.contains("Germany")&& getUnits().contains("mmol")){
			tobeSetRegion = "United Kingdom";

		}
		if (!tobeSetRegion.equals(region)) {
			client.click(
					"NATIVE",
					"xpath=//*[@text='Region' and @XCElementType='XCUIElementTypeCell']",
					0, 1);
			client.waitForElement("NATIVE",
					"xpath=//*[@value='Search' and @text='Search']", 0, 10000);
			client.elementSendText(
					"NATIVE",
					"xpath=//*[@text='Search' and @XCElementType='XCUIElementTypeSearchField']",
					0, tobeSetRegion);
			client.waitForElement("NATIVE",
					"xpath=//*[@text='" + tobeSetRegion + "']", 0, 10000);
			client.click("NATIVE", "xpath=//*[@text='" + tobeSetRegion + "']", 0, 1);
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@class='UIAButton' and @label='Done']", 0, 1);
			if(client.isElementFound("NATIVE", "xpath=//*[@class='UIAButton' and @label='Continue']",0)){
				client.click("NATIVE", "xpath=//*[@class='UIAButton' and @label='Continue']", 0, 1);
			}else{
				client.waitForElement("NATIVE", "xpath=//*[@name='Change to "
						+ getLanguage() + "']", 0, 10000);
				client.click("NATIVE", "xpath=//*[c@name='Change to " + getLanguage()
				+ "']", 0, 1);
			}
			waitFor(client,3);
			closePhoneSettings(client);
			waitFor(client,12);
			client.closeDevice();
			client.openDevice();

			if(client.isElementFound("NATIVE", "text=OK",0)){
				client.click("NATIVE", "text=OK", 0, 1);
			}

		}else{
			client.click("NATIVE", "xpath=//*[@class='UIAButton']", 0, 1);//CANCEL button
			closePhoneSettings(client);
		}

		System.out.println("*************Region Changed !!! *************");

	}

	/**
	 * Author: Amaresh
	 *
	 * Method to Set Default Target glucose range
	 *
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void cleanUpForTG(Client client)  {
		navigateToScreen(client, "Settings");
		if (getUnits().equals("mg/dL")) {
			verifyandsetTGfromSettings(client, 100, 140);
		} else if (getUnits().equals("mmol/L")) {
			verifyandsetTGfromSettings(client, 5.6, 7.8);
		}
		navigateToScreen(client, "Home");
	}

	/**
	 * Author: Amaresh
	 * 
	 * Set Time Zone in Device settings
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param zone
	 *            Set Zone
	 */
	public void changeTimeZone(Client client, String zone) {
		openDateTimeSettings(client);
		automaticDateAndTime(client, false);

		client.waitForElement("NATIVE", "xpath=//*[@value='Time Zone']", 0,
				10000);
		String str0 = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='UIAStaticText' and ./preceding-sibling::*[@text='Time Zone']]",
						0);

		if (!str0.equals(zone)) {

			client.click(
					"NATIVE",
					"xpath=//*[@class='UIAStaticText' and ./preceding-sibling::*[@text='Time Zone']]",
					0, 1);
			client.sleep(2000);
			client.waitForElement("NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeSearchField']",
					0, 10000);
			client.click("NATIVE", "xpath=//*[@text='Clear text']", 0, 1);
			client.elementSendText("NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeSearchField']",
					0, zone);
			client.waitForElement("NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeStaticText' and contains(@text,'"
							+ zone + ",')]", 0, 1000);
			client.click("NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeStaticText' and contains(@text,'"
							+ zone + ",')]", 0, 1);
			client.sleep(2000);
		}
		closePhoneSettings(client);
		System.out.println("*************Time Zone Changed !!! *************");

	}

	/**
	 * Author: Amaresh
	 *
	 * Method to Click on Calendar
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 */
	public void clickCalendar(Client client) {
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='CalendarIcon']",
				0, 1);
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to get the Device date
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @throws ParseException
	 * 		Throws parse exception for setting date
	 * @return date
	 * 		Returns device date
	 */
	public Date getDeviceDate(Client client) throws ParseException {

		String systemDateTime = client.getDeviceProperty("device.time");
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = ft.parse(systemDateTime);
		ft.applyPattern("EEE MMM d HH:mm:ss z yyyy");
		System.out.println(date);
		return date;

	}

	/**
	 * Author: ShabinaSherif
	 *
	 * Method ot Get the date format
	 *
	 * @param dateString
	 *        set the date for dateformat
	 *         
	 * @throws ParseException
	 * 			Throws Parse exception for date selection
	 * @return date
	 * 		Returns the date
	 */
	public Date getDateFormat(String dateString) throws ParseException {

		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
		Date date = ft.parse(dateString);
		ft.applyPattern("EEE MMM d HH:mm:ss z yyyy");
		System.out.println(date);
		return date;

	}

	/**
	 * Author: Amaresh
	 *
	 *  Method to Picks the selected date in calendar
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 * @param date
	 *            check current date
	 * @throws ParseException
	 * 			Throws Parse exception for date selection
	 */
	public void pickDate(Client client, Date date) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy");
		String monthTitle = dateFormat.format(date);
		SimpleDateFormat dayformat = new SimpleDateFormat("dd");
		int day = Integer.parseInt(dayformat.format(date));
		String appCalendarDate = client.elementGetText("NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and @enabled='true']", 0);
		DateFormat appFormat;
		String dateSelected = null;

		String direction = "up";


		if (getLanguage().contains("U.S.")) {
			appFormat = new SimpleDateFormat("MMMMM d, yyyy");
			dateSelected = appFormat.format(date);

			if (appFormat.parse(appCalendarDate).before(date)) {

				direction = "down";
			}

		} else if (getLanguage().contains("U.K.")) {
			appFormat = new SimpleDateFormat("d MMMMM yyyy");
			dateSelected = appFormat.format(date);
			if (appFormat.parse(appCalendarDate).before(date)) {

				direction = "down";
			}

		}

		if(!client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0)){
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UICollectionView']", direction, 300, 1000, "NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0, 0, 3, false);
		}else{
			if(!client.isFoundIn("NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0, "Down", "NATIVE", "xpath=//*[@text='"+day+"']", 0, 0))
				client.elementSwipe("NATIVE", "xpath=//*[@class='UICollectionView']", 0, direction, 300, 1000);
			waitFor(client,1);
		}
		client.clickIn("NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0, "Down", "NATIVE", "xpath=//*[@text='"+day+"']", 0, 0, 0, 1);
		client.waitForElementToVanish("NATIVE", "xpath=//*[@class='UICollectionView']", 0, 3000);
		if(!client.isElementFound("NATIVE", "xpath=//*[@class='UICollectionView']", 0)){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+dateSelected+"']", 0);
		}
	}

	/**
	 * Author: ShabinaSherif
	 *
	 * Method to Verify previous date is displayed
	 *
	 * @param client
	 *         Integrate SeeTestAutomation 
	 *
	 * @param date
	 *            check current date
	 *            
	 * @throws ParseException
	 * 		Throws parse exception for date selection
	 */
	public void verifyPickedDateIsDisplayed(Client client, Date date)
			throws ParseException {
		if (getLanguage().contains("English (U.S.)")) {
			DateFormat deviceFormat = new SimpleDateFormat("MMMMM d, yyyy");
			String appDate = deviceFormat.format(date);
			client.verifyElementFound("NATIVE", "xpath=//*[@text = '" + appDate
					+ "']", 0);

		} else if (getLanguage().contains("English (U.K.)")) {
			DateFormat deviceFormat = new SimpleDateFormat("d MMMMM yyyy");
			String appDate = deviceFormat.format(date);
			client.verifyElementFound("NATIVE", "xpath=//*[@text = '" + appDate
					+ "']", 0);
		} 
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method to Navigate To MyGlucose Page
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * 
	 */
	public void navigateToMyGlucosePage(Client client) {

		if (!(client.isElementFound("NATIVE",
				"xpath=//*[@text='My Glucose' and ./parent::*[@class='_UINavigationBarContentView']]", 0))) {
			openDebugDrawer(client);
			client.click(
					"Native",
					"xpath=//*[@accessibilityLabel='MY GLUCOSE' and @onScreen='true']",
					0, 1);
			waitFor(client,1);
		}
	}


	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method to Verify GlucoseValue and Units in My Glucose
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param glucoseValue
	 *           set the Scanned glucose value
	 */
	public void verifyGlucoseValueandUnitsMyGlucose(Client client,
			String glucoseValue) {
		client.waitForElement("NATIVE","xpath=//*[@accessibilityLabel='My Glucose']", 0, 1000);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"
				+ glucoseValue + "']", 0);
		if (!(glucoseValue.equals("HI") || glucoseValue.equals("LO"))) {
			client.verifyElementFound("NATIVE", "xpath=//*[@text='"
					+ getUnits() + "']", 0);
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to click on the Notes or Timezone in the  graph
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param element
	 *            notes/timezone/realtime glucose
	 * @param index
	 * 				position of the element in the graph
	 */
	public void clickOnNotesorTimeZoneorBG(Client client, String element, int index) {
		String cordinatesValue = null;
		cordinatesValue = client.runNativeAPICall("NATIVE", "xpath=//*[@class='LibreLink.LLLineChartView']", 0, "invokeMethod:'{\"selector\":\""+element+":\",\"arguments\":[\""+index+"\"]}'");
		cordinatesValue = cordinatesValue.substring(1, cordinatesValue.length()-1);
		cordinatesValue =cordinatesValue.replace("NSPoint:", "").replace("{", "").replace("}", "");
		cordinatesValue =cordinatesValue.replace(" ","");
		System.out.println("========="+cordinatesValue);
		String cordinates[] = cordinatesValue.split(",");
		int x=(int)Math.round(Double.parseDouble(cordinates[0]));
		int y=(int)Math.round(Double.parseDouble(cordinates[1]));

		String width[] = client.getAllValues("NATIVE", "class=LibreLink.LLLineChartView", "width");
		String height[] = client.getAllValues("NATIVE", "class=LibreLink.LLLineChartView", "height");

		int widx = Integer.parseInt(width[0]);
		int hgty = Integer.parseInt(height[0]);
		String deviceModel = client.getDeviceProperty("device.model");
		if(deviceModel.contains("+")||deviceModel.contains("iPhone X")){
			x = (-(widx/2)+(3*x));
			y = (-(hgty/2)+(3*y));
		}else{
			x = (-(widx/2)+(2*x));
			y = (-(hgty/2)+(2*y));
		}

		client.click("NATIVE", "xpath=//*[@class='LibreLink.LLLineChartView']", 0, 1, x, y);
		waitFor(client, 2);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Get Zone Time As GMT format
	 * 
	 * @param zone
	 *            Set the Zone
	 * @return timezoneValue
	 * 		Returns time zone value
	 */
	public String getTimeZoneValue(String zone) {
		String timeZoneString;
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		Date date = c.getTime();
		TimeZone tz = TimeZone.getTimeZone(zone);
		long hours = TimeUnit.MILLISECONDS.toHours(tz.getRawOffset());
		long minutes = TimeUnit.MILLISECONDS.toMinutes(tz.getRawOffset())
				- TimeUnit.HOURS.toMinutes(hours);
		minutes = Math.abs(minutes);
		if (tz.inDaylightTime(date)) {
			hours = hours + 1;
		}

		if (hours > 0) {
			timeZoneString = String.format("GMT+%s:%02d", hours, minutes);
		} else {

			timeZoneString = String.format("GMT%s:%02d", hours, minutes);
		}

		timeZoneString = timeZoneString.replace(":00", "");
		return timeZoneString;
	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 *  Method to Click Back button From MyGlucose page
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void clickBackFromMyGlucose(Client client) {
		if(client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='My Glucose']", 0)){
			clickOnBackIcon(client);
		}		
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify LogBook Detail Page for Insulin Note
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *           
	 * @param insulinType
	 *            set the insulin type
	 *            
	 * @param insulinUnit
	 *            set the insulin Units
	 */

	public void verifyInsulinLogBookDetailPage(Client client,
			String insulinType, String insulinUnit) {
		if (insulinUnit.equals("none")) {
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 2000, "NATIVE", "xpath=//*[@text='"
					+ insulinType + "-Acting Insulin' and @top='true']", 0, 1000, 5, true);

			client.verifyElementFound("NATIVE", "xpath=//*[@text='"
					+ insulinType + "-Acting Insulin' and @top='true']", 0);

		} else {
			if ((insulinUnit.equals("1"))) {
				client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 2000, "NATIVE", "xpath=//*[@text='"
						+ insulinType
						+ "-Acting Insulin (1 unit)' and @top='true']", 0, 1000, 5, true);

				client.verifyElementFound("NATIVE", "xpath=//*[@text='"
						+ insulinType
						+ "-Acting Insulin (1 unit)' and @top='true']", 0);

			} else {
				client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 2000, "NATIVE", "xpath=//*[@text='"
						+ insulinType + "-Acting Insulin (" + insulinUnit
						+ " units)' and @top='true']", 0, 1000, 5, true);

				client.verifyElementFound("NATIVE", "xpath=//*[@text='"
						+ insulinType + "-Acting Insulin (" + insulinUnit
						+ " units)' and @top='true']", 0);

			}
		}

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click on Created Note
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param notetimeorValue
	 *            set the notetime or Value
	 */
	public void clickCreatedNote(Client client, String notetimeorValue) {
		waitFor(client, 3);
		if (getLanguage().contains("U.K.") && (notetimeorValue.contains("AM")||notetimeorValue.contains("PM"))) {
			notetimeorValue = notetimeorValue.toLowerCase();
		}
		if(!client.isElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'" + notetimeorValue+"') and @accessibilityIdentifier='LogbookTableCell' and @top='true']", 0)){
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @backgroundColor='0xF2F4F5' and @onScreen='true']", "Down", 0, 2000, "NATIVE", "xpath=//*[contains(@accessibilityLabel,'" + notetimeorValue+"') and @accessibilityIdentifier='LogbookTableCell']", 0, 1000, 5, false);
		}		
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + notetimeorValue
				+ "']", 0, 1);
		waitFor(client,2);
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to Click On Calendar Date On Application Calendar
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickOnCalendarDate(Client client) {
		if (client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0)) {
			client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0, 1);
			waitForProgress(client);
			waitFor(client,2);
		}

	}


	/**
	 * Author: ShabinaSherif
	 *
	 * Method to Get the date format
	 *
	 * @param noOfdayFromCurrent
	 *           date from current day
	 *           
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 * @return Date
	 * 		Returns the date in right format
	 */
	public Date getDateFormatFromPastNoOfDays(int noOfdayFromCurrent) throws ParseException {

		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DAY_OF_YEAR, noOfdayFromCurrent);
		Date dateBefore = cal.getTime();
		System.out.println(dateBefore);
		return dateBefore;

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Food in LogBook Detail Page
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 * @param mealType
	 *            set the meal type(breakfast/lunch/dinner/snack)
	 *            
	 * @param carbUnit
	 *            set the carbohydrate units
	 *            
	 * @param carbAmount
	 *            set the Amount of Carbohydrates
	 */
	public void verifyFoodInLogBookDetailPage(Client client, String mealType,
			String carbUnit, String carbAmount) {
		if (carbUnit.equals("grams")) {
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 500, "NATIVE", "xpath=//*[@text='" + mealType+ " (" + carbAmount + " g)']", 0, 1000, 5, false);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='" + mealType
					+ " (" + carbAmount + " g)']", 0);


		} else if (carbUnit.equals("servings") || carbUnit.equals("portions")) {
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 500, "NATIVE", "xpath=//*[@text='" + mealType
					+ " (" + carbAmount + "'+text=${servingsSymbol}+')']", 0, 1000, 5, false);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='" + mealType
					+ " (" + carbAmount + "'+text=${servingsSymbol}+')']", 0);

		}
	}


	public void verifyLogBookDetailPageNotesContent(Client client, String content){
		client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 500, "NATIVE", "xpath=//*[contains(@text,'" +content + "')]", 0, 1000, 5, false);
		client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'" +content + "')]", 0);	
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Exercise Note with Intensity with set time on LogBook Detail Page
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 * @param intensity
	 *            set intensity
	 * @param hr
	 *            set hour
	 * @param min
	 *            set minute
	 */
	public void verifyExerciseIntensityInLogBookDetailPage(Client client,
			String intensity, int hr, int min) {
		String value=getLangPropValue("exercise");
		String hoursContent = "";
		String minsContent = "";
		if(intensity!=null){
			value = value+" "+intensity+" Intensity";
			if(hr==0){
				hoursContent = "";
			}
			else if(hr==1){
				hoursContent = getLangPropValue("hours_one");
				value = value+" ("+hoursContent;
			}else{
				hoursContent = getLangPropValue("hours_other").replace("%1$d", Integer.toString(hr));
				value = value+" ("+hoursContent;
			}
			if(min==0){
				minsContent = "";
				if(hr!=0){
					value = value+")";
				}
			}
			else if(min==1){
				minsContent = getLangPropValue("minutes_one");
				if(hr!=0){
					value = value+" "+minsContent+")";
				}else{
					value = value+" ("+minsContent+")";
				}
			}else{
				minsContent = getLangPropValue("minutes_other").replace("%1$d", Integer.toString(min));
				if(hr!=0){
					value = value+" "+minsContent+")";
				}else{
					value = value+" ("+minsContent+")";
				}
			}
		}

		client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.LogbookNoteCell']]", "Down", 0, 500, "NATIVE", "xpath=//*[contains(@text,'" +value + "')]", 0, 1000, 5, false);
		client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'" +value + "')]", 0);	
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Carbohydrate Options
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyCarbohydrateOptions(Client client) {
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${grams}']]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${servings}']]", 0); 
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Click on Edit Icon Button
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void clickEditConfIcon(Client client) {
		client.click("NATIVE", "accessibilityIdentifier=Edit_Icon", 0, 1);
		waitFor(client, 1);
		client.verifyElementFound("NATIVE", "accessibilityLabel=Edit Sensor Config", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to verify food entry
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param mealType
	 *            set the meal type(breakfast/lunch/dinner/snack)
	 *            
	 * @param carbUnit
	 *            set the carbohydrate units
	 *            
	 * @param carbAmount
	 *            set the Amount of Carbohydrates
	 */
	public void verifyFoodEntry(Client client, String mealType,
			String carbUnit, String carbAmount) {
		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + mealType
				+ "' and @top='true']", 0);
		if (carbUnit.equals("grams")) {
			client.verifyIn("NATIVE", "xpath=//*[@text='" + carbAmount
					+ "' and @class='UITextField']", 0, "Right", "NATIVE",
					"text=${gramsOfCarbs}", 0, 0);
		} else {
			client.verifyIn("NATIVE", "xpath=//*[@text='" + carbAmount
					+ "' and @class='UITextField']", 0, "Right", "NATIVE",
					"text=${servingsOfCarbs}", 0, 0);

		}

	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Scroll To Bottom of Add Note Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void scrollToBottomAddNotePage(Client client) {
		client.sleep(2000);
		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[@class='UITableView' and ./*[@class='LibreLink.AddNoteTableCell']]",
				0,
				"invokeMethod:'{\"selector\":\"pl_scrollToBottom:\",\"arguments\":[\"true\"]}'");
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method for Unselect Note Attribute
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param attribute
	 *  	   set the Attribute
	 * 
	 */
	public void selectNoteAttribute(Client client, String attribute) {
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
						+ attribute + "']]", 0);
		try{
			String option = client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='"
									+ attribute + "']]", 0,
							"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
			if (option.equalsIgnoreCase("0")) {
				client.click(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
								+ attribute + "']]", 0, 1);
			}
		}catch(Exception e){
			client.click(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
							+ attribute + "']]", 0, 1);

		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click and Set food Attribute
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param foodType
	 *           Enter the Food Type
	 *           
	 * @param value
	 *         Enter value of carbohydrates
	 */

	public void clickAndSetFoodAttribute(Client client, String foodType,
			String value) {
		selectNoteAttribute(client, "Food");
		waitFor(client, 2);
		if(foodType!=null){
			if(!client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.AddNoteChoicesTableCell' and @hidden='false' and ./*[./*[@accessibilityLabel='"+foodType+"']]]", 0)){
				client.click(
						"NATIVE",
						"xpath=//*[@class='LibreLink.AddNoteDropdownTableCell' and @hidden='false']",0, 1);

				waitFor(client, 1);
			}
			client.click("NATIVE", "xpath=//*[@text='" + foodType
					+ "' and @visible='true']", 0, 1);
			waitFor(client, 1);
		}

		client.elementSendText(
				"NATIVE",
				"xpath=//*[@class='UITextField' and ./following-sibling::*[contains (@text,'of carbs')]]",
				0, value);

		client.closeKeyboard();

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Get the Calendar date
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *            
	 * @throws ParseException
	 * 				Throws Parse exception on settings date
	 * @return date
	 * 		Return date in string format
	 */
	public String getCalendarDate(Client client) throws ParseException {
		String systemDateTime = client.elementGetText("NATIVE",
				"xpath=//*[@class='UILabel' and @textColor='0xFFFFFF']", 0);
		SimpleDateFormat deviceFormat = new SimpleDateFormat("MMMMM d, yyyy");
		if (getLanguage().contains("English (U.K.)")) {
			deviceFormat = new SimpleDateFormat("d MMMMM yyyy");
		}
		Date d = deviceFormat.parse(systemDateTime);
		deviceFormat.applyPattern("dd.MM.yyyy");
		String devicedate = deviceFormat.format(d);
		return devicedate;

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set LogBook Time
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 * @param date
	 *            Set the date
	 *            
	 * @param logbookTime
	 *            Set the logbookTime
	 *            
	 * @throws ParseException
	 *			Throws parse exception on settings date
	 */
	public void setLogBookTime(Client client, String date, String logbookTime) throws ParseException  {
		String time = null;

		if (getLanguage().contains("U.K.")) {

			if (client.isElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='am']", 0) || client.isElementFound("NATIVE",
							"xpath=//*[@accessibilityLabel='AM']", 0)) {

				String _24HourTime = logbookTime.replace(".", ":");
				SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
				SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh.mm a");
				Date _24HourDt = _24HourSDF.parse(_24HourTime);

				String time1 = _12HourSDF.format(_24HourDt).toLowerCase();
				time = date + " " + time1;

			} 

			else {
				time = date + " " + logbookTime;
			}

		} else {
			time = date + " " + logbookTime;
		}

		client.elementSetProperty("NATIVE", "xpath=//*[@class='UIDatePicker']",
				0, "datetime", time);

		client.click("NATIVE", "xpath=//*[@class='_UIButtonBarButton']", 1, 1);
		waitFor(client, 2);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set time for UK region
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 * @param time
	 *            Set the time
	 *            
	 * @throws ParseException
	 *			Throws parse exception on settings date
	 */
	public void setHourandTimeforUKFormat(Client client, String time) throws ParseException{
		SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
		SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh:mm a");
		Date _24Hour = _24HourSDF.parse(time);

		String _12Hour = _12HourSDF.format(_24Hour);
		String[] time1 = _12Hour.split(":");
		if(!time1[0].contains("00")&&!time1[0].contains("10")){
			time1[0] = time1[0].replace("0", "");
		}
		System.out.println(_24Hour);
		System.out.println(_12Hour);
		System.out.println(time1[0]);
		System.out.println(time1[1]);
		String[] time2 = time1[1].split(" ");
		client.elementSetProperty(
				"NATIVE",
				"xpath=//*[@class='UIDatePicker' and @hidden='false']",
				0, "text", time2[0] + ",1");
		client.elementSetProperty(
				"NATIVE",
				"xpath=//*[@class='UIDatePicker' and @hidden='false']",
				0, "text", time1[0] + ",0");
		client.elementSetProperty(
				"NATIVE",
				"xpath=//*[@class='UIDatePicker' and @hidden='false']",
				0, "text", time2[1]+",2");
	}

	/**
	 * Author: Amaresh
	 * 
	 *  Method to Create New Note
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 * @param date
	 *        set the date for new Note
	 *        
	 * @param time
	 *         set the time for new Note
	 *         
	 * @throws ParseException
	 * 			Throws Parse exception on setting date
	 */
	public void createNewNote(Client client, String date, String time) throws ParseException {
		clickAddNote(client);
		setLogBookTime(client, date, time);

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 *   Method to Verify Glucose Units
	 *   
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void verifyGlucoseUnits(Client client) {
		waitFor(client, 2);
		client.verifyElementFound("NATIVE", "partial_text="+getUnits(), 0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify LastScan In HomePage
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param value
	 *         Sending the Scan value
	 */

	public void verifyLastScanInHomePage(Client client,String value) {
		client.waitForElement("NATIVE","xpath=//*[@text='LAST 24 HOURS' and @onScreen='true']", 0, 10000);
		if (value.equals("HI") || value.equals("LO")) {
			client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+ value +"') and ./preceding-sibling::*[@accessibilityLabel='LAST SCAN']]", 0);
		} else {	
			client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+ value +" "+getUnits()+"') and ./preceding-sibling::*[@accessibilityLabel='LAST SCAN']]",0);
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to verify Timezone Change details
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyTimezoneChangeDetailsFromCstToPst(Client client) {
		waitFor(client,1);
		System.out.println("==========="+getCstformat());
		System.out.println("==========="+getPstformat());
		System.out.println("==========="+getTimeZoneValue(LibrelinkConstants.US));
		System.out.println("==========="+getTimeZoneValue(LibrelinkConstants.CST));
		if (!getLanguage().contains("English (U.K.)")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getCstformat()+" to "+getPstformat()+" (-2h)']",
					0);
		} else {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getTimeZoneValue(LibrelinkConstants.CST)+" to "+getTimeZoneValue(LibrelinkConstants.US)+" (-2h)']", 0);
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to verify Timezone Change details
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyTimezoneChangeDetailsFromPstToAkdt(Client client) {
		client.sleep(1000);

		if (!getLanguage().contains("United Kingdom")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getPstformat()+" to "+getAkdtformat()+" (-1h)']",
					0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getAkdtformat()+" to "+getPstformat()+" (1h)']",
					0);
		} else {

			client.verifyElementFound("NATIVE","xpath=//*[@text='Time zone change from GMT-8 to GMT-7 (1h)']",	0);
			client.verifyElementFound("NATIVE","xpath=//*[@text='Time zone change from GMT-7 to GMT-8 (-1h)']",	0);

		}

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method for Calculate and enter details in "Edit Sensor Config" dialog box
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *                       
	 * @param days
	 *            add or decrease date
	 * @param hours
	 *            add or decrease hours
	 * @param minutes
	 *            add or decrease minutes
	 * @param sensorType
	 * 				10 day or 14 day sensor
	 * @throws ParseException 
	 * 			Throws Parse Exception for settings date/time
	 */
	
	public void editConfiguration(Client client, int days, int hours, int minutes,String sensorType) throws ParseException {
		openDebugDrawer(client);
		clickEditConfIcon(client);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Calendar cal = Calendar.getInstance();
		String activationTime = client.elementGetText("NATIVE",
				"xpath=//*[@class='UIButtonLabel' and contains(@accessibilityLabel,':')]", 0);
		String activationDate = client.elementGetText("NATIVE",
				"xpath=//*[@class='UIButtonLabel' and contains(@accessibilityLabel,'-')]", 0);
		String[] date = activationDate.split("-");
		int x = Integer.parseInt(activationTime.substring(0, 2));
		int y = Integer.parseInt(activationTime.substring(3));
		int a = Integer.parseInt(date[0]);
		int b = Integer.parseInt(date[1]);
		int c = Integer.parseInt(date[2]);
		cal.set(Calendar.YEAR, a);
		cal.set(Calendar.MONTH, b-1);
		cal.set(Calendar.DATE, c);
		cal.set(Calendar.HOUR_OF_DAY, x);
		cal.set(Calendar.MINUTE, y);
		cal.set(Calendar.SECOND, 0);
		cal.add(Calendar.DAY_OF_MONTH, days);
		cal.add(Calendar.HOUR, hours);
		cal.add(Calendar.MINUTE, minutes);

		String dateTime = dateFormat.format(cal.getTime());
		String inputActivationDate = dateTime.replace("/", "-");
		String Date = inputActivationDate.substring(0, 10);
		String time = inputActivationDate.substring(11, 16);
		System.out.println(Date);
		String inputDate[] = Date.split("-");
		System.out.println(time);
		String inputTime[]= time.split(":");

		if(!activationDate.equals(Date)){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='"+activationDate+"' and @class='UIButton']", 0, 1);
			client.waitForElement("NATIVE", "accessibilityLabel=Select Activation Date:", 0, 5000);
			client.elementSetProperty("NATIVE",
					"xpath=//*[@class='UIDatePicker' and @hidden='false']", 0,
					"date", inputDate[2] + "." + inputDate[1] + "." + inputDate[0]);
			waitFor(client, 2);
			client.click("NATIVE", "accessibilityLabel=OK", 0, 1);
			client.verifyElementFound("NATIVE", "text="+Date, 0);

		}
		if(!activationTime.equals(time)){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='"+activationTime+"' and @class='UIButton']", 0, 1);
			client.waitForElement("NATIVE", "accessibilityLabel=Select Activation Time:", 0, 5000);
			if (getLanguage().contains("U.K.")
					&& getCountryCode().contains("United Kingdom")) {
				setHourandTimeforUKFormat(client, time);

			} else {
				client.elementSetProperty("NATIVE",
						"xpath=//*[@class='UIDatePicker' and @hidden='false']",
						0, "time", inputTime[0] + "." + inputTime[1]);
			}
			waitFor(client, 2);
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK' and @tag='0']", 0, 1);
			System.out.println("======Time======="+time);
			client.verifyElementFound("NATIVE", "text="+time, 0);
		}

		  String selectedSensor = client.elementGetText("NATIVE", "xpath=//*[@class='UIButtonLabel' and contains(@accessibilityLabel,'/')]", 0);
		  if(!sensorType.equals(selectedSensor)){
				client.click("NATIVE", "xpath=//*[@accessibilityLabel='"+selectedSensor+"' and @class='UIButton']", 0, 1);
				client.waitForElement("NATIVE", "accessibilityLabel=Sensor Type:", 0, 5000);
				client.click("NATIVE", "xpath=//*[@accessibilityLabel='"+sensorType+"' and @class='UITableViewLabel']", 0, 1);
		  }
		
		waitFor(client, 1);
		clickOnButtonOption(client, "OK", true);
		closeDebugDrawer(client);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify the get started button
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param click
	 *            click if it is true
	 *            
	 */

	public void getStarted(Client client, boolean click) {		
		if (click) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityLabel='GET STARTED NOW']", 0, 1);
			client.waitForElement("NATIVE", "text=${countryOfOriginTitle}", 0, 1000);

		} else  {
			client.verifyElementFound("NATIVE", "accessibilityLabel=GET STARTED NOW", 0);
		}
	}


	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Confirm Country Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyConfirmCountryPage(Client client) {
		client.waitForElement("NATIVE", "text=Confirm Country", 0, 1000);
		client.verifyElementFound("NATIVE", "text=Confirm Country", 0);
	}



	/**
	 * Author: Lourde Noel Rini 
	 * 
	 * Method to Verify Terms of Page and Privacy Policy page details
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param page
	 *            Verify the page title
	 * 
	 */

	public void verifyTermsAndPolicyPageDetails(Client client, String page) {
		waitFor(client,3);
		try{
			client.runNativeAPICall(
					"NATIVE",
					"xpath=//*[contains(@class,'ScrollView')]",
					0,
					"invokeMethod:'{\"selector\":\"pu_scrollToEdge:animated:\",\"arguments\":[\"1\", \"true\"]}'");
		}catch(Exception e){
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[contains(@class,'ScrollView')]", "Up", 0, 
					2000, "NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='false']", 0, 1000, 10, false);
		}
		waitFor(client,1);
		verifyPageTitles(client, page);

		verifyButtonStatus(client, "REJECT", false);
		verifyButtonStatus(client, "ACCEPT", true);

	}


	/**
	 * Author: Lourde Noel Rini 
	 * 
	 * Method to Verify Terms of Page and Privacy Policy page details
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param page
	 *            Verify the page title
	 *            
	 * @param clickCheckbox
	 *            true/false
	 * 
	 */

	public void clickCheckBox(Client client,String page, boolean clickCheckbox) {
		verifyPageTitles(client, page);
		if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']", 0)){
			
				client.runNativeAPICall(
						"NATIVE",
						"xpath=//*[contains(@class,'ScrollView')]",
						0,
						"invokeMethod:'{\"selector\":\"pu_scrollToEdge:animated:\",\"arguments\":[\"3\", \"true\"]}'");
			if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']", 0)){
				client.swipeWhileNotFound("Down", 250, 500, "NATIVE", "xpath=//*[@class='UIView' and ./descendant::*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']]", 0, 1000, 50, false);
			}
			waitFor(client,2);
		}
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']", 0);

		if (clickCheckbox) {

			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']",
					0, 1);

			clickOnButtonOption(client, "ACCEPT", true);
			waitFor(client,1);

		} else {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@text='I have read and explicitly accept the "
							+ page + ".' and @onScreen='true']", 0);
		}
	}



	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method to Verify GetStartedNow and SignIn
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyGetStartedNowandSignIn(Client client) {
		client.verifyElementFound("NATIVE", "text=GET STARTED NOW", 0);
		client.verifyElementFound("NATIVE",
				"text=Already have a LibreView account? Sign In", 0);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Librelink Tour page
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param page
	 *            select the page to verify
	 *            
	 */

	public void verifyAppTourScreens(Client client, int page) {
		if (page == 2) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='TourAppIntro2']", 0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='You can check your glucose with your smartphone.']",
					0);

		} else if (page == 3) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='TourAppIntro3']", 0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='You can have quick access to your glucose information.']",
					0);

		} else if (page == 4) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='TourAppIntro4']", 0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='You can gain insights to help you make more informed decisions.']",
					0);

		} else if (page == 5) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='TourAppIntro5']", 0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='You can share your glucose information with your health care professional and loved ones.']",
					0);

		}
		verifyGetStartedNowandSignIn(client);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Swipe right Librelink welcome page
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 */

	public void swipeWelcomescreen(Client client) {
		client.elementSwipe("NATIVE",
				"xpath=//*[@class='LibreLink.FirstTourCollectionViewCell']", 0,
				"Right", 100, 2000);
		waitFor(client,2);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Librelink Welcome page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void librelinkWelcomePage(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityIdentifier='Freestyle_logo']", 0, 5000);
		verifyGetStartedNowandSignIn(client);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=Sensor", 0);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify create account Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyCreateAccountScreen(Client client) {
		waitFor(client,1);
		client.verifyElementFound("NATIVE", "text=Create New Account", 0);
		client.verifyElementFound("NATIVE",
				"text=${sensorUserPrompt}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='First Name']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Last Name']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Date of Birth']", 0);
		verifyButtonStatus(client, "NEXT", false);
	}

	/**
	 * Author: NagarajuKasarla/Amaresh
	 * 
	 * Method to Select Long insulin and set Glucose value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 * @param value
	 *            set the glucose value
	 */

	public void addNoteForLongActingInsulin(Client client, String value) {
		selectNoteAttribute(client, "Long-Acting Insulin");
		String food = client.runNativeAPICall("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='Food']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");

		String RapidActingInsulin = client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='Rapid-Acting Insulin']]",
						0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
		if (food.equals("1")&&RapidActingInsulin.equals("1")) {
			client.elementSendText(
					"NATIVE",
					"xpath=//*[@class='_UITextFieldContentView' and @top='true']",
					2, value);
			client.verifyElementFound("NATIVE", "accessibilityLabel=units", 1);
		} else if (food.equals("1")&&RapidActingInsulin.equals("0")||food.equals("0")&&RapidActingInsulin.equals("1")) {
			client.elementSendText(
					"NATIVE",
					"xpath=//*[@class='_UITextFieldContentView' and @top='true']",
					1, value);
			client.verifyElementFound("NATIVE", "accessibilityLabel=units", 0);
		}else{
			client.elementSendText(
					"NATIVE",
					"xpath=//*[@class='_UITextFieldContentView' and @top='true']",
					0, value);
			client.verifyElementFound("NATIVE", "accessibilityLabel=units", 0);
		}

		client.closeKeyboard();
		waitFor(client, 1);
	}

	/**
	 * Author: NagarajuKasarla/Amaresh
	 * 
	 * Method to Select Long insulin and set Glucose value
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 * @param value
	 *            set the glucose value
	 */

	public void addNoteForRapidActingInsulin(Client client, String value) {
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		String food = client.runNativeAPICall("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='Food']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
		if (food.equalsIgnoreCase("1")) {
			client.elementSendText("NATIVE",
					"xpath=//*[@class='_UITextFieldContentView' and @top='true']",
					1, value);

		}else{
			client.elementSendText("NATIVE",
					"xpath=//*[@class='_UITextFieldContentView' and @top='true']",
					0, value);
		}

		client.verifyElementFound("NATIVE", "accessibilityLabel=units", 0);
		client.closeKeyboard();
		waitFor(client, 1);
	}

	/**
	 * Author: NagarajuKasarla/AMaresh
	 * 
	 * Method to Select Exercise type and set the Hours and minutes
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param intensity
	 *            set the require intensity
	 * @param hrs
	 *            set the hours
	 * @param mins
	 *            set the minutes
	 */

	public void addNoteForExercise(Client client, String intensity, int hrs,
			int mins) {
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		if(intensity!=null){
			if(!client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.AddNoteChoicesTableCell' and @hidden='false' and ./*[./*[@accessibilityLabel='Low Intensity']]]", 0)){
				client.clickIn(
						"NATIVE",
						"xpath=//*[@class='UILabel' and @top='true' and (contains (@text,'Intensity'))]",
						0, "Right", "NATIVE",
						"xpath=//*[@accessibilityIdentifier='DownCaret']", 0, 0, 0, 1);
				client.waitForElement("NATIVE", "accessibilityLabel=" + intensity, 0,
						10000);
			}
			client.click("NATIVE", "accessibilityLabel=" + intensity, 0, 1);
		}
		scrollToBottomAddNotePage(client);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='DownCaret' and ./preceding-sibling::*[contains(@accessibilityLabel,'min')]]",
				0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Edit Time']", 0, 10000);
		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[@class='UIPickerView']",
				0,
				"invokeMethod:'{\"selector\":\"selectRow:inColumn:animated:\",\"arguments\":[\""
						+ hrs + "\", \"0\", \"true\"]}'");

		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[@class='UIPickerColumnView' and ./*[./*[./*[./*[./*]]]]]",
				0,
				"invokeMethod:'{\"selector\":\"selectRow:animated:notify:\",\"arguments\":[\""
						+ mins + "\", \"true\", \"true\"]}'");

		client.click("NATIVE", "accessibilityLabel=Done", 0, 1);
		waitFor(client,1);

	}

	/**
	 * Author: NagarajuKasar
	 * 
	 * Method to click on Add Note in MyGlucose Screen
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation    
	 */

	public void clickAddNoteInMyGlucose(Client client) {
		waitFor(client, 3);
		client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='editblue']", 0, 1);
		waitFor(client, 1);
	}


	/**
	 * Author: NagarajuKasar
	 * 
	 * Method to verify  Note Pop-Up Details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation 
	 *         
	 * @param attributes 
	 *        sending attributes(food/rapid/long/exercise) for verification
	 *        
	 */

	public void verifyNotePopUpDetails(Client client, String attributes) {
		if(attributes.contains("svg")&&getUnits().contains("mmol/L")){ 
			attributes=attributes.replace("svg", "ptn");
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+attributes+"']", 0);
		}else{
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+attributes+"']", 0);
		}

	}

	/**
	 * Author: NagarajuKasar
	 * 
	 * Method to Verify time in Note Pop-Up
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation 
	 *         
	 * @param time 
	 *        sending time for verification
	 *        
	 * @param present
	 *        if it's true then verify Note found       
	 */

	public void verifyTimeInNotePopUp(Client client,String time,boolean present) {
		if (!getLanguage().equals("English (U.S.)")) {
			time=time.toLowerCase();
		}
		waitFor(client, 1);
		if(present){
			client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@accessibilityLabel='EditIconLarger' and ./preceding-sibling::*[@accessibilityLabel='"+ time +"']]]", 0);
		}else{
			client.verifyElementNotFound("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@accessibilityLabel='EditIconLarger' and ./preceding-sibling::*[@accessibilityLabel='"+ time +"']]]", 0);

		}
		waitFor(client, 1);
	}			
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify US Specific HomeScreen
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation    
	 */

	public void verifyHomePageDetails(Client client){
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SliderMenuIcon']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Apply a new Sensor. The Sensor should only be applied to the back of your upper arm.']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='NewSensorApply']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='HOW TO APPLY A SENSOR']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='BlueQuestion']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='HOW TO APPLY A SENSOR']", 0);
	}


	/**
	 * Author: LourdeNoelRini
	 * 
	 *  Click Alert (i) icon
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void clickAlertIcon(Client client) {
		navigateToMyGlucosePage(client);
		waitFor(client, 1);
		client.click("NATIVE",
                "xpath=//*[@accessibilityIdentifier='light_event_warning' and @onScreen='true']", 0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@class='_UITextContainerView' and @top='true']", 0,
				1000);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Click and verify Check Glucose Reminder
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void clickSetCheckGlucoseReminder(Client client) {
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='SET' and @class='LibreLink.LLDialogButton']",
				0, 1);
		client.waitForElement("NATIVE", "accessibilityLabel=Add Reminder", 0,
				2000);
		client.verifyElementFound("NATIVE", "accessibilityLabel=Add Reminder",
				0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * select Low Reminder Time
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param value
	 *            click time
	 */
	public void selectLowReminderTime(Client client, int value) {
		client.click("NATIVE", "text=" + value + " mins", 0, 1);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value
				+ " mins' and @top='true']", 0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify CheckGlucose Reminder Countdown
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param time
	 *            reminder time to verify
	 */
	public void verifyCheckGlucoseReminderCountdown(Client client, String time) {		
		client.verifyElementFound("NATIVE", "text=Check Glucose", 0);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and contains(@text,'Next Reminder:  " + time + "20, Check Glucose')]",
				0, 40000);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='LibreLink.RegularLabel' and contains(@text,'Next Reminder:  " + time + "20, Check Glucose')]", 0);

		String t1 = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='UILabel' and ./preceding-sibling::*[@accessibilityLabel='Check Glucose']]",
						0);
		waitFor(client,5);
		String t2 = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='UILabel' and ./preceding-sibling::*[@accessibilityLabel='Check Glucose']]",
						0);
		String t3 = t2.substring(0, t2.length() - 2);
		String newtime=time.substring(0,time.length()-2);


		if (!t1.equals(t2)) {
			Assert.assertTrue(t3.contains(newtime));

			System.out
			.println("Check Glucose TIMERS reminder displayed a countdown timer which started from "
					+ t3 + "XX");
		}

	}


	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify Timer Expired Notification
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void verifyTimerExpiredNotification(Client client) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='NotificationShortLookView' and contains(@value,'Timer Expired')]", 0, 240000);
		waitFor(client,2);
		openNotification(client);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'LIBRELINK,')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Timer Expired')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Check Glucose')]", 0);
	}


	/**
	 * Author: Meenakshi
	 * 
	 * Set values from build config file
	 * 
	 * @param fileName
	 *            Filename
	 * @param SheetName
	 *            SheetName in the file
	 * @param countryKeyCode
	 *            country code
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */

	public ArrayList<ArrayList<Object>>  ReadExcelData(String fileName,String SheetName,String countryKeyCode) throws IOException, ParserConfigurationException, SAXException
	{	
		int column = 0, rowCount;
		FileInputStream inputStream = new FileInputStream(new File(fileName));
		ArrayList<ArrayList<Object>> list = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> singleRows = new ArrayList<Object>();

		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet firstSheet = workbook.getSheet(SheetName);
		Iterator<Row> iterator = firstSheet.iterator();
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Iterator<Cell> cellIterator = nextRow.cellIterator();

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();

				String Key = cell.getStringCellValue();
				for ( rowCount = firstSheet.getFirstRowNum();rowCount<=firstSheet.getLastRowNum();rowCount++)
				{
					if(Key.equalsIgnoreCase(countryKeyCode))
					{	 

						for(column = 1; column<nextRow.getPhysicalNumberOfCells();column++)
						{
							while (cellIterator.hasNext()) {
								Cell cell1 = cellIterator.next();
								if (cell1.getCellTypeEnum() == CellType.STRING)
								{
									System.out.print("cell1.getStringCellValue()"+cell1.getStringCellValue()+"\t");
									singleRows.add(cell1.getStringCellValue());
								}

								else if(cell1.getCellTypeEnum() ==CellType.BOOLEAN)      
								{
									System.out.print(cell1.getBooleanCellValue()+"\t");
									singleRows.add(cell1.getBooleanCellValue());
								}
								else if(cell1.getCellTypeEnum() ==CellType.NUMERIC)
								{
									System.out.print(cell1.getNumericCellValue()+"\t");
									singleRows.add(cell1.getNumericCellValue());
								}
							}
						}
					}

					list.add(singleRows);

				}

			}
		}
		workbook.close();
		inputStream.close();

		return list;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to display not applicable screenshot
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void showNotApplicableScreenShot(Client client, String message){
		waitFor(client,1);
		client.setShowReport(true);
		client.report(getProperty("user.dir") + "\\Reports\\notapplicable_snapshot.PNG",message, true);
		client.setShowReport(false);
		waitFor(client,1);
	}
	
	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify My Glucose Info Page
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param verifyNext
	 * 			Verify if NEXT button is present true/false
	 */

	public void verifyMyGlucoseInfoPage(Client client, boolean verifyNext) {
		
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=my_glucose_overview_mg" , 0);
		}else{
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=my_glucose_overview_mmol" , 0);
		}
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("myGlucoseExplanationUpdate"),0);
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("myGlucoseExplanationTitle"),0);
		if(verifyNext){
		verifyButtonStatus(client, "NEXT", true);
		}
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify Glucose Trend arrow Page Contents
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 * @param verifyNext
	 * 			Verify if NEXT button is present true/false
	 */

	public void verifyGlucoseTrendArrow(Client client,boolean verifyNext) {
	
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("trendExplanationTopText"),0);
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("trendExplanationTitle"),0);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseRisingQuicklyArrow", 0);
		client.verifyElementFound("NATIVE", "text=Rising quickly", 0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseRisingArrow", 0);
		client.verifyElementFound("NATIVE", "text=Rising", 0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseChangingSlowlyArrow", 0);
		client.verifyElementFound("NATIVE", "text=Changing slowly",
				0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseFallingArrow", 0);
		client.verifyElementFound("NATIVE", "text=Falling", 0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseFallingQuicklyArrow", 0);
		client.verifyElementFound("NATIVE", "text=Falling quickly", 0);
		if(verifyNext){
			if (getNAIconConfig().equalsIgnoreCase("yes")) {
				verifyButtonStatus(client, "NEXT", true);
			}else{
				verifyButtonStatus(client, "DONE", true);
			}
			}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Welcome screen
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 *
	 * */
	public void verifyWelcomeScreen(Client client){
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=Freestyle_logo", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Welcome!' and @backgroundColor='0x000000']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Welcome!']", 1);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Take a few moments to learn how to understand your glucose readings with this app.']", 0);
		verifyButtonStatus(client, "NEXT", true);
	}
	
	/**
	 * Author: ShabinaSherif 
	 * 
	 * verify safety information
	 *         
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	public void verifySafetyInfo(Client client){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='SAFETY INFORMATION']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='BlueQuestion']", 0);
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='SAFETY INFORMATION']", 0,1);
			waitFor(client,2);
			waitForProgress(client);
			waitFor(client,10);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Safety Information' and @class='UILabel']", 0);
		
	}
	
	/**
	 * Author: Meenakshi
	 *
	 * Method to Click on back icon on Webview
	 *
	 * @param client
	 *         Integrate SeeTestAutomation
	 */
	
	public void clickOnBackIconWebView(Client client) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='_UIButtonBarButton' and @onScreen='true']",
				0, 5000);
		client.click(
				"NATIVE",
				"xpath=//*[@class='_UIButtonBarButton' and @onScreen='true']",
				0, 1);

		waitFor(client,2);

	}
	

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Glucose Screen Background color
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param verifyNext
	 * 			Verify if NEXT button is present true/false
	 */
	
	public void verifyGlucoseBackgroundColor(Client client,boolean verifyNext) {
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("backgroundGlucoseColorsDetail"),0);
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("backgroundGlucoseColorsTitle"),0);
		if(getUnits().contains("mg/dL")){
			client.verifyElementFound("NATIVE", "text=${glucoseHighAbove240Mgdl}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseBetweenTarget240Mgdl}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseTargetRange}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseBetweenTarget70Mgdl}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseLowBelow70Mgdl}", 0);
		}else{
			client.verifyElementFound("NATIVE", "text=${glucoseHighAbove240Mmol}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseBetweenTarget240Mmol}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseTargetRange}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseBetweenTarget70Mmol}", 0);
			client.verifyElementFound("NATIVE", "text=${glucoseLowBelow70Mmol}", 0);
		}
		if(verifyNext){
			verifyButtonStatus(client, "NEXT", true);
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Treatment Decision Screen 1
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param verifyNext
	 * 			Verify if NEXT button is present true/false
	 * */
	
	public void verifyTreatmentDecisionScreen1(Client client,boolean verifyNext) {
		
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=treatment_decisions_step_5_mgdl" , 0);
		}else{
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=treatment_decisions_step_5_mmol" , 0);
		}
		
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("treatmentDecisionsSymbol"),0);
		client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("treatmentDecisions"),0);
		if(verifyNext){
			verifyButtonStatus(client, "NEXT", true);
			}
	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Treatment Decision Screen 2
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param verifyNext
	 * 			Verify if NEXT button is present true/false
	 * */
	
	public void verifyTreatmentDecisionScreen2(Client client,boolean verifyNext) {
		
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='treatment_decisions_step_6']" , 0);
			client.verifyElementFound("NATIVE","partial_text="+getLangPropValue("treatmentDecisionsTest"),0);
			client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'"+getLangPropValue("treatmentDecisions")+"')]",0);
		if(verifyNext){
			verifyButtonStatus(client, "DONE", true);
			}
	}
	

	/**
	 * Author: Amaresh
	 * 
	 * navigate To AppSettings SubMenu Screens
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param subscreen
	 *          App settings sub menu screen name
	 * 
	 * @param click
	 * 			true/false
	 */
	
	public void verifyandClickHelpSubMenu(Client client,
			String subscreen, boolean click) {
		if(click){
		client.waitForElement("NATIVE", "text=" + subscreen, 0, 1000);
		client.click("NATIVE", "text=" + subscreen, 0, 1);
		}
		else{
			client.waitForElement("NATIVE", "text=" + subscreen, 0, 5000);
			client.verifyElementFound("NATIVE", "text=" + subscreen, 0);
		}
		

	}


	/**
	 * Author: Amaresh
	 * 
	 * Verify How to Apply new sensor link
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param click
	 * 			true/false
	 * 
	 */
	
	public void verifyHowToApplyNewSensorLink(Client client, boolean click) {
		if (click){
			client.waitForElement("NATIVE", "xpath=//*[contains(@text,'Apply a new Sensor')]", 0, 1000);
			client.click(
					"NATIVE",
					"xpath=//*[@text='HOW TO APPLY A SENSOR' and @textColor='0x059EEC']",
					0,1);}
		else{
		
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Apply a new Sensor')]", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='HOW TO APPLY A SENSOR' and @textColor='0x059EEC']",
				0);
		}
		
	}
	

	/**
	 * Author: Amaresh
	 * 
	 * Verify How to scan a new sensor link
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param click
	 * 			true/false
	 * 
	 */
	
	public void verifyHowToScanNewSensorLink(Client client, boolean click) {
		if (click)
		{
			client.waitForElement("NATIVE", "text=SCAN NEW SENSOR", 0, 1000);
			client.click(
					"NATIVE",
					"xpath=//*[@text='HOW TO SCAN A SENSOR' and @textColor='0x059EEC']",
					0,1);
		}else{
		client.verifyElementFound("NATIVE", "text=SCAN NEW SENSOR", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='HOW TO SCAN A SENSOR' and @textColor='0x059EEC']",
				0);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * verify safety information
	 *         
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	public void verifySafetyInformation(Client client) {	
		waitFor(client,2);
		waitForProgress(client);
		waitFor(client,10);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Safety Information' and @class='UILabel']", 0);
		
	}
	
	
	/**
	 * Author: ShabinaSherif 
	 * 
	 * verify user's manual Guide
	 *         
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	public void verifyQuickReferenceGuide(Client client) {	
		waitFor(client,2);
		waitForProgress(client);
		waitFor(client,10);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Quick Reference Guide' and @class='UILabel']", 0);
		
	}

	
	/**
	 * Author: ShabinaSherif 
	 * 
	 * verify quick start guide
	 *         
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	public void verifyQuickStartGuide(Client client) {	
		waitFor(client,2);
		waitForProgress(client);
		waitFor(client,10);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Quick Start Guide' and @class='UILabel']", 0);
		
	}
	
	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify About Information
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 */
	
	public void verifyAboutInfo(Client client) {
		if(getAboutInfo().contains("yes")){
			client.verifyElementFound("NATIVE", "xpath=//*[@text='Part of the FreeStyle Libre Flash Glucose Monitoring System' and @top='true']", 0);
		}else{
			client.verifyElementNotFound("NATIVE", "xpath=//*[@text='Part of the FreeStyle Libre Flash Glucose Monitoring System' and @top='true']", 0);
		}
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='FreeStyle LibreLink']", 0);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify the links are in order
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	
	public void verifyHelpLinksInOrder(Client client, String link, String order) {
		String ylink1 = client.elementGetProperty("NATIVE", "xpath=//*[@accessibilityLabel='User’s Manual']", 0, "y");
		String ylink2 = client.elementGetProperty("NATIVE", "xpath=//*[@accessibilityLabel='"+link+"']", 0, "y");
		if(order.contains("above")){
			Assert.assertTrue(Integer.parseInt(ylink1)>Integer.parseInt(ylink2));
		}else{
			Assert.assertTrue(Integer.parseInt(ylink1)<Integer.parseInt(ylink2));
		}
		
	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Set servings value
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param val
	 *            value of grams
	 *            
	 */

	public void setServingsValue(Client client, double val) {
		String direction=null;
		String existingValue = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and ../parent::*[@class='LibreLink.ServingSizeTableCell']]", 0);
		String[] value = existingValue.split("=");
		existingValue = value[1].substring(0, 3);
		double gramValue = Double.parseDouble(existingValue);
		if(val==gramValue){
			direction=null;
		}else if(val==10.0 || val<gramValue){
			direction="Right";
		}else if(val==15.0 || val>gramValue){
			direction="Left";
		}
		if(direction!=null){
		if(val==10.0 || val==15.0){
			
			for(int i=0; i<12;i++){
				client.elementSwipe("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UISlider']]", 0, direction, 0, 500);
				existingValue = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and ../parent::*[@class='LibreLink.ServingSizeTableCell']]", 0);
				value = existingValue.split("=");
				existingValue = value[1].substring(0, 3);
				gramValue = Double.parseDouble(existingValue);
				if(val==gramValue){
					break;
				}
			}
		}else{
			client.elementSwipe("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UISlider']]", 0, direction, 0, 500);
		}
		}
		
	}	
}
