package com.abbott.project37375iOS.main;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import org.junit.Test;



public class Sample{
	
	 public static final String SRC = "C:\\DVTiOS_2.1\\project37375iOS\\Reports\\reports\\PreRequisite\\United States\\2018-02-12_151606\\test0\\index.pdf";
	 public static final String DEST = "C:\\DVTiOS_2.1\\project37375iOS\\Reports\\reports\\PreRequisite\\United States\\2018-02-12_151606\\test0\\PreRequisite.pdf";
	    
	@Test
	public void sample() throws IOException, DocumentException{
	        File file = new File(DEST);
		        file.getParentFile().mkdirs();
		        new Sample().manipulatePdf(SRC, DEST);
		}
	
	 public void manipulatePdf(String src, String dest) throws IOException, DocumentException {
		 PdfReader reader = new PdfReader(src);
	        int n = reader.getNumberOfPages();
	        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
	        
	        PdfContentByte pagecontent;
	        for (int i = 0; i < n; ) {
	            pagecontent = stamper.getOverContent(++i);
	            float x = reader.getPageSize(i).getRight(100);
		        float y = reader.getPageSize(i).getBottom(100);
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
	                    new Phrase(String.format("Page %s of %s", i, n)), x,y, 0);
	          }
	     //  BaseHelper bs=new BaseHelper();
	        for (int i = 0; i < n; ) {
	            pagecontent = stamper.getOverContent(++i);
	            float x = reader.getPageSize(i).getWidth() / 2;
		        float y = reader.getPageSize(i).getBottom(100);
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
	                    new Phrase(String.format("TD")), x,y, 0);
	          }
	        for (int i = 0; i < n; ) {
	            pagecontent = stamper.getOverContent(++i);
	            float x = reader.getPageSize(i).getLeft(100);
		        float y = reader.getPageSize(i).getBottom(100);
	            ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
	            		new Phrase(String.format("DOC39066-001 Step ID: 1208")), x,y, 0);
	          }
	        stamper.close();
	        reader.close();
	    }
}
