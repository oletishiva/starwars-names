package com.abbott.project37375iOS.uigeneral;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;

import com.abbott.project37375iOS.main.BaseHelper;
import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.experitest.client.Client;
import com.experitest.client.InternalException;

public class GeneralReleaseBaseHelper extends BaseHelper {

	
	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Page title gets displayed
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param title
	 *            Enter page title
	 *            
	 */
	@Override
	public void verifyPageTitles(Client client, String title) {
		client.verifyElementFound("NATIVE", "text=${" + title+"}", 0);
	}
	
	/**
	 * Author: Amaresh/Shabina
	 * 
	 * Method to Navigate To Screen
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param Screen
	 *            Navigate to Reports
	 * 
	 */

	@Override
	public void navigateToScreen(Client client, String Screen) {
		clickOnMenu(client);
		waitFor(client,1);
		client.runNativeAPICall("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.MenuTableCell']]", 0, "invokeMethod:'{\"selector\":\"pl_scrollToTop:\",\"arguments\":[\"true\"]}'");
		if (Screen.equalsIgnoreCase("home")) {
			client.elementSwipeWhileNotFound(
					"NATIVE",
					"xpath=//*[@class='UITableView' and @backgroundColor='0xF2F4F5' and @onScreen='true']",
					"Up", 100, 1000, "NATIVE", "xpath=//*[@text='${"
							+ Screen + "}']", 0, 1000, 5,
							false);
		}
		else
		{
		client.elementSwipeWhileNotFound(
				"NATIVE",
				"xpath=//*[@class='UITableView' and @backgroundColor='0xF2F4F5' and @onScreen='true']",
				"Down", 100, 1000, "NATIVE", "xpath=//*[@text='${"
						+ Screen + "}']", 0, 1000, 5,
						false);}
		waitFor(client,2);
		client.click("NATIVE", "xpath=//*[@text='${"+Screen+"}' and @class='LibreLink.RegularLabel']", 0, 1);
		waitFor(client,1);
		if (Screen.equalsIgnoreCase("home")) {
				client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo']",
					0);
		} else if (Screen.equalsIgnoreCase("logbook")
				|| Screen.equalsIgnoreCase("reminders") || Screen.equalsIgnoreCase("help")
				|| Screen.contains("settings") || Screen.equalsIgnoreCase("about")) {
			verifyPageTitles(client, Screen);
		} else {
			client.verifyElementFound("NATIVE","text="+ getLangPropValue(Screen).toUpperCase(),	0);

		}
	}
	

	/**
	 * Author: Amaresh
	 * 
	 * Swipe on report
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param direction
	 * 		Provide the direction to swipe
	 */

	public void swipeOnReport(Client client, String direction) {
		client.elementSwipe("NATIVE",
				"xpath=//*[@class='LibreLink.ReportCollectionViewCell' and @hidden='false']", 0,
				direction, 100, 500);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Librelink Application Tour Screens
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param pageId
	 *            Set the page to verify
	 * @param pageno
	 * 			page no to be verified           
	 */

	public void verifyAppTourScreens(Client client, int pageno, String pageId) {
		if(pageno==1){
			client.waitForElement("NATIVE",
					"xpath=//*[@accessibilityIdentifier='Freestyle_logo']", 0, 5000);
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=Sensor", 0);

		}else{
			String identifier = "TourAppIntro"+pageno;
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='"+identifier+"']", 0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='"+getLangPropValue(pageId)+"']",
					0);
		}
		client.verifyElementFound("NATIVE", "text="+getLangPropValue("getStartedNow").toUpperCase(), 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+getLangPropValue("alreadyHaveAccountPromptText")+"')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+getLangPropValue("account_sign_in_title")+"')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIPageControl']", 0);
		Assert.assertEquals("0x000000", client.elementGetProperty("NATIVE", "xpath=//*[@class='UIView' and ./parent::*[@class='UIPageControl']]", pageno-1, "backgroundColor"));
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Confirm Country Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	@Override
	public void verifyConfirmCountryPage(Client client) {
		client.verifyElementFound("NATIVE", "text=${countryOfOriginTitle}", 0);
		client.verifyElementFound("NATIVE", "text=${countryOfOriginTopText}", 0);
		client.verifyElementFound("NATIVE", "text=${countryOfOriginExplanation}", 0);
		client.verifyElementFound("NATIVE", "text=${countryLabelForSetup}", 0);
		client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);
		verifyButtonStatus(client, "next", true);

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Verify button status
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param option
	 *            NEXT, OK, SAVE , CANCEL , SUBMIT, ACCEPT, REJECT Buttons
	 *            
	 * @param enable
	 *           true/false
	 *           
	 */
	@Override
	public void verifyButtonStatus(Client client, String option, boolean enable) {

		option = getLangPropValue(option).toUpperCase();
		if (enable) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='" + option
					+ "' and @text='" + option
					+ "' and @textColor='0xFFFFFF']", 0);

		} else {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='" + option
					+ "' and @text='" + option
					+ "']", 0);

		}
		waitFor(client, 1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Click on Next or Save or Ok or Cancel Buttons
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param option
	 *            NEXT, OK, SAVE , CANCEL , SUBMIT, ACCEPT, REJECT, Radio Options like Grams and Servings
	 *            
	 * @param click
	 *          true/false
	 *          
	 */
	@Override
	public void clickOnButtonOption(Client client, String option,
			boolean click) {
		option = getLangPropValue(option).toUpperCase();
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='" + option
				+ "' and @knownSuperClass='UIButton' and @onScreen='true']", 0);
		if (click){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + option
					+ "' and  @knownSuperClass='UIButton' and @onScreen='true']", 0,
					1);
		}
		waitFor(client,1);
		waitForProgress(client);

	}

	/**
	 * Author: Lourde Noel Rini 
	 * 
	 * Method to Verify Terms of Use and Privacy Policy page details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param page
	 *            Verify the page title
	 * 
	 */
	@Override
	public void verifyTermsAndPolicyPageDetails(Client client, String page) {
		waitFor(client,3);
		verifyPageTitles(client, page);
		try{
		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[contains(@class,'ScrollView')]",
				0,
				"invokeMethod:'{\"selector\":\"pu_scrollToEdge:animated:\",\"arguments\":[\"1\", \"true\"]}'");
		}catch(Exception e){
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[contains(@class,'ScrollView')]", "Up", 0, 
					2000, "NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='false']", 0, 1000, 10, false);
			}
		waitFor(client,1);
		verifyButtonStatus(client, "reject", false);
		verifyButtonStatus(client, "accept", true);

	}

	/**
	 * Author: Lourde Noel Rini 
	 * 
	 * Click on Checkbox in Terms of Use and Privacy Policy page
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param clickCheckbox
	 *            true/false
	 * 
	 */
	public void clickCheckBox(Client client, boolean clickCheckbox) {
		if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']", 0)){
				client.runNativeAPICall(
						"NATIVE",
						"xpath=//*[contains(@class,'ScrollView')]",
						0,
						"invokeMethod:'{\"selector\":\"pu_scrollToEdge:animated:\",\"arguments\":[\"3\", \"true\"]}'");
			if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']", 0)){
				client.swipeWhileNotFound("Down", 250, 500, "NATIVE", "xpath=//*[@class='UIView' and ./descendant::*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']]", 0, 1000, 50, false);
			}
			waitFor(client,2);
		}
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @top='true']", 0);


		if (clickCheckbox) {

			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']",
					0, 1);

			clickOnButtonOption(client, "accept", true);
			waitFor(client,1);

		} 
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Terms of Use \ Privacy Policy page Pop up
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *            
	 */

	public void verifyPagePopUp(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='"+getLangPropValue("accept").toUpperCase()+"' and @onScreen='true']",
				0, 2000);

		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='"+getLangPropValue("accept").toUpperCase()+"' and @onScreen='true']",
				0, 1);
		waitFor(client,1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='"+getLangPropValue("cancel").toUpperCase()+"' and @enabled='true' and @onScreen='true']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='"+getLangPropValue("accept").toUpperCase()+"' and @enabled='true' and @onScreen='true']", 0);
	}

	public void clickAccept(Client client){
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='"+getLangPropValue("accept").toUpperCase()+"' and @class='LibreLink.LLDialogButton']",
				0, 1);
		waitFor(client,2);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Enter first name  last name and DOB details for Create new account
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 * @param fname
	 *            Enter fname as FirstName
	 *            
	 * @param lname
	 *            Enter lname as LastName
	 *            
	 * @param dob
	 *            Select Date of Birth from app calendar
	 *            
	 * 
	 */

	public void createNewAccountDetails(Client client, String fname,
			String lname, String dob) {
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField']", 0,
				fname);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField']", 1,
				lname);
		client.closeKeyboard();
		enterDOB(client, dob);


	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to verify Adult Login Screen
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */
	public void verifyAdultLoginScreen(Client client){
		client.waitForElement("NATIVE", "text=${adultRegistrationTitle}", 0, 5000);
		client.verifyElementFound(
				"NATIVE",
				"text=${enter_numera_data}",
				0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Adult login details for Create an account
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param email
	 *         Enter email from getEmail
	 *                
	 * @param password
	 *            Enter password
	 *            
	 * @param confirmpassword
	 *          enter confirm password
	 *            
	 * @param checkSubscription
	 *            true/false
	 */

	public void adultLoginDetails(Client client, String email, String password,
			String confirmpassword, boolean checkSubscription) {
		setEmailAndPassword(client, email, password, confirmpassword);
		waitFor(client,2);
		client.closeKeyboard();
		if (checkSubscription) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']",
					0, 1);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set Email And Password
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param email
	 *            Enter email 
	 *            
	 * @param password
	 *            Enter password
	 *            
	 * @param confirmpassword
	 *           Enter confirm password
	 *            
	 */

	public void setEmailAndPassword(Client client, String email,
			String password, String confirmpassword) {
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Email']", 0, email);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.closeKeyboard();
		waitFor(client,1);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Confirm Password']",
				0, confirmpassword);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Confirm Password']",
				0, confirmpassword);
		client.closeKeyboard();
		waitFor(client,1);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Unit Of Measurement Page details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyUnitOfMeasurementPageDetails(Client client) {
		client.verifyElementFound("NATIVE", "text=${unitOfMeasurementTitle}", 0);
		if (getCountryCode().equals("Germany")) {
			client.verifyElementFound("NATIVE",
					"text=${unitOfMeasurementTopTextForSetup}", 0);
			client.verifyElementFound("NATIVE",
					"text=${mgPerDeciliterRadioText}", 0);
			client.verifyElementFound("NATIVE",
					"text=${mmolPerLiterRadioText}", 0);
			client.verifyElementFound("NATIVE", "text=${unitOfMeasureWarning}",
					0);
			verifyButtonStatus(client, "next", false);
			unitOfMeasurementGerman(client);
			verifyButtonStatus(client, "next", true);
		} else {
			client.verifyElementFound("NATIVE",
					"text=${unitOfMeasurementFixedTopText}", 0);
			client.verifyElementFound("NATIVE",
					"text=${unitOfMeasurementFixedCountryText}", 0);
			client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);
			client.verifyElementFound("NATIVE",
					"text=${unitOfMeasurementFixedText}", 0);
			client.verifyElementFound("NATIVE", "text=" + getUnits(), 0);
			verifyButtonStatus(client, "next", true);
		}

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method to select Unit of measurement when both units are present
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */
	public void unitOfMeasurementGerman(Client client){
		client.click("NATIVE", "xpath=//*[contains(@accessibilityLabel,'"+getUnits()+"')]", 0, 1);
		waitFor(client,1);


	}

	/**
	 * Author: Lourde Noel Rini / Shabina
	 * 
	 * Method to Verify Target Glucose Range Page details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyTargetGlucoseRangePageDetails(Client client) {
		client.verifyElementFound("NATIVE", "text=${targetGlucoseRangeTitle}", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=${targetGlucoseRangeTopTextForSetup}",
				0);
		client.verifyElementFound("NATIVE", "text=" + getUnits(), 0);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			Assert.assertEquals(100, findTargetGlucose(client, 0),0);
			Assert.assertEquals(140, findTargetGlucose(client, 1),0);
		}
		else if (getUnits().equalsIgnoreCase("mmol/L")) {
			Assert.assertEquals(5.6, findTargetGlucose(client, 0),0);
			Assert.assertEquals(7.8, findTargetGlucose(client, 1),0);
		}

		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='BackArrow']", 0);
	}


	/**
	 * Author: Lourde Noel Rini 
	 * 
	 * Method to Verify carbohydrate Units Page details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyCarbohydrateUnitsPageDetails(Client client) {
		client.verifyElementFound("NATIVE", "text=${carbohydrateUnitsTitle}", 0);
		client.verifyElementFound("NATIVE", "text=${carbohydrateUnitsTopText}", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${grams}']]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${servings}']]", 0); 


		Assert.assertTrue("0".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./following-sibling::*[@text='${servings}'] and ./parent::*[@class='UITableViewCellContentView']]",
						0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
		Assert.assertTrue("0".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${grams}']]",
						0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

		verifyButtonStatus(client, "done", false);
		Assert.assertTrue("0".equals(client
				.runNativeAPICall("NATIVE", "xpath=//*[@text='"+getLangPropValue("done").toUpperCase()+"']", 0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Select Grams/servings in carbohydrate Units Page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param units
	 *            Select either Grams/Servings
	 *          
	 */

	public void selectCarbohydrateUnits(Client client, String units) {

		client.click("NATIVE", "text=${" + units + "}", 0, 1);
		Assert.assertTrue("1".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${"
								+ units + "}']]", 0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

		if (units.equalsIgnoreCase("Grams")) {
			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='UIImageView' and @height>0 and ./following-sibling::*[@text='${servings}'] and ./parent::*[@class='UITableViewCellContentView']]",
							0,
							"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='LibreLink.ServingSizeTableCell']",
							0,
							"invokeMethod:'{\"selector\":\"isUserInteractionEnabled\",\"arguments\":[]}'")));

		} else {

			Assert.assertTrue("1".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='LibreLink.ServingSizeTableCell']",
							0,
							"invokeMethod:'{\"selector\":\"isUserInteractionEnabled\",\"arguments\":[]}'")));

			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${grams}']]",
							0,
							"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

			setAndverifyServingsValue(client, 10.0);

		}
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify My Glucose Page information
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param screenName
	 *           set the Screen Name         
	 */

	public void verifyMyGlucoseInfoPage(Client client, String screenName) {
		if(screenName.contains("setup")){
			client.verifyElementFound("NATIVE",
					"text=${myGlucoseExplanationTitle}", 0);
			client.verifyElementFound("NATIVE",
					"text=${myGlucoseExplanationTopText}", 0);
			verifyButtonStatus(client, "next", true);
		}else{
			client.verifyElementFound("NATIVE",
					"text=${helpItemTitleGlucoseHelp}", 0);
		}

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=my_glucose_overview_mg" , 0);
		}else{
			client.verifyElementFound("NATIVE", "accessibilityIdentifier=my_glucose_overview_mmol" , 0);
		}

		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='${myGlucoseExplanationResultCallouts}']",
				0);

	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Glucose Trend arrow Page Contents
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param screenName
	 *           set the Screen Name         
	 */

	public void verifyGlucoseTrendArrow(Client client, String screenName) {
		if(screenName.contains("setup")){
			client.verifyElementFound("NATIVE",
					"text=${trendExplanationTitle}", 0);
			client.verifyElementFound("NATIVE","text=${trendExplanationTopText}",0);
			verifyButtonStatus(client, "next", true);
		}else{
			client.verifyElementFound("NATIVE",
					"text=${helpItemTitleGlucoseHelp}", 0);
		}

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseRisingQuicklyArrow", 0);
		client.verifyElementFound("NATIVE", "text=${trendExplanationRisingQuickly}", 0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseRisingArrow", 0);
		client.verifyElementFound("NATIVE", "text=${trendExplanationRising}", 0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseChangingSlowlyArrow", 0);
		client.verifyElementFound("NATIVE", "text=${trendExplanationStable}",
				0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseFallingArrow", 0);
		client.verifyElementFound("NATIVE", "text=${trendExplanationFalling}", 0);

		client.verifyElementFound("NATIVE", "accessibilityIdentifier=GlucoseFallingQuicklyArrow", 0);
		client.verifyElementFound("NATIVE", "text=${trendExplanationFallingQuickly}", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify and Click How to Apply new sensor link
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void verifyandClickHowToApplyNewSensorLink(Client client) {	
		client.waitForElement("NATIVE", "text=${applyNewSensorDetail}", 0, 1000);
		client.click(
				"NATIVE",
				"xpath=//*[@text='"+getLangPropValue("helpItemTitleApplySensor").toUpperCase()+"']",
				0,1);	
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify How to Apply new sensor pages
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void verifyHowToApplyNewSensorSteps(Client client) {
		client.waitForElement("NATIVE", "text=${applySensorTitleStep1}", 0, 1000);
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep1}", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+getLangPropValue("applySensorTextStep1")+"')]",0);

		client.verifyElementFound("NATIVE", 
				"xpath=//*[contains(@text,'"+getLangPropValue("applySensorSubTextStep1")+"')]",0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep2}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep2}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep3}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep3}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep4}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep4}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep5}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep5}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep6}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep6}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep7}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep7}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep8}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep8}']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep9}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep9}']", 0);

		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${applySensorTitleStep10}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${applySensorTextStep10}']", 0);

	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify and Click How to scan a new sensor link
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 */

	public void verifyandClickHowToScanNewSensorLink(Client client) {
		client.waitForElement("NATIVE", "text="+getLangPropValue("helpItemTitleScanSensor").toUpperCase(), 0, 1000);
		client.click(
				"NATIVE",
				"xpath=//*[@text='"+getLangPropValue("helpItemTitleScanSensor").toUpperCase()+"']",
				0,1);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify How to Scan a sensor Pages
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */

	public void verifyHowToScanSensorSteps(Client client) {
		client.waitForElement("NATIVE", "text=${scanSensorTitleStep1}", 0, 10000);
		client.verifyElementFound("NATIVE", "text=${scanSensorTitleStep1}", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=${iosScanSensorTextStep1}",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${scanSensorTitleStep2}", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=${iosScanSensorTextStep2}",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=${scanSensorTitleStep3}", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='${iosScanSensorTextStep3}']",
				0);

	}

	/**
	 * Author: LourdeNoelRini 
	 * 
	 * Method to verify User's Manual
	 *         
	 * @param client
	 *        Integrate SeeTestAutomation
	 */

	public void verifyUsersManualGuide(Client client) {
		waitFor(client,1);
		client.waitForElementToVanish(
				"NATIVE",
				"xpath=//*[@text='${progressDownloadingUserGuide}' and @top='true']",
				0, 80000);
		waitFor(client,30);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='User’s Manual' and @class='UILabel']", 0);

	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Get the Calendar date
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 * @throws ParseException
	 * 			Throws Parse Exception for date selection
	 *@return date
	 *		Returns the date in String format
	 */
	public String getCalendarDate(Client client) throws ParseException {
		String systemDateTime = client.elementGetText("NATIVE",
				"xpath=//*[@class='UILabel' and @textColor='0xFFFFFF']", 0);
		SimpleDateFormat deviceFormat = new SimpleDateFormat("MMMMM d, yyyy");
		if (getLanguage().contains("English (U.K.)") ) {
			deviceFormat = new SimpleDateFormat("d MMMMM yyyy");
		}
		Date d = deviceFormat.parse(systemDateTime);
		deviceFormat.applyPattern("dd.MM.yyyy");
		String devicedate = deviceFormat.format(d);
		return devicedate;

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Select Food Attribute 
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param foodType
	 *           select Food Type from list(breakfast/lunch/dinner/snack)
	 */

	public void setFoodAttribute(Client client, String foodType) {
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='DownCaret' and @top='true']",
				0, 1);

		waitFor(client, 1);
		client.click("NATIVE", "xpath=//*[@text='${" + foodType
				+ "}' and @visible='true']", 0, 1);
		waitFor(client, 1);


	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set Food Value 
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param value
	 *           set the food value
	 */
	public void setFoodValue(Client client,
			String value) {
		client.elementSendText(
				"NATIVE",
				"xpath=//*[@class='UITextField']",
				0, value);
		client.click("NATIVE", "accessibilityLabel=Done", 0, 1);
		client.closeKeyboard();
	}
	/**
	 * Author: Amaresh
	 * 
	 * Method to Click On Created Note
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param notetime
	 *            set the note time for click
	 */
	public void clickCreatedNote(Client client, String notetime) {
		if (getLanguage().contains("U.K.") ) {
			notetime = notetime.toLowerCase();
		}

		client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + notetime
				+ "']", 0, 1);
		waitFor(client,2);
	}

	public void deleteNote(Client client) {

		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='TrashIcon']", 0, 5000);

		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='TrashIcon']", 0, 1);
		waitFor(client, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='DELETE']", 0, 5000);

		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='DELETE']", 0, 1);
		waitFor(client, 1);

	}

	/**
	 * Author: Amaresh
	 *  Method to Select The Note Attribute
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param attribute
	 *         set the Attribute(Food/Rapid Acting-Insulin/Long Acting-Insulin/Exercise)
	 * 
	 */

	public void selectNoteAttribute(Client client, String attribute) {
		attribute=getLangPropValue(attribute);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
						+ attribute + "']]", 0, 1);
		waitFor(client,1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Food In LogBook Detail Page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param mealType
	 *            set the meal type(breakfast/lunch/dinner/snack)
	 * @param carbUnit
	 *            Set the CarbUnit
	 * @param carbAmount
	 *            Set the CarbAmount
	 */
	public void verifyFoodInLogBookDetailPage(Client client, String mealType,
			String carbUnit, String carbAmount) {
		String value=null;
		if(mealType!=null){
			value = getLangPropValue(mealType);
		}else{
			value = getLangPropValue("food");
		}
		if (carbUnit.equals("grams")) {
			value = value+" ("+carbAmount+" "+getLangPropValue("gramsSymbol")+")";

		} else if (carbUnit.equals("servings") || carbUnit.equals("portions")) {
			value = value+" ("+carbAmount+" "+getLangPropValue("servingsSymbol")+")";

		}
		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value
				+ "']", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to verify the Food Error
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param units
	 *        set the Units
	 *
	 */
	public void verifyFoodError(Client client, String units) {
		String value=null;
		if (units.equalsIgnoreCase("grams")) {
			value = getLangPropValue("carbsGramsError").replace("%2$@", "400");
		} else {
			value = getLangPropValue("carbsServingsError").replace("%2$@", "40");
		}
		value = value.replace("%1$@", "0");
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='"+value+"']",
				0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='${ok}']", 0);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method for Edit the Note
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void editNote(Client client) { 
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityIdentifier='EditIconLarger']", 0,
				10000);
		waitFor(client, 1);
		client.click("NATIVE",
				"xpath=//*[@accessibilityIdentifier='EditIconLarger']", 0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='TrashIcon']", 0, 10000);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Click OK On Insulin Error
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
*/
	public void clickErrorOk(Client client) {
		client.click("NATIVE", "xpath=//*[@text='${ok}']", 0, 1);
		waitFor(client,1);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Get TimeZone value As GMT format
	 * 
	 * @param zone
	 *            Set the Zone
	 *            
	 * @param selecteddate
	 *         set the date
	 * @param time
	 * 			set the exact time
	 * @return timezone
	 * 		Returns the time zone value          
	 */
	public String getTimeZoneValueForSelectedDate(String zone, String selecteddate, String time) {
		String timeZoneString;
		Calendar c = Calendar.getInstance();

		if(selecteddate!=null){
			SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
			Date date = null;
			String time1  = null;
			try {
				date = sdf.parse(selecteddate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			c.setTime(date);
			if(time.contains("AM")||time.contains("PM")){
				SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
				SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh:mm a");
				Date _12HourDt=null;
				try {
					_12HourDt = _12HourSDF.parse(time);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				time1 = _24HourSDF.format(_12HourDt);
			}else{
				time1 = time;
			}
			String[] hm = time1.split(":");
			c.set(Calendar.HOUR, Integer.parseInt(hm[0]));
			c.set(Calendar.MINUTE, Integer.parseInt(hm[1]));
		}else{
			c.setTime(new Date());
		}

		Date date = c.getTime();
		System.out.println("SelectedDate:"+date);
		TimeZone tz = TimeZone.getTimeZone(zone);
		long hours = TimeUnit.MILLISECONDS.toHours(tz.getRawOffset());
		long minutes = TimeUnit.MILLISECONDS.toMinutes(tz.getRawOffset())
				- TimeUnit.HOURS.toMinutes(hours);
		minutes = Math.abs(minutes);
		if (tz.inDaylightTime(date)) {
			hours = hours + 1;
		}

		if (hours > 0) {
			timeZoneString = String.format("GMT+%s:%02d", hours, minutes);
		} else {

			timeZoneString = String.format("GMT%s:%02d", hours, minutes);
		}

		timeZoneString = timeZoneString.replace(":00", "");
		return timeZoneString;
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method for click Calendar Arrow Button
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param count
	 *         set count for click
	 *
	 */
	public void clickCalendarArrow(Client client, int count) {
		if(count<0){
			for (int click = 0; click > count; click--) {
				client.click(
						"NATIVE",
						"xpath=//*[@class='UIButton' and ./parent::*[@class='LibreLink.LLBanner']]",
						0, 1);


			}
		}else{
			for (int click = 0; click < count; click++) {
				client.click(
						"NATIVE",
						"xpath=//*[@class='UIButton' and ./parent::*[@class='LibreLink.LLBanner']]",
						2, 1);

			}
		}
		waitFor(client,1);
	}


	/**
	 * Author: NagarajuKasarla/Amaresh
	 * 
	 *  Add Note for Insulin
	 * 
	 * @param client
	 *         Integrate SeeTestAutomationo
	 *         
	 * @param indexOfTextField
	 *            set the index value   
	 *                
	 * @param value
	 *            set the glucose value
	 */

	public void addNoteForInsulin(Client client, int indexOfTextField,String value) {

		client.elementSendText("NATIVE",
				"xpath=//*[@class='_UITextFieldContentView' and @top='true']",
				indexOfTextField, value);
		client.verifyElementFound("NATIVE", "text=${units}", 0);
		client.closeKeyboard();
		waitFor(client, 1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify LogBook Detail Page for Insulin Note
	 * 
	 * @param client
	 *         Integrate SeeTestAutomationo  
	 *         
	 * @param insulinType
	 *            set the insulin type
	 *            
	 * @param insulinUnit
	 *            set the insulin Units
	 */

	public void verifyInsulinLogBookDetailPage(Client client,
			String insulinType, String insulinUnit) {

		String value = getLangPropValue(insulinType);
		if(insulinUnit!=null){

			if ((insulinUnit.equals("1"))) {
				value = value+" ("+getLangPropValue("insulinUnits_one").replace("%1$@", "1")+")";
			} else {
				value = value+" ("+getLangPropValue("insulinUnits_other").replace("%1$@", insulinUnit)+")";

			}
		}
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"
				+ value + "' and @top='true']", 0);
	}

	/** Author: Amaresh
	 * 
	 * Method to verify the Insulin Error
	 * 
	 * @param client
	 *            Integrate SeeTestAutomationo
	 *
	 */
	public void verifyInsulinError(Client client) {

		String value = getLangPropValue("insulinDoseError").replace("%1$d", "200");
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='"+value+"']",
				0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='${ok}']", 0);
	}


	/**
	 * Author: Amaresh
	 * 
	 *   Click Blood Drop Icon and Create ManualBG note
	 *         
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *        Set the Note value
	 *        
	 * @param date
	 *        Set the date
	 *        
	 * @param time
	 *         Set the time
	 */
	public void createManualBGNote(Client client, int value, String date, String time) {
		if(client.isElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='BGM_Drop_Plus' and @hidden='false']", 0)){
			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='BGM_Drop_Plus' and @hidden='false']", 0, 1);
			waitFor(client,1);

			client.verifyElementFound("NATIVE", "xpath=//*[@text='${manualBgTitle}']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='${manualBgExplanation}']", 0);
		}
		client.elementSendText("NATIVE", "xpath=//*[@class='UITextField']", 0, Integer.toString(value));
		waitFor(client, 1);
		client.click("NATIVE", "text=${done}", 0, 1);
		client.closeKeyboard();
		if(date!=null && time!=null){
			if(!client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.BGRDateTimePickerCell' and @onScreen='true']", 0)){
				client.click("NATIVE", "text=Edit Time", 0, 1);
			} 
			waitFor(client, 1);

			String datetime = date+" "+time;
			client.elementSetProperty("NATIVE", "class=UIDatePicker", 0, "datetime", datetime);
		}
		waitFor(client, 1);
		clickOnButtonOption(client, "done", true);
		waitFor(client, 1);

	}

	/**
	 * Author: Amaresh
	 * 
	 *  Method to verify added manual BG in Logbook list
	 *         
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param logBookTime
	 *            set the time
	 *            
	 * @param value
	 *          set the value
	 *          
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 */
	public void verifyManualBGinLogbookList(Client client, String value, String logBookTime) throws InternalException, ParseException {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']",
				0);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "text=" + getUnits(), 0, 0);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "xpath=//*[@text='" + logBookTime+ "']", 0, 0);

		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookNoteIcon']", 0, 0);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=LogbookNoteIcon", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0x808080']", 0);
		if (getLanguage().contains("English (U.S.)")&&getCountryofExecution().contains("US")){
			client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "text=" + getUSExecutionFormat(client,getCalendarDate(client),logBookTime), 0, 0);
		}
		else{
			client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "text=" + getTimeZoneValueForSelectedDate(getDefaultCOETimeZone(),getCalendarDate(client),logBookTime), 0, 0);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 *    Method to verify BG error
	 *         
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 */
	public void verifyBGError(Client client) {
		String value = getLangPropValue("carbsGramsError").replace("%1$@", "20").replace("%2$@", "500");
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='"+value+"']",
				0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to scroll To Bottom Add Note Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void scrollToBottomAddNotePage(Client client) {
		client.sleep(2000);
		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[@class='UITableView' and ./*[@class='LibreLink.AddNoteTableCell']]",
				0,
				"invokeMethod:'{\"selector\":\"pl_scrollToBottom:\",\"arguments\":[\"true\"]}'");
		if(!client.isElementFound("NATIVE", "xpath=//*[@class='_UITextContainerView' and @top='true']", 0)){
			client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView']", 0, "down", 0, 1000);
		}
	}
	
	/**
	 * Author: NagarajuKasarla
	 *
	 * Method to Navigate To Sub Menu Screens
	 *
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param subscreen
	 *         setting sub menu screen name
	 *
	 */
	@Override
	public void navigateToSubMenuScreens(Client client,
			String subscreen) {
		subscreen = getLangPropValue(subscreen);
		client.waitForElement("NATIVE", "text=" + subscreen, 0, 1000);
		client.click("NATIVE", "text=" + subscreen, 0, 1);
		waitForProgress(client);

	}


	/**
	 * Author: NagarajuKasarla/Amaresh
	 * 
	 * Method to Select Exercise type and set the Hours, minutes
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param intensity
	 *            set the required intensity
	 * @param hrs
	 *            set the hours
	 * @param mins
	 *            set the minutes
	 */

	public void addNoteForExercise(Client client, String intensity, int hrs,
			int mins) {
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		client.click("NATIVE", "xpath=//*[@class='LibreLink.AddNoteDropdownTableCell']", 0, 1);
		waitFor(client,1);
		client.click("NATIVE", "text=${" + intensity+"}", 0, 1);
		waitFor(client,1);
		scrollToBottomAddNotePage(client);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='DownCaret' and ./preceding-sibling::*[contains(@accessibilityLabel,'min')]]",
				0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Edit Time']", 0, 10000);
		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[@class='UIPickerView']",
				0,
				"invokeMethod:'{\"selector\":\"selectRow:inColumn:animated:\",\"arguments\":[\""
						+ hrs + "\", \"0\", \"true\"]}'");

		client.runNativeAPICall(
				"NATIVE",
				"xpath=//*[@class='UIPickerColumnView' and ./*[./*[./*[./*[./*]]]]]",
				0,
				"invokeMethod:'{\"selector\":\"selectRow:animated:notify:\",\"arguments\":[\""
						+ mins + "\", \"true\", \"true\"]}'");

		client.click("NATIVE", "text=${done}", 0, 1);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Exercise Note with Intensity with set time on LogBook Detail Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param intensity
	 *            set intensity
	 * @param hr
	 *            set hour
	 * @param min
	 *            set minutes
	 */
	public void verifyExerciseIntensityInLogBookDetailPage(Client client,
			String intensity, int hr, int min) {
		String value=getLangPropValue("exercise");
		String hoursContent = "";
		String minsContent = "";
		if(intensity!=null){
			value = value+" "+getLangPropValue(intensity);
			if(hr!=0 && min!=0){

				if(hr==0){
					hoursContent = "";
				}
				else if(hr==1){
					hoursContent = getLangPropValue("hours_one");
				}else{
					hoursContent = getLangPropValue("hours_other").replace("%1$d", Integer.toString(hr));
				}
				if(min==0){
					minsContent = "";
				}
				else if(min==1){
					minsContent = getLangPropValue("minutes_one");
				}else{
					minsContent = getLangPropValue("minutes_other").replace("%1$d", Integer.toString(min));
				}
				client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'" +hoursContent + "')]", 0);	
				client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'" +minsContent + "')]", 0);	
			}

		}
		client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'" +value + "')]", 0);		


	}

	/**
	 * Author: Amaresh
	 * 
	 * Method for Unselect Note Attribute
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param attribute
	 *  	   set the Attribute
	 * 
	 */

	public void unSelectNoteAttribute(Client client, String attribute) {

		attribute = getLangPropValue(attribute);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
						+ attribute + "']]", 0);

		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
						+ attribute + "']]", 0, 1);

		waitFor(client, 2);

	}

	/**
	 * Author: Amaresh
	 * 
	 *    Method for  Enter Notes Comments
	 *    
	 * @param client
	 *            Integrate SeeTestAutomation 
	 *            
	 * @param notesComments
	 *            set the comments
	 */
	public void enterNotesComments(Client client, String notesComments) {
		scrollToBottomAddNotePage(client);
		client.click("NATIVE",
				"xpath=//*[@class='_UITextContainerView' and @top='true']", 0, 1);
		waitFor(client, 1);
		client.elementSendText("NATIVE",
				"xpath=//*[@knownSuperClass='UITextView']", 0, notesComments);
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='Done']", 0, 1);
		waitFor(client, 2);
	}

	/**
	 * Author: Amaresh
	 * 
	 *   Method to  Verify Notes Comments
	 *   
	 * @param client
	 *            Integrate SeeTestAutomation  
	 * @param notesComments
	 *            set the comments
	 */
	public void verifyNotesComments(Client client, String notesComments) {
		client.verifyElementFound("NATIVE",
				"text="+notesComments, 0);

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 *  Click Arrow On Top Left Of The Graph
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param count
	 *            Number of times to Click on Top Left Arrow
	 * 
	 */

	public void clickArrowOnTopLeftOfTheGraph(Client client, int count) {

		if (client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.RegularButton'and @x='0']", 0)) {
			try {
				int newcount=-count;
				String dateToBeDisplayed = getNewDate(client,newcount);

				for (int i = 1; i <= count; i++) {
					client.click("NATIVE", "xpath=//*[@class='LibreLink.RegularButton'and @x='0']", 0, 1);
				}
				waitFor(client,1);
				client.verifyElementFound("NATIVE","accessibilityLabel="+dateToBeDisplayed, 0);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

	public String getNewDate(Client client, int count) throws ParseException {
		String currentDate = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and @textColor='0x000000' and @top='true' and ./parent::*[@class='UIView' ]]", 0);
		SimpleDateFormat sdf;
		Date date;
		String dateToBeDisplayed=null;
		Calendar c1 = null;
		if (getLanguage().contains("U.S.")) {
			sdf = new SimpleDateFormat("MMMMM d, yyyy");
			date = sdf.parse(currentDate);
			c1 = Calendar.getInstance();
			c1.setTime(date);
			c1.add(Calendar.DATE, count);
			dateToBeDisplayed = sdf.format(c1.getTime());

		} else if (getLanguage().contains("U.K.")) {
			sdf = new SimpleDateFormat("d MMMMM yyyy");
			date = sdf.parse(currentDate);
			c1 = Calendar.getInstance();
			c1.setTime(date);
			c1.add(Calendar.DATE, count);
			dateToBeDisplayed = sdf.format(c1.getTime());

		}
		return dateToBeDisplayed;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method for Sign-In to the App
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param email
	 *            Enter email
	 * @param pwd
	 *            Enter Password
	 */
	public void signIn(Client client, String email, String pwd) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityIdentifier='Freestyle_logo']", 0, 1000);
		client.click("NATIVE", "xpath=//*[contains(@text,'"
				+ getLangPropValue("alreadyHaveAccountPromptText") + "')]", 0,
				1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Sign In']", 0, 10000);
		client.verifyElementFound("NATIVE", "text=${normal_user_login_text}", 0);
		client.elementSendText("NATIVE",
				"xpath=//*[@knownSuperClass='UITextField']", 0, email);
		client.elementSendText("NATIVE",
				"xpath=//*[@knownSuperClass='UITextField']", 1, pwd);
		client.closeKeyboard();
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='SIGN IN']", 0, 1);
		waitForProgress(client);
		waitFor(client,5);
		if (client.isElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='OK']", 0)) {
			clickOnButtonOption(client, "ok", true);

		}
		waitForProgress(client);
		clickAndAcceptPage(client, "Terms of Use");
		clickAndAcceptPage(client, "Privacy Notice");
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Unit of Measurement", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Click and Accept Terms of Use /Privacy Notice page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param page
	 *            terms of use or privacy notice page
	 *            
	 */

	public void clickAndAcceptPage (Client client, String page) {

		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @knownSuperClass='UILabel']",
				0, 3000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @knownSuperClass='UILabel']",
				0, 1);
		waitFor(client,1);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @knownSuperClass='UIButton' and @tag='1']",
				0, 1);
		waitFor(client,2);
		waitForProgress(client);
	}

	/**
	 * Author: Amaresh/Nagaraju
	 * 
	 * Method to Verify default settings
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param units
	 *           Set the Units
	 * @param value
	 *          Set the Value           
	 */
	public void defaultSettings(Client client, String units, double value) {
		verifyPageTitles(client,"unitOfMeasurementTitle");	
		if(getCountryCode().contains("German")){
			unitOfMeasurementGerman(client);
			clickOnButtonOption(client, "next", true);
			if (client.isElementFound("NATIVE",
					"xpath=//*[@class='UIView' and ./*[@accessibilityLabel='OK']]",
					0)) {
				client.click(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='OK' and @class='LibreLink.LLDialogButton']",
						0, 1);
			}
		}
		else{
			clickOnButtonOption(client, "next", true);
		}
		verifyPageTitles(client,"targetGlucoseRangeTitle");	
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"carbohydrateUnitsTitle");
		client.click("NATIVE", "text=${"+units+"}", 0, 1);
		if(units.contains("servings")){
			setServingsValue(client,value);
		//	setAndverifyServingsValue(client,value);
		}
		waitFor(client,1);
		clickOnButtonOption(client, "done", true);
		verifyPageTitles(client,"welcome");	
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"myGlucoseExplanationTitle");	
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"backgroundGlucoseColorsTitle");
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"trendExplanationTitle");	
		
		if (getNAIconConfig().equalsIgnoreCase("yes")) {
		
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"treatmentDecisions");	
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"treatmentDecisions");	
		
		}
		clickOnButtonOption(client, "done", true);
	
	}	

	/**
	 * Author: ShabinaSherif
	 *  Method for  Swipe Slider
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param valueSet
	 *           Set Valueset
	 *  @return slidervalue
	 *  		Returns the slider value          
	 */
	public double swipeSlider(Client client, double valueSet){

		if(valueSet==10.0){
			client.elementSwipe("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UISlider']]", 0, "Left", 20, 1000);
		}else if(valueSet==14.5){
			client.elementSwipe("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UISlider']]", 0, "Left", 0, 1000);
		}else{
			client.elementSwipe("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UISlider']]", 0, "Left", 15, 1000);
		}
		String existingValue = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and ../parent::*[@class='LibreLink.ServingSizeTableCell']]", 0);
		String[] value = existingValue.split("=");
		existingValue = value[1].substring(1, 4);
		double gramValue = Double.parseDouble(existingValue);

		return gramValue;
	}

	/**
	 * Author: ShabinaSherif
	 *  Method to  Set And verify Servings Value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param val
	 *           Set Value
	 *            
	 */
	public void setAndverifyServingsValue(Client client, double val) {
		String existingValue = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and ../parent::*[@class='LibreLink.ServingSizeTableCell']]", 0);
		String[] value = existingValue.split("=");
		existingValue = value[1].substring(1, 4);
		double gramValue = Double.parseDouble(existingValue);
		while(val!=gramValue){

			gramValue = swipeSlider(client,gramValue);
		}

		String servingsvalue = getLangPropValue("serving_size_in_grams");
		servingsvalue = servingsvalue.replace("%.1f", "" + val);

		client.verifyElementFound("NATIVE", "text=" + servingsvalue, 0);
	}


	public void addReminder(Client client){
		client.click("NATIVE", "accessibilityLabel=ADD REMINDER", 0, 1);
		waitFor(client,1);
	}

	public void editReminder(Client client, String reminderName){
		selectReminder(client,reminderName,true);
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 *  Add the Reminder for a given time
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param name
	 *            send the name for reminder
	 * @param isAdvance
	 * 			is to advance time true/false
	 * @param hrs
	 *            set the hours
	 * @param mins
	 *            set the minutes
	 * @param isRepeat
	 * 			repeat option to be set true/false
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 */

	public void enterReminderdetails(Client client, String name, boolean isAdvance,
			int hrs, int mins, boolean isRepeat) throws ParseException {
		String time = null;
		client.verifyElementFound("NATIVE", "text=${addReminder}", 0);
		client.elementSendText("NATIVE", "xpath=//*[@accessibilityIdentifier='ReminderTextField']", 0, name);
		client.closeKeyboard();
		if(isAdvance){
			SimpleDateFormat dateFormatHrs = new SimpleDateFormat("HH");
			String formattedDatehrs = dateFormatHrs.format(new Date()).toString();
			int hr = Integer.parseInt(formattedDatehrs);
			SimpleDateFormat dateFormatMins = new SimpleDateFormat("mm");
			String formattedDateMins = dateFormatMins.format(new Date()).toString();
			int min1 = Integer.parseInt(formattedDateMins);
			hr = hr+hrs;
			int minute = min1 + mins;

			if (minute > 60) {
				hrs = hr + 1;
				mins = minute - 60;
			} else if (minute < 60) {
				hrs = hr;
				mins = minute;
			} else {
				hrs = hr + 1;
				mins = 00;
			}
			if(hrs>23){
				hrs=hrs-23;
			}
		}
		if (getLanguage().contains("U.K.")) {

			if (client.isElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='am']", 0) || client.isElementFound("NATIVE",
							"xpath=//*[@accessibilityLabel='AM']", 0)) {
				String _24HourTime = hrs + ":" + mins;
				SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
				SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh.mm a");
				Date _24HourDt = _24HourSDF.parse(_24HourTime);

				time = _12HourSDF.format(_24HourDt).toLowerCase();


			} else {
				time = hrs + "." + mins;
			}

		} else {
			time = hrs + "." + mins;
		}

		client.elementSetProperty("NATIVE", "xpath=//*[@class='UIDatePicker']", 0, "time", time);
		waitFor(client,1);

		if(isRepeat){
			client.click("NATIVE", "xpath=//*[@class='UISwitch']", 0, 1);
			waitFor(client,1);
			client.click("NATIVE","xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./following-sibling::*[@text='All']]", 0, 1);
			waitFor(client,1);
		}
		waitFor(client, 1);
		client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='ReminderSetButton']", 0, 1);
		waitFor(client,1);

	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify Reminder notification 
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation  
	 * @param name
	 *            choose the reminder name
	 *     
	 * @param openReminder
	 *            true/false
	 *
	 */
	public void verifyReminderNotification(Client client, String name, boolean openReminder) {

		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'LIBRELINK,')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Reminder, "+name+"')]", 0);
		if(openReminder){
			client.elementSwipe("NATIVE", "xpath=//*[contains(@text,'Reminder, "+name+"')]", 0, "Left", 100, 500);
			waitFor(client,5);
		}
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder switch is enabled/disabled
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param name
	 *         reminder name
	 *  
	 * @param isEnabled
	 *         true/false
	 * @param compareReminder
	 *        set the reminder for comparision        
	 *         
	 */
	public void verifyReminderStatus(Client client, String name, boolean isEnabled, String compareReminder) {
		selectReminder(client,name,false);
		String switchStatus;
		try{
			switchStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, "invokeMethod:'{\"selector\":\"isOn\",\"arguments\":[]}'");
			if(isEnabled){
				Assert.assertEquals("1",switchStatus);
			}else{
				Assert.assertEquals("0",switchStatus);
			}
		}
		catch(Exception e){
			String xToCompare = client.elementGetProperty("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UISwitchModernVisualElement' and ./parent::*[contains(@accessibilityLabel,'"+compareReminder+"')]]]", 0, "x");
			String x6Once = client.elementGetProperty("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UISwitchModernVisualElement' and ./parent::*[contains(@accessibilityLabel,'"+name+"')]]]", 0, "x");
			if(isEnabled){
				Assert.assertTrue("Switch is on for "+name, Integer.parseInt(xToCompare) == Integer.parseInt(x6Once));
			}else{
				Assert.assertTrue("Switch is off for "+name, Integer.parseInt(xToCompare) > Integer.parseInt(x6Once));
			}
		}

	}


	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to swipe down and select the reminder
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param reminderName
	 *            reminderName to be selected
	 *            
	 * @param click
	 *            true/false
	 *            
	 */
	public void selectReminder(Client client, String reminderName, boolean click) {
		if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor' and @top='true']", 0)){
			client.swipeWhileNotFound("Up", 500, 1000, "NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor' and @top='true']", 0, 1000, 3, false);
		}
		if(!client.isElementFound("TEXT",reminderName,0)){
			client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Down", 300, 300);
		}
		if(click){
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@text='"+reminderName+"' and ../parent::*[@class='LibreLink.ReminderTableCell' ] and @onScreen='true']", 0, 1);
		}

		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify enable or disable reminder
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param name
	 *            choose the reminder
	 *
	 * @param enable
	 *            true/false
	 *            
	 */
	public void enableordisableReminder(Client client, String name, boolean enable) {
		selectReminder(client,name,false);
		try{
			String enabledStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, "invokeMethod:'{\"selector\":\"isOn\",\"arguments\":[]}'");
			if((enabledStatus.equals("1") && !enable) || (enabledStatus.equals("0") && enable) ){
				client.click("NATIVE",
						"xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, 1);
			}
		}catch(Exception e){
			client.click("NATIVE",
					"xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, 1);
		}
		waitFor(client,1);
	}

	public void verifyReminderRepeat(Client client, String name) {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reload' and @hidden='false' and ./following-sibling::*[contains(@accessibilityLabel,'"+name+"')]]", 0);

	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify Next Reminder with BackGround Color
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param name
	 *            reminder name
	 * 
	 *            
	 */

	public void verifyNextReminderwithBackGroundColor(Client client,
			String name) {

		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and contains(@text,'"  + name + "') and ./parent::*[@class='LibreLink.LLBanner']]", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='LibreLink.LLBanner' and @backgroundColor='0x138BE8']",
				0);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to delete  a single reminder
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param name
	 *            choose the reminder name
	 *            
	 */

	public void deleteReminder(Client client, String name) {
		selectReminder(client,name,false);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Right", 0, 500);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0, 500);
		client.click(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0, 1);
		waitFor(client,1);

		client.verifyElementNotFound("NATIVE", "text=" + (name), 0);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to delete all the reminders
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void deleteAllReminders(Client client) {
		int count = client.getElementCount("NATIVE", "class=LibreLink.ReminderTableCell");
		while(count>1){
			client.elementSwipe("NATIVE", "class=LibreLink.ReminderTableCell", count-1, "Right", 0, 500);
			if(client.isElementFound("NATIVE", "xpath=//*[@class='UISwipeActionStandardButton']",
					0)){

				client.click(
						"NATIVE",
						"xpath=//*[@class='UISwipeActionStandardButton']",
						0, 1);
			}
			count = client.getElementCount("NATIVE", "class=LibreLink.ReminderTableCell");
			waitFor(client,1);
		}

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify and if required Set TargetGlucose Range from Settings
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param low
	 *            Set Target Glucose Low Range
	 * 
	 * @param high
	 *            Set Target Glucose high Range
	 * 
	 */

	public void verifyandsetTGfromSettings(Client client, double low, double high) {
		boolean alreadyTGSet = verifyTargetGlucoseRange(client, low, high);
		if (!alreadyTGSet) {
			client.click("NATIVE",
					"xpath=//*[@text='${targetGlucoseRangeTitle}']", 0,
					1);
			waitFor(client,1);
			setTargetGlucoseRange(client, low, high);
			waitFor(client,1);
			clickOnButtonOption(client, "save", true);
			verifyTargetGlucoseRange(client, low, high);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Target glucose range value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param low
	 *            Target Glucose Low Range
	 * 
	 * @param high
	 *            Target Glucose high Range
	 * @return verifyTG
	 * 		Returns the boolean value of verification true/false
	 */

	public boolean verifyTargetGlucoseRange(Client client, double low,
			double high) {

		String lowValue,highValue;
		boolean alreadySet = false;
		if(getUnits().contains("mg")){
			lowValue = (int)low+"";
			highValue = (int)high+"";
		}else{
			lowValue = low+"";
			highValue = high+"";

		}
		System.out.println("'" + lowValue + " - " + highValue + " " + getUnits() + "'");
		if (client.isElementFound("NATIVE", "text=" + lowValue + " - " + highValue + " "
				+ getUnits(), 0)) {

			alreadySet = true;
		}

		return alreadySet;

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Set the carbohydrate units and save it
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param unit
	 *            set the unit to be selected
	 *@throws Exception
	 *		GeneralException
	 */
	public void setCarbohydrateUnits(Client client, String unit)
			throws Exception {

		client.waitForElement("NATIVE", "text=${servings}", 0,
				10000);
		client.click("NATIVE", "text=${" + unit + "}", 0, 1);
		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='SAVE' and @onScreen='true']",
				0, 1);
		waitFor(client, 1);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+unit+"') and @onScreen='true' and  ./preceding-sibling::*[@accessibilityLabel='Carbohydrate Units']]", 0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Select speech option
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param switchStatus
	 *            set on/off
	 */

	public void selectspeechOption(Client client, String switchStatus) {
		client.verifyElementFound("NATIVE", "accessibilityLabel="+switchStatus, 0);
		client.click("NATIVE", "accessibilityLabel="+switchStatus, 0, 1);
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='SAVE' and  @knownSuperClass='UIButton' and @onScreen='true']", 0,
				1);
		waitFor(client, 1);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+switchStatus+"') and @onScreen='true' and  ./preceding-sibling::*[@accessibilityLabel='Text to Speech']]", 0);
	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Account Setting Page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyAccountSettings(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"text=${profileUpdateTopText}",
				0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=First Name", 0);
		client.click("NATIVE", "accessibilityLabel=First Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Last Name", 0);
		client.click("NATIVE", "accessibilityLabel=Last Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Date of Birth",
				0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='_UIDatePickerView' and @onScreen='true']", 0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);

		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Country of Residence", 0);
		client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);

		client.verifyElementFound("NATIVE", "accessibilityLabel=Email", 0);
		client.click("NATIVE", "accessibilityLabel=Email", 0, 1);
		Assert.assertEquals(false, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Password", 0);
		client.click("NATIVE", "accessibilityLabel=Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify if keyboard is opened
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @return keyboardValue
	 * 		Returns the boolean value of keyboard opened or not
	 */
	public boolean isKeyboardOpened(Client client) {
		boolean keyboard = client.isElementFound("NATIVE",
				"xpath=//*[@class='UIKeyboardAutomatic' and @onScreen='true']",
				0);
		if (keyboard == true) {
			client.closeKeyboard();
		} else {
			keyboard = false;
		}
		return keyboard;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Update Account Setting 
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *  
	 */

	public void updateAccountSettings(Client client) {
		enterValue(client,"First Name","UpdatedFirstName");
		enterValue(client,"Last Name","UpdatedLastName");
		try{
			enterDOB(client, "10.10.1995");
		}
		catch(Exception e){
			client.elementSwipe("NATIVE", "xpath=//*[@accessibilityLabel='October']", 0, "Up", 200, 500);
			client.elementSwipe("NATIVE", "xpath=//*[@accessibilityLabel='1']", 0, "Up", 200, 500);
			client.elementSwipe("NATIVE", "xpath=//*[@accessibilityLabel='1967']", 0, "Up", 200, 500);
			waitFor(client,1);
		}
		clickDOB(client);
		sendValidPasswordAndSubmit(client,LibrelinkConstants.CURRENT_PASSWORD);

	}

	/**
	 * Author: Shabina
	 * 
	 * Enter Value
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param label
	 *            send the label value
	 *            
	 * @param value
	 *            send the String value
	 *            
	 */

	public void enterValue(Client client, String label, String value) {
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='"+ label+"']" , 0,
				value);
		client.closeKeyboard();
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Send Valid Password And Submit
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param password
	 * 			enter the password
	 * 
	 */

	public void sendValidPasswordAndSubmit(Client client,String password) {
		/*client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Down", 0, 500);
		client.click("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0, 1);*/
		//password = password.replaceAll(" ", "");
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.closeKeyboard();
		waitFor(client,3);
		clickOnButtonOption(client, "submit", true);
		waitForProgress(client);
		waitFor(client,1);
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to Verify updated Account Settings 
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyUpdateMinorAccountSettings(Client client) {
		client.verifyElementFound("NATIVE", "text=UpdatedFirstName", 0);
		client.verifyElementFound("NATIVE", "text=UpdatedLastName", 0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Change the current password
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param currentPassword
	 *            LibrelinkConstants.CURRENT_PASSWORD
	 *            
	 * @param newPassword
	 *            LibrelinkConstants.NEW_PASSWORD
	 *            
	 * @param confirmNewPassword
	 *            LibrelinkConstants.CURRENT_PASSWORD
	 *            
	 */

	public void changePassword(Client client, String currentPassword,
			String newPassword, String confirmNewPassword ) {
		enterValue(client,"Current Password",currentPassword);
		enterValue(client,"New Password",newPassword);
		enterValue(client,"Confirm Password",confirmNewPassword);
		client.closeKeyboard();
		clickOnButtonOption(client, "submit", true);
		waitForProgress(client);

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Click On Calendar icon in Daily graph or Logbook
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickOnCalendarDate(Client client) {
		if (client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0)) {
			client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0, 1);
			waitFor(client,2);
		}

	}

	/**
	 * Author: ShabinaSherif
	 *
	 * Get the date format
	 *
	 * @param noOfdayFromCurrent
	 *        No of days from current date
	 *        
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 *@return date
	 *		Return the date format
	 */
	public Date getDateFormat(int noOfdayFromCurrent) throws ParseException {

		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DAY_OF_YEAR, noOfdayFromCurrent);
		Date dateBefore = cal.getTime();
		System.out.println(dateBefore);
		return dateBefore;

	}

	/**
	 * Author: Amaresh
	 *
	 * Method to pick the date from the Calendar
	 *         
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param date
	 *            check current date
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 */

	public void pickDate(Client client, Date date) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy");
		String monthTitle = dateFormat.format(date);
		SimpleDateFormat dayformat = new SimpleDateFormat("dd");
		int day = Integer.parseInt(dayformat.format(date));
		String appCalendarDate = client.elementGetText("NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and @enabled='true']", 0);
		DateFormat appFormat;
		String dateSelected = null;

		String direction = "up";

		if (getLanguage().contains("U.S.")) {
			appFormat = new SimpleDateFormat("MMMMM d, yyyy");
			dateSelected = appFormat.format(date);

			if (appFormat.parse(appCalendarDate).before(date)) {

				direction = "down";
			}

		} else if (getLanguage().contains("U.K.")) {
			appFormat = new SimpleDateFormat("d MMMMM yyyy");
			dateSelected = appFormat.format(date);
			if (appFormat.parse(appCalendarDate).before(date)) {

				direction = "down";
			}

		} 
		if(!client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0)){
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UICollectionView']", direction, 300, 1000, "NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0, 0, 3, false);
		}else{
			if(!client.isFoundIn("NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0, "Down", "NATIVE", "xpath=//*[@text='"+day+"']", 0, 0))
				client.elementSwipe("NATIVE", "xpath=//*[@class='UICollectionView']", 0, direction, 300, 1000);
			waitFor(client,1);
		}
		client.clickIn("NATIVE", "xpath=//*[@class='LibreLink.CalendarMonthCollectionHeaderView' and ./*[contains(@text,'"+monthTitle+"')]]", 0, "Down", "NATIVE", "xpath=//*[@text='"+day+"']", 0, 0, 0, 1);
		client.waitForElementToVanish("NATIVE", "xpath=//*[@class='UICollectionView']", 0, 3000);
		if(!client.isElementFound("NATIVE", "xpath=//*[@class='UICollectionView']", 0)){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+dateSelected+"']", 0);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Click On Icon in Reports page and verify the information content
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param reportName
	 *            report to be selected
	 * 
	 */

	public void clickOnIconAndVerifyReportMessage(Client client, String reportName) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityIdentifier='Information']", 0, 3000);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='Information']", 0);
		client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='Information']", 0, 1);
		client.verifyElementFound("NATIVE", "text=${"+reportName+"}", 0);
		reportName = getLangPropValue(reportName);
		if (reportName.equalsIgnoreCase("Daily Patterns")){
			client.verifyElementFound("NATIVE", "text=${daily_patterns_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='DailyPatternsIcon']", 0);

		} else if (reportName.equalsIgnoreCase("Time In Target")) {
			client.verifyElementFound("NATIVE", "text=${time_in_target_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TimeInTargetIcon']", 0);

		} else if (reportName.equalsIgnoreCase("Low Glucose Events")) {
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LowGlucoseEventsIcon']", 0);
			if(getUnits().contains("mg")){
				client.verifyElementFound("NATIVE", "text=${low_glucose_info_msg_mg}", 0);
			}else{
				client.verifyElementFound("NATIVE", "text=${low_glucose_info_msg_mmol}", 0);
			}
		} else if (reportName.equalsIgnoreCase("Average Glucose")) {
			client.verifyElementFound("NATIVE", "text=${average_glucose_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='AverageGlucoseIcon']", 0);

		} else if (reportName.equalsIgnoreCase("Daily Graph")) {
			client.verifyElementFound("NATIVE", "text=${daily_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='DailyGraphIcon']", 0);

		} else if (reportName.equalsIgnoreCase("Estimated A1c")) {
			client.verifyElementFound("NATIVE", "text=${a1c_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='EstimatedA1CIcon']", 0);

		} else if (reportName.equalsIgnoreCase("Sensor Usage")) {
			client.verifyElementFound("NATIVE", "text=${sensor_usage_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='SensorUsageIcon']", 0);

		}



	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Click on Share Button at the Bottom of the screen 
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickShareButton(Client client) {
		if (client
				.waitForElement(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and ./parent::*[@class='_UIModernBarButton'] and @y>300]",
						0, 10000)) {
			client.click(
					"NATIVE",
					"xpath=//*[@class='UIImageView' and ./parent::*[@class='_UIModernBarButton'] and @y>300]",
					0, 1);
		}
		waitFor(client, 1);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Click on Mail option
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickEmail(Client client) {
		client.clickIn("NATIVE", "nixpath=//*[@class='UIAView' and @height>0 and ./*[@class='UIAView' and @height>0 and ./*[@class='UIAView' and @height>0]] and ./parent::*[@class='UIAView' and @width>0 and ./parent::*[@class='UIACollectionView']]]", 0, "Inside", "TEXT", "Mail", 0, 0, 0, 1);
		waitFor(client,1);
		client.waitForElement("NATIVE", "nixpath=//*[@text='Cancel']", 0, 2000);


	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Click on Add To Notes option
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickAddToNotes(Client client) {
		client.clickIn("NATIVE", "nixpath=//*[@class='UIAView' and @height>0 and ./*[@class='UIAView' and @height>0 and ./*[@class='UIAView' and @height>0]] and ./parent::*[@class='UIAView' and @width>0 and ./parent::*[@class='UIACollectionView']]]", 0, "Inside", "TEXT", "Notes", 0, 0, 0, 1);
		waitFor(client,1);
		client.waitForElement("NATIVE", "nixpath=//*[@text='Cancel']", 0, 2000);


	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method for saving the Notes
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void saveNotes(Client client) {

		waitFor(client, 1);
		client.click("NATIVE",
				"nixpath=//*[@value='Save' and @class='UIAButton']", 0, 1);
		waitFor(client, 1);
		launch(client);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method for Send email
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void sendEmail(Client client) {

		waitFor(client, 1);
		client.elementSendText("NATIVE", "nixpath=//*[@value='To:']", 0,
				"abbott.automation@icloud.com");
		waitFor(client, 1);
		client.click("NATIVE",
				"nixpath=//*[@value='Send' and @class='UIAButton']", 0, 1);
		waitFor(client, 1);
		launch(client);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify date on Logbook and the arrow's visibility
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param count 
	 * 			set the count from no of days
	 * 
	 */

	public void verifyDateonGraphAndArrow(Client client, int count) {
		Calendar cal = Calendar.getInstance();
		cal.add( Calendar.DAY_OF_YEAR, count);
		Date dateBefore = cal.getTime();
		System.out.println(dateBefore);
		SimpleDateFormat sdf = null;
		String dateToBeDisplayed=null;
		if (getLanguage().contains("U.S.")) {
			sdf = new SimpleDateFormat("MMMMM d, yyyy");

		} else if (getLanguage().contains("U.K.")) {
			sdf = new SimpleDateFormat("d MMMMM yyyy");

		} 
		dateToBeDisplayed = sdf.format(dateBefore);
		client.verifyElementFound("NATIVE","accessibilityLabel="+dateToBeDisplayed, 0);
		if(count==0){
			Assert.assertEquals("true", client.elementGetProperty("NATIVE", "xpath=//*[@class='LibreLink.RegularButton']", 1, "hidden"));
		}else if(count==90){
			Assert.assertEquals("true", client.elementGetProperty("NATIVE", "xpath=//*[@class='LibreLink.RegularButton']", 0, "hidden"));
		}
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to Verify Not Enough Sensor Data Message
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyNotEnoughSensorDataMessage(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@class='LibreLink.ReportCollectionViewCell']", 0, 1000)) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Not Enough Sensor Data' and @onScreen='true']",
					0);
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Click On number of Days Data
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param noOfDays
	 *            Number of days Data
	 * 
	 */

	public void clickOnDays(Client client, int noOfDays) {

		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment" + noOfDays
				+ "Days']", 0);
		client.click("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment" + noOfDays
				+ "Days']", 0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment" + noOfDays
				+ "Days' and @backgroundColor='0xE0E0E0']", 0);
		waitFor(client,1);

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify report available period for n days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Number of days Data available
	 * 
	 */

	public void verifyReportDataAvailableForNdays(Client client,  int noOfDays) {
		String daysAvailable = getLangPropValue("days_of_data").replace("%1$d", "0").replace("%2$d", Integer.toString(noOfDays));
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @text='"+daysAvailable+"']",
				0);

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify Target Glucose range in Time In target report
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param tgRange
	 *            Target Glucose Range
	 * 
	 */

	public void verifyTargetGlucoseinReports(Client client,  String tgRange) {

		String targetRange = getLangPropValue("timeInTargetGlucoseRangeLabel").replace("%@", tgRange);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @text='"+targetRange+"']",
				0);
	}


	/**
	 * Author: LourdeNoelRini 
	 * 
	 * Method to verify application version, CE mark, Registration no, UDI (based on build) on About screen
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyAppVersionUDICE(Client client) {
		client.verifyElementFound("NATIVE", "accessibilityLabel=Software Version:", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UITableViewLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[@text='${softwareVersion}']] ", 0);
		String appversion = client.elementGetText("NATIVE",
				"xpath=//*[@class='UITableViewLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[@text='${softwareVersion}']] ", 0);
		Assert.assertEquals(appversion,getAppversion());

		if (getCountryCode().equals("United States")) {
			client.verifyElementFound("NATIVE", "xpath=//*[@text='${udi}' and @onScreen='true']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='"+getAppudi()+"' and @onScreen='true']", 0);
			client.runNativeAPICall("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "invokeMethod:'{\"selector\":\"pl_scrollToBottom:\",\"arguments\":[\"true\"]}'");
			client.verifyElementNotFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CELogo' and @hidden='false']", 0);
			client.runNativeAPICall("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "invokeMethod:'{\"selector\":\"pl_scrollToTop:\",\"arguments\":[\"true\"]}'");

		} else if (getCountryCode().equals("United Kingdom")||getCountryCode().equals("Germany")) {
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Down", 100, 1000, "NATIVE", "xpath=//*[@accessibilityIdentifier='CELogo' and @onScreen='true']", 0, 1000, 2, false);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CELogo' and @onScreen='true']", 0);

		}
	}


	/**
	 * Author: LourdeNoelRini 
	 * 
	 * Method to verify website details on About screen
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyWebSite(Client client) {
		client.verifyElementFound("NATIVE", "accessibilityLabel=http://www.freestylelibre.com", 0);
		client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Down", 100, 1000, "NATIVE", "xpath=//*[@text='https://www.abbott.com/patents' and @onScreen='true']", 0, 1000, 2, false);
		client.verifyElementFound("NATIVE", "text=${patentWebsiteLabel}", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='https://www.abbott.com/patents' and @onScreen='true']", 0);
		client.click("NATIVE", "accessibilityLabel=http://www.freestylelibre.com", 0, 1);
		waitFor(client,2);

	}
	
	/**
	 * Author: Amaresh
	 * 
	 * close Running Browser
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 */

	public void closeRunningBrowser(Client client) {
		String browser = client.getCurrentApplicationName();
		waitFor(client, 5);
		client.applicationClose(browser);
		waitFor(client, 5);

	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify the contents of Update date and time pop up
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyNetworkWarningMsg(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'Update Date')]", 0,
				5000);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='${iosEnableNetworkTimeTitle}']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='SETTINGS']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='${ok}']", 0);
		client.verifyElementFound("NATIVE", "text=${iosEnableNetworkTime}", 0);
		waitFor(client,1);

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify if Update date and time pop up not displayed
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */

	public void verifyUpdateDateandTimePopUpNotFound(Client client) {
		client.verifyElementNotFound("NATIVE",
				"xpath=//*[@text='${iosEnableNetworkTimeTitle}']", 0);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to select OK/Settings from Update date and time pop up
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param option
	 *            OK/SETTINGS
	 */

	public void selectOptioninNetworkWarning(Client client, String option) {
		client.click("NATIVE", "accessibilityLabel=" + option, 0, 1);

		waitFor(client, 2);

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Method to enable/disable network communication
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param on
	 * 		true/false
	 */

	public void enableNetwork(Client client, boolean on) {
		String deviceModel = client.getDeviceProperty("device.model");
		if(deviceModel.contains("iPhone X")){
			client.drag("NATIVE", "xpath=//*[@value='Charging']", 0, 0, 1000);

		}else{
		client.swipe("Down", 0, 500);
		}
		if (on) {
			if (client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityLabel='wifi-button' and @value='0']",
							0)) {
				client.click("NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button']", 0, 1);
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button' and @value='1']",
						0);
			}
		} else {
			if (client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityLabel='wifi-button' and @value='1']",
							0)) {
				client.click("NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button']", 0, 1);
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button' and @value='0']",
						0);
			}
		}
		if(deviceModel.contains("iPhone X")){
			client.swipe("Down", 0, 500);

		}else{
			client.swipe("Up", 0, 500);
		}
	

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Logbook page contents
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyLogbookPageContents(Client client) {
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SensorIcon']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SliderMenuIcon']" ,0);
		if (getCountryCode().equalsIgnoreCase("United States")) {
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='BGM_Drop_Plus' and @hidden='false']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='EditIconLarger']", 0);

		}
		else{
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='ADD NOTE']", 0);
		}
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='${logbookListEmpty}']", 0);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify the required date to be displayed
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param currentDate
	 *            current date
	 * @param minusDays
	 *            past how many days          
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 */

	public void verifyRequiredDateIsDisplayed(Client client, Date currentDate,
			int minusDays) throws ParseException {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DATE, -minusDays);
		verifyPickedDateIsDisplayed(client, calendar.getTime());
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Notes in Logbook list page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param time
	 *            time of note created
	 * @param attributesCnt
	 * 				no of attributes tagged to the note
	 *@throws ParseException
	 *		Throws parse exception for setting date
	 */

	public void verifyNotesInLogBookList(Client client, String time, String attributesCnt) throws InternalException, ParseException{
		if (getLanguage().contains("U.K.")) {

			time= time.toLowerCase();
		} 
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'"+time+"')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'"+getLangPropValue("note")+"')]", 0);
		if (getLanguage().contains("English (U.S.)")&&getCountryofExecution().contains("US")){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'"+getUSExecutionFormat(client,getCalendarDate(client), time)+"')]" , 0);
		}
		else{
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'"+getTimeZoneValueForSelectedDate(getDefaultCOETimeZone(),getCalendarDate(client),time)+"')]", 0);
		}
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'"+attributesCnt+"') and @accessibilityIdentifier='LogbookNoteIcon' and ../parent::*[contains(@accessibilityLabel,'"+getLangPropValue("note")+", "+time+"')]]", 0);

	}

	public String getUSExecutionFormat(Client client, String selectedDate, String time) throws ParseException{
		String dateformat = getTimeZoneValueForSelectedDate(LibrelinkConstants.US,selectedDate, time);
		String abbrevatedFormat = null;
		String format[]=null;
		if(dateformat.contains("GMT-7")){
			format= getProperty("test.timezoneformat.1").split(";");
		}else{
			format= getProperty("test.timezoneformat.0").split(";");
		}
		abbrevatedFormat = format[0];
		return abbrevatedFormat;
	}
	
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Home Screeb details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */

	public void verifyHomeScreenDetails(Client client) {
		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='LAST SCAN' and @onScreen='true']" ,0);
		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='AVERAGE' and @onScreen='true']" ,0);
		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='TIME IN TARGET' and @onScreen='true']" ,0);
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * verify report available period for n days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Number of days Data available
	 * 
	 * @param reportName 
	 *  		  Set report name
	 */

	public void verifyReportDataAvailableForNdays(Client client, String reportName, int noOfDays) {
		String dataAvl = null;
		if (client.waitForElement("NATIVE", "xpath=//*[@text='"+reportName+"']", 0, 1000)) {
			if(reportName.contains("ESTIMATED")){
				dataAvl = "Data spans "+noOfDays +" of "+ noOfDays +" days";
			}else{
			dataAvl = "Data available for "+noOfDays +" of "+ noOfDays +" days";
			}
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @accessibilityLabel='"+dataAvl+"']",
						0);
		
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Welcome screen
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 *
	 * */
	@Override
	public void verifyWelcomeScreen(Client client){
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=Freestyle_logo", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Welcome!' and @backgroundColor='0x000000']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Welcome!']", 1);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Take a few moments to learn how to understand your glucose readings with this app.']", 0);
		verifyButtonStatus(client, "next", true);
	}
	
	
}
