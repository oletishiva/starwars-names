package com.abbott.project37375iOS.uigeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.abbott.project37375iOS.uigeneral.GeneralReleaseBaseHelper;


public class GeneralFunction_T002_ReleaseBuild_Part2 extends GeneralReleaseBaseHelper {

	/**
	 * Author: ShabinaSherif
	 * 
	 * Script to verify Release Build - Covers Below areas 
	 * Help/About:  SDAIUIRS929
	 * Target Glucose Range Settings: SDAIUIRS1144, 1253
	 * Carbohydrate Unit of Measure Settings, SDAIUIRS1145, 1146
	 * text-to-speech Settings: SDAIUIRS1245
	 * Connected Account Settings: SDAIUIRS925
	 * Connected Account, adult-create, adult-signin
	 * Logbook: SDAIUIRS881, 877, 879, 891, 883, 884  
	 * Notes: (Not including note associated with scan result) : SDAIUIRS893, 905.906, 910, 1134,1135, 891, 879
	 * Reminders: SDAIUIRS912, 914, 917, 918, 260, 1203, 1183, 1158
	 * REPORTS: SDAIUIRS953,954, 957
	 * Daily Graph: SDAIUIRS1014, 1004, 1195, 1006, 1007, 954
	 * Daily pattern:SDAIUIRS961, 961, 967
	 * Time In Target:  SDAIUIRS967, 969, 1193
	 * Low Glucose Events : SDAIUIRS979
	 * Sensor Usage: SDAIUIRS1020
	 * Estimated A1c: SDAIUIRS1016
	 *  
	 */

	/**
	 * @throws Exception
	 * 		GenericException
	 */
	@Test
	public void test_T002_ReleaseBuild_Part2() throws Exception {
		
		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		launch(client);
		
		/**
		 * @stepId Step 1
		 * @Reqt SDAIUIRS912_SDAIUIRS914_SDAIUIRS917_SDAIUIRS1156_SDAIUIRS1203
		 * @Expected Create Reminders with and without repeat options
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step1);
		navigateToScreen(client,"reminders");
		addReminder(client);
		enterReminderdetails(client, "1 once", true, 0, 3, false);
		addReminder(client);
		enterReminderdetails(client, "2 Rep", true, 0, 3, true);
		addReminder(client);
		enterReminderdetails(client, "3 once", true, 0, 15, false);
		addReminder(client);
		enterReminderdetails(client, "4 Rep", true, 1, 0, true);
		addReminder(client);
		enterReminderdetails(client, "5 once", false, 00, 00, false);
		addReminder(client);
		enterReminderdetails(client, "6 once", false, 23, 59, false);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 2
		 * @Reqt SDAIUIRS912_SDAIUIRS917 SDAIUIRS1158
		 * @Expected Verify Reminder Notifications and next reminder set for repeat options
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step2);
		moveApptoBackground(client);
		openNotification(client);
		client.waitForElement("NATIVE", "xpath=//*[contains(@text,'Reminder, 2 Rep')]", 0, 180000);
		waitFor(client,2);
		verifyReminderNotification(client, "1 once",false);
		verifyReminderNotification(client, "2 Rep",false);
		clearSingleNotification(client,"1 once");
		clearSingleNotification(client,"2 Rep");
		launch(client);
		navigateToScreen(client, "reminders");
		verifyReminderStatus(client, "1 once", false,"5 once");
		verifyReminderStatus(client, "2 Rep", true,"5 once");
		capturescreenshot(client, getStepID(), true);
		launch(client);
		navigateToScreen(client, "reminders");
		
		/**
		 * @stepId Step 3
		 * @Reqt SDAIUIRS260_SDAIUIRS918_SDAIUIRS1183
		 * @Expected Verify Reminders in reminder list and next reminder text
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step3);
		selectReminder(client,"6 once",false);
		client.click("NATIVE",
				"xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='6 once']]", 0, 1);	
		waitFor(client,1);
		enableordisableReminder(client, "2 Rep",false);
		enableordisableReminder(client, "1 once",true);
		editReminder(client,"3 once");
		enterReminderdetails(client, "33 Rep", true, 0, 30, false);
		editReminder(client,"4 Rep");
		enterReminderdetails(client, "44 once", true, 0, 5, false);
		verifyReminderStatus(client, "1 once", true,"5 once");
		verifyReminderStatus(client, "2 Rep", false,"1 once");
		verifyReminderStatus(client, "33 Rep", true,"1 once");
		verifyReminderStatus(client, "44 once", true,"1 once");
		verifyReminderRepeat(client,"44 once");
		verifyReminderStatus(client, "5 once", true,"1 once");
		verifyReminderStatus(client, "6 once", false,"1 once");
		verifyNextReminderwithBackGroundColor(client,"44 once");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1123
		 * @Expected Delete reminders and verify remain 4 listed Reminders
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step4);
		deleteReminder(client,"6 once");
		deleteReminder(client,"44 once");
		verifyReminderStatus(client, "1 once", true,"5 once");
		verifyReminderStatus(client, "2 Rep", false,"1 once");
		verifyReminderStatus(client, "33 Rep", true,"1 once");
		verifyReminderStatus(client, "5 once", true,"1 once");
		capturescreenshot(client, getStepID(), true);
		deleteAllReminders(client);
		
	
		/**
		 * @stepId Step 5
		 * @Reqt SDAIUIRS877_SDAIUIRS879
		 * @Expected Verify Logbook screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step5);
		navigateToScreen(client, "logbook");
		verifyLogbookPageContents(client);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);		
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 6
		 * @Reqt SDAIUIRS893_SDAIUIRS905_SDAIUIRS906
		 * @Expected Verify created notes (Food 12am and Exercise 2pm) on Logbook detail screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step6);
		createNewNote(client, getCalendarDate(client), "00.00");
		selectNoteAttribute(client, "food");
		setFoodValue(client,"0");
		selectNoteAttribute(client, "rapidActingInsulin");
		selectNoteAttribute(client, "longActingInsulin");
		selectNoteAttribute(client, "exercise");
		scrollToBottomAddNotePage(client);
		enterNotesComments(client,
				LibrelinkConstants.TWENTY_CHARACTERS_COMMENTS);
		clickOnButtonOption(client, "done", true);
		
		createNewNote(client, getCalendarDate(client), "14.00");
		selectNoteAttribute(client, "exercise");
		scrollToBottomAddNotePage(client);
		addNoteForExercise(client, "lowIntensity", 1, 00);
		clickOnButtonOption(client, "done", true);
		
		clickCreatedNote(client, "2:00 PM");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		clickOnCalendarDate(client);
		pickDate(client, getDateFormat(-89));
		
		/**
		 * @stepId Step 7
		 * @Reqt SDAIUIRS909
		 * @Expected The Manual BG is displayed at Logbook list with value: 205 mg/dL and Time: 11:01pm
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		if(getCountryCode().contains("United States")){
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step7);
		createManualBGNote(client,205,getCalendarDate(client),"23.01");
		verifyManualBGinLogbookList(client,"205","11:01 PM");
		capturescreenshot(client, getStepID(), true);
		}
		else{
			showNotApplicableScreenShot(client,"Step7_ReqtNo_SDAIUIRS909_ManualBG_NotApplicable for Non US build");
			}
		
		/**
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1135
		 * @Expected Create a note with Food attribute for 41 svg/ptn, error message is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step8);
		createNewNote(client, getCalendarDate(client), "21.00");
		selectNoteAttribute(client, "food");
		setFoodValue(client,"41");
		clickOnButtonOption(client, "done", true);
		verifyFoodError(client,"servings");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 9
		 * @Reqt SDAIUIRS881_SDAIUIRS1135
		 * @Expected Note with Food attribute 40 svg/ptn is displayed on Logbook detail page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step9);
		clickErrorOk(client);
		setFoodValue(client,"40");
		clickOnButtonOption(client, "done", true);
		clickCreatedNote(client, "9:00 PM");
		verifyFoodInLogBookDetailPage(client, null, "servings", "40");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 10
		 * @Reqt SDAIUIRS883_SDAIUIRS884_SDAIUIRS1144
		 * @Expected Verify Logbook graph X and Y axis and Target glucose range highlighted to default value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step10);
		//Verify Glucose Graph Manually
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		

		
		/**
		 * @stepId Step 11
		 * @Reqt SDAIUIRS909
		 * @Expected The Manual BG is displayed at Logbook list with value:101 mg/dL and Time: 12:00am
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		if(getCountryCode().contains("United States")){
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step11);
		createManualBGNote(client,101,getCalendarDate(client),"00.00");
		verifyManualBGinLogbookList(client,"101","12:00 AM");
		capturescreenshot(client, getStepID(), true);
		
		}
		else{
			showNotApplicableScreenShot(client,"Step11_ReqtNo_SDAIUIRS909_ManualBG_NotApplicable for Non US build");
		}
		
		/**
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1144_SDAIUIRS1253
		 * @Expected verify Target Glucose Range displayed as 70-180 mg/dL or 3.9-10.0 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step12);
		navigateToScreen(client, "settingsMenuTitle");
		if(getUnits().contains("mg")){
			verifyandsetTGfromSettings(client,70,180);
		}else{
			verifyandsetTGfromSettings(client,3.9,10.0);
		}
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1145_SDAIUIRS1146
		 * @Expected Update Carbohydrate units to grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step13);
		navigateToSubMenuScreens(client, "carbohydrateUnitsTitle");
		setCarbohydrateUnits(client,"grams");
		capturescreenshot(client, getStepID(), true);
		
		if(getTextToSpeech().equalsIgnoreCase("yes")){
		/**
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1245
		 * @Expected Update Text to Speech settings to 'On'
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step14);
		navigateToSubMenuScreens(client, "textToSpeechTitle");
		selectspeechOption(client,"on");
		capturescreenshot(client, getStepID(), true);
		}
		else{
			showNotApplicableScreenShot(client,"Step14_ReqtNo_SDAIUIRS1245 TextToSpeech_NotApplicable for US build");
			}
		
		/**
		 * @stepId Step 15
		 * @Reqt SDAIUIRS925
		 * @Expected Verify if account settings have option to edit fields except email id
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step15);
		navigateToSubMenuScreens(client, "account");
		verifyAccountSettings(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * @stepId Step 16
		 * @Reqt SDAIUIRS925
		 * @Expected Update user details and submit then verify modified fields
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step16);
		navigateToSubMenuScreens(client, "account");
		updateAccountSettings(client);
		navigateToSubMenuScreens(client, "account");
		verifyUpdateMinorAccountSettings(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * @stepId Step 17
		 * @Reqt SDAIUIRS926
		 * @Expected Update Password
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step17);
		navigateToSubMenuScreens(client, "changePassword");
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.EIGHT_CHAR_PASSWORD,
				LibrelinkConstants.EIGHT_CHAR_PASSWORD);
		verifyPageTitles(client, "settingsMenuTitle");
		capturescreenshot(client, getStepID(), true);
		
		
		
		/**
		 * @stepId Step 18
		 * @Reqt SDAIUIRS1134_SDAIUIRS1135
		 * @Expected Create a new note (Food+insulin) and verify if the new note and previously created
		 * 				 note 12am is also displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step18);
		navigateToScreen(client,"logbook");
		createNewNote(client, getCalendarDate(client), "7.00");
		selectNoteAttribute(client, "food");
		setFoodValue(client,"101");
		selectNoteAttribute(client, "rapidActingInsulin");
		clickOnButtonOption(client, "done", true);
		clickCreatedNote(client, "7:00 AM");
		verifyInsulinLogBookDetailPage(client,"rapidActingInsulin", null);
		verifyFoodInLogBookDetailPage(client,null, "grams", "101");
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		verifyFoodInLogBookDetailPage(client,null, "servings", "0");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 19
		 * @Reqt SDAIUIRS891
		 * @Expected Verify the attribute count for each note on the Logbook detail graph
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step19);
		//Verify graph and badge count manually
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 20
		 * @Reqt SDAIUIRS883_SDAIUIRS884_SDAIUIRS1144
		 * @Expected Verify Logbook graph X-axis( midnight to midnight) and Y-axis(0 to at least 350 mg/dL (0-21 mmol/L)) and Target glucose range highlighted to 70-180 mg/dL or 3.9-10.0 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step20);
		//Verify X and Y axis and Target Glucose Range manually
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 21
		 * @Reqt SDAIUIRS879
		 * @Expected Verify the attributes of all notes and ManualBG in logbook list page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step21);
		clickOnBackIcon(client);
		verifyNotesInLogBookList(client,"12:00 AM","5");
		verifyNotesInLogBookList(client,"7:00 AM","2");
		verifyNotesInLogBookList(client,"2:00 PM","1");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 22
		 * @Reqt SDAIUIRS1014
		 * @Expected Verify the notes position and attributes count in Daily graph report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step22);
		navigateToScreen(client, "navigation_drawer_daily_graph");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 23
		 * @Reqt SDAIUIRS894_SDAIUIRS910
		 * @Expected Edit 12am note and delete 7am note and Verify the same in logbook list page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step23);
		navigateToScreen(client, "logbook");
		clickCreatedNote(client, "12:00 AM");
		editNote(client);
		unSelectNoteAttribute(client,"exercise");
		clickOnButtonOption(client, "done", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "7:00 AM");
		editNote(client);
		deleteNote(client);
		verifyNotesInLogBookList(client,"12:00 AM","4");
		verifyNotesInLogBookList(client,"2:00 PM","1");
		client.verifyElementNotFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'7:00 AM')]", 0);
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 24
		 * @Reqt SDAIUIRS1014
		 * @Expected Verify the notes position and attributes count in Daily graph report, deleted 
		 * 			note should not be present and 
		 * 			edited note attribute should be updated
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step24);
		navigateToScreen(client, "navigation_drawer_daily_graph");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 25
		 * @Reqt SDAIUIRS1004
		 * @Expected Can view last 90 days in Daily Graph Calendar
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step25);
		clickOnCalendarDate(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 26
		 * @Reqt SDAIUIRS1006_SDAIUIRS1007_SDAIUIRS1195
		 * @Expected Verify Daily graph X-axis( midnight to midnight) and Y-axis(0 to at least 350 mg/dL (0-21 mmol/L)) and Target glucose range 
		 * 				highlighted to 70-180 mg/dL or 3.9-10.0 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step26);
		pickDate(client, getDateFormat(-89));
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 27
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Daily graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step27);
		clickOnIconAndVerifyReportMessage(client, "daily_info_title");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		
		/**
		 * @stepId Step 28
		 * @Reqt SDAIUIRS954
		 * @Expected Share the report through email
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step28);
		capturescreenshot(client, getStepID(), true);
		clickShareButton(client);
		clickEmail(client);	
		sendEmail(client);
		
		/**
		 * @stepId Step 29
		 * @Reqt SDAIUIRS955
		 * @Expected Verify the current date of the Daily Graph header and no right arrow icon is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step29);
		navigateToScreen(client, "navigation_drawer_daily_graph");
		verifyDateonGraphAndArrow(client,0);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 30
		 * @Reqt SDAIUIRS957
		 * @Expected Not enough sensor data content is displayed on navigating to previous day
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step30);
		clickArrowOnTopLeftOfTheGraph(client,1);
		verifyNotEnoughSensorDataMessage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 31
		 * @Reqt SDAIUIRS961_SDAIUIRS967
		 * @Expected Verify 0 of 14 days data available text on Daily patterns page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step31);
		navigateToScreen(client, "navigation_drawer_daily_patterns");
		clickOnDays(client, 14);
		verifyReportDataAvailableForNdays(client,14);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 32
		 * @Reqt SDAIUIRS961_SDAIUIRS967
		 * @Expected Swipe to verify 0 of 7 days data available text on Daily patterns page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step32);
		swipeOnReport(client,"Left");
		verifyReportDataAvailableForNdays(client,7);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 33
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Daily Patterns graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step33);
		clickOnIconAndVerifyReportMessage(client, "daily_patterns_info_title");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		
		/**
		 * @stepId Step 34
		 * @Reqt SDAIUIRS969_SDAIUIRS970_SDAIUIRS955_SDAIUIRS971
		 * @Expected Verify 0 of 30 days data available text Time In Target page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step34);
		navigateToScreen(client, "navigation_drawer_time_in_target");
		clickOnDays(client, 30);
		verifyReportDataAvailableForNdays(client,30);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 35
		 * @Reqt SDAIUIRS969_SDAIUIRS971
		 * @Expected Swipe to verify 0 of 90 days data available text on Time In Target page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step35);
		swipeOnReport(client,"Right");
		verifyReportDataAvailableForNdays(client,90);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 36
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Time in Target graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step36);
		clickOnIconAndVerifyReportMessage(client, "time_in_target_info_title");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * @stepId Step 37
		 * @Reqt SDAIUIRS1193_SDAIUIRS957
		 * @Expected Verify Target Glucose range below the graph 70-180 mg/dL or 3.9-10.0 mmol/L and not enough sensor data text
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step37);
		clickOnButtonOption(client, "ok", true);
		verifyNotEnoughSensorDataMessage(client);
		if(getUnits().contains("mg")){
			verifyTargetGlucoseinReports(client,"70 - 180 mg/dL");
		}else{
			verifyTargetGlucoseinReports(client,"3.9 - 10.0 mmol/L");
		}
		
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 38
		 * @Reqt SDAIUIRS979_SDAIUIRS957_SDAIUIRS967
		 * @Expected Verify 0 of 7 days data available text, not enough sensor data text on Low Glucose Events page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step38);
		navigateToScreen(client, "navigation_drawer_low_glucose");
		clickOnDays(client, 7);
		verifyReportDataAvailableForNdays(client,7);
		verifyNotEnoughSensorDataMessage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 39
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Low Glucose Events graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step39);
		clickOnIconAndVerifyReportMessage(client, "low_glucose_info_title");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		
		/**
		 * @stepId Step 40
		 * @Reqt SDAIUIRS991_SDAIUIRS994_SDAIUIRS957
		 * @Expected Verify 0 of 90 days data available text, not enough sensor data text on Average Glucose page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step40);
		navigateToScreen(client, "navigation_drawer_average_glucose");
		clickOnDays(client, 90);
		verifyReportDataAvailableForNdays(client,90);
		verifyNotEnoughSensorDataMessage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 41
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Average Glucose graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step41);
		clickOnIconAndVerifyReportMessage(client, "average_glucose_info_title");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		
		/**
		 * @stepId Step 42
		 * @Reqt SDAIUIRS1020_SDAIUIRS957
		 * @Expected Verify 0 of 14 days data available text, not enough sensor data text on Sensor Usage page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step42);
		navigateToScreen(client, "navigation_drawer_sensor_usage");
		clickOnDays(client, 14);
		verifyReportDataAvailableForNdays(client,14);
		verifyNotEnoughSensorDataMessage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 43
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Sensor Usage graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step43);
		clickOnIconAndVerifyReportMessage(client, "sensor_usage_info_title");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		
		if(getEstimatedA1c().equalsIgnoreCase("yes")){
		/**
		 * @stepId Step 44
		 * @Reqt SDAIUIRS1016_SDAIUIRS957
		 * @Expected Verify not enough sensor data text is displayed on Estimated A1c page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step44);
		navigateToScreen(client, "navigation_drawer_estimated_a1c");
		verifyNotEnoughSensorDataMessage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 45
		 * @Reqt SDAIUIRS953
		 * @Expected Verify Estimated A1c graph information by tapping on i icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step45);
		clickOnIconAndVerifyReportMessage(client, "a1c_info_title");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		}
		
		else{
			showNotApplicableScreenShot(client,"Step44 & 45_Part of ReqtNo SDAIUIRS1016_SDAIUIRS957_SDAIUIRS953 EstimatedA1c_NotApplicable for US build");
			}
		/**
		 * @stepId Step 46
		 * @Reqt SDAIUIRS929
		 * @Expected Verify Application version, UDI, CE Mark, Registration Number as applicable to build
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step46);
		navigateToScreen(client, "about");
		verifyAboutInfo(client);
		verifyAppVersionUDICE(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 47
		 * @Reqt SDAIUIRS929
		 * @Expected Verify Customer service link and it is accessible
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step47);
		verifyWebSite(client);
		waitFor(client,10);
		capturescreenshot(client, getStepID(), true);
		closeRunningBrowser(client);
		

		/**
		 * @stepId Step 48
		 * @Reqt SDAIUIRS1148
		 * @Expected Network error pop up not displayed when time difference between smartphone and network is less than 5 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step48);
		advanceTime(client,0,3);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 49
		 * @Reqt SDAIUIRS1148
		 * @Expected Network error pop up is displayed when time difference between smartphone and network is greater than 5 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step49);
		advanceTime(client,0,3);
		launch(client);
		verifyNetworkWarningMsg(client);
		selectOptioninNetworkWarning(client,"OK");
		verifyNetworkWarningMsg(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 50
		 * @Reqt SDAIUIRS1148
		 * @Expected Network error pop up not displayed when time settings is set to automatic date and time
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T002_ReleaseBuild_Part2_Step50);
		selectOptioninNetworkWarning(client,"SETTINGS");
		currentSystemTime(client);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		capturescreenshot(client, getStepID(), true);
		
		unInstall(client);
	}
}
