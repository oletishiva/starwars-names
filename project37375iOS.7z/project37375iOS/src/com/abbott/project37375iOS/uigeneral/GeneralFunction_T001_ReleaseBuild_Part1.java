package com.abbott.project37375iOS.uigeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.abbott.project37375iOS.uigeneral.GeneralReleaseBaseHelper;


public class GeneralFunction_T001_ReleaseBuild_Part1 extends GeneralReleaseBaseHelper {

	/**
	 * Author: ShabinaSherif
	 * 
	 * Script to verify Release Build - Covers Below areas 
	 * Time format: 24 and 12 hour format, Network, Target Glucose Range, Settings
	 * Carbohydrate, Unit of Measure, Settings, Connected Account Settings
	 * Connected Account, adult-create, adult-signin, Logbook, Manual BG: add,
	 * date and time, error message Notes: add, edit, date and time, error message (Not
	 * including note associated with scan result) : multi Reminders: Help (All
	 * but 'Event Log'): First-Time Startup (all): Target Glucose Range Settings,
	 * Carbohydrate, Unit of Measure Settings, Connected Account Settings,
	 * Connected Account
	 *  @throws Exception
	 *  		Throws Exception as it involves date selection
	 */

	@Test
	public void test_T001_ReleaseBuild_Part1() throws Exception {

		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setEmail();
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		launch(client);


		/**
		 * @stepId Step 1
		 * @Reqt SDAIUIRS937 SDAIUIRS938
		 * @Expected Verify the welcome screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step1);
		verifyAppTourScreens(client,1,"");
		swipeWelcomescreen(client);
		verifyAppTourScreens(client,2,"checkGlucoseWithPhone");
		swipeWelcomescreen(client);
		verifyAppTourScreens(client,3,"instantAccess");
		swipeWelcomescreen(client);
		verifyAppTourScreens(client,4,"actionableInsights");
		swipeWelcomescreen(client);
		verifyAppTourScreens(client,5,"shareGlucoseInformation");
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * @stepId Step 2
		 * @Reqt SDAIUIRS939
		 * @Expected Verify the Confirm country screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step2);
		getStarted(client,true);
		verifyConfirmCountryPage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 3
		 * @Reqt SDAIUIRS939
		 * @Expected Verify Terms Of Use Screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step3);
		clickOnButtonOption(client, "next", true);
		verifyTermsAndPolicyPageDetails(client, "termsOfUseTitle");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 4
		 * @Reqt SDAIUIRS939
		 * @Expected Privacy Notice Page gets displays with following details
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step4);
		clickCheckBox(client, true);
		verifyTermsAndPolicyPageDetails(client, "privacyNoticeTitle");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 5
		 * @Reqt SDAIUIRS939
		 * @Expected The Pop-up displays with checkbox message I have read and explicitly accept the Privacy Notice 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step5);
		verifyPagePopUp(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 6
		 * @Reqt SDAIUIRS939
		 * @Expected Accept Privacy notice from pop up and it should display Create account screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step6);
		clickAccept(client);
		verifyPageTitles(client, "nameAndBirthDateTitle");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1238 SDAIUIRS938
		 * @Expected A adult Account Login screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step7);
		createNewAccountDetails(client, "Tester", "Adult", "1.10.1967");
		clickOnButtonOption(client, "next", true);
		verifyAdultLoginScreen(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1238 SDAIUIRS1239
		 * @Expected Enter email and password and click on create account, Also verify UOM screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step8);
		adultLoginDetails(client, getEmail(), LibrelinkConstants.CURRENT_PASSWORD, LibrelinkConstants.CURRENT_PASSWORD, true);
		clickOnButtonOption(client, "createAccountSubmitButtonText", true);
		verifyUnitOfMeasurementPageDetails(client);
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * @stepId Step 9
		 * @Reqt SDAIUIRS943
		 * @Expected Click Next and verify Target Glucose default screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step9);
		clickOnButtonOption(client, "next", true);
        if(client.isElementFound("NATIVE", "xpath=//*[@class='UIView' and ./*[@accessibilityLabel='OK']]", 0)){
        	 client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK' and @class='LibreLink.LLDialogButton']", 0, 1);
        }
		verifyTargetGlucoseRangePageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 10
		 * @Reqt SDAIUIRS943
		 * @Expected Modify glucose range and click on Next. Carbohydrates Unit screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step10);
		if(getUnits().contains("mg")){
			setTargetGlucoseRange(client,70,71);
		}else{
			setTargetGlucoseRange(client,3.9,4.0);
		}
		clickOnButtonOption(client, "next", true);
		verifyCarbohydrateUnitsPageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1292
		 * @Expected Select Gram option and click on done, Welcome screen should be displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step11);
		selectCarbohydrateUnits(client, "grams");
		clickOnButtonOption(client, "done", true);
		verifyWelcomeScreen(client);
		capturescreenshot(client, getStepID(), true);
		
		
		if (getSafetyConfig().equalsIgnoreCase("yes")) {
		/**
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1292
		 * @Expected click on Safety Information and Safety information content should be displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step12);
		verifySafetyInfo(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIconWebView(client);
		}
		else
		{
			showNotApplicableScreenShot(client,"Step12_SDAIUIRS1292_Safety Information screen_Not applicable as per Configuration for that build");
		}
		/**
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1217
		 * @Expected My Glucose screen should be displayed on the tap of NEXT in welcome screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step13);
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"myGlucoseExplanationTitle");
		verifyMyGlucoseInfoPage(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1293
		 * @Expected Glucose Background Color Screen displays the various results colors.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step14);
		swipePage(client, "Right");
		verifyPageTitles(client, "backgroundGlucoseColorsTitle");
		verifyGlucoseBackgroundColor(client,false);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 15
		 * @Reqt SDAIUIRS1247
		 * @Expected Glucose Trend Arrow screen gets displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step15);
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client, "trendExplanationTitle");
		verifyGlucoseTrendArrow(client,false);
		capturescreenshot(client, getStepID(), true);
		
		if (getNAIconConfig().equalsIgnoreCase("yes")) {
		
		/**
		 * 
		 * @stepId Step 16
		 * @Reqt  SDAIUIRS1294
		 * @Expected Glucose Reading fourth screen is displayed and it shows Non-Actionable Icon image
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step16);
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"treatmentDecisions");
		verifyTreatmentDecisionScreen1(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt  SDAIUIRS1295
		 * @Expected Glucose Reading 5th screen is displayed and it shows the action to be performed on observing Non-actionable result
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step17);
		clickOnButtonOption(client, "next", true);
		verifyPageTitles(client,"treatmentDecisions");
		verifyTreatmentDecisionScreen2(client,false);
		capturescreenshot(client, getStepID(), true);
		}
		else
		{
			showNotApplicableScreenShot(client,"Step16 & 17 SDAIUIRS1294_SDAIUIRS1295 Treatment Decisions screen are not applicable as per Configuration for that build");
		}
		
		/**
		 * 
		 * @stepId Step 18
		 * @Reqt  SDAIUIRS943
		 * @Expected On Allowing notification,Home Screen gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step18);
		clickOnButtonOption(client, "done", true);
		allowNotifications(client);
		capturescreenshot(client, getStepID(), true);
		/**
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1137
		 * @Expected click on how to apply a sensor link from Help and verify all 10 screens
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step19);
		verifyHowToApplyNewSensorLink(client, true);
		verifyHowToApplyNewSensorSteps(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS1137
		 * @Expected Applying a Sensor section contains total 10 screens with instructions for How to Apply a new sensor.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step20);
		clickOnBackIconWebView(client);
		navigateToScreen(client,"help");
		verifyandClickHelpSubMenu(client,"How to apply a Sensor",true);
		verifyHowToApplyNewSensorSteps(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 21
		 * @Reqt SDAIUIRS1138
		 * @Expected click on how to scan a sensor link and verify all 3 screens
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step21);
		clickOnBackIcon(client);
		navigateToScreen(client,"home");
		clickOnButtonOption(client, "next", true);
		verifyandClickHowToScanNewSensorLink(client);
		verifyHowToScanSensorSteps(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 22
		 * @Reqt SDAIUIRS1138
		 * @Expected click on how to scan a sensor link from Help and verify all 3 screens
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step22);
		clickOnBackIcon(client);
		navigateToScreen(client,"help");
		verifyandClickHelpSubMenu(client, "How to scan a Sensor", true);
		verifyHowToScanSensorSteps(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 23
		 * @Reqt SDAIUIRS1283 SDAIUIRS1284
		 * @Expected click on Glucose readings link from help and verify 5 or 3 screens based on Config
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step23);
		clickOnBackIcon(client);
		verifyandClickHelpSubMenu(client, "Glucose Readings", true);
		verifyMyGlucoseInfoPage(client,false);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 24
		 * @Reqt  SDAIUIRS1285
		 * @Expected Verify Glucose Reading second screen is displayed and it shows Background color explanation
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step24);
		swipePage(client, "Right");
		verifyGlucoseBackgroundColor(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 25
		 * @Reqt  SDAIUIRS1286
		 * @Expected Glucose Reading third screen is displayed and it shows Trend Arrow explanation
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step25);
		swipePage(client, "Right");
		verifyGlucoseTrendArrow(client,false);
		capturescreenshot(client, getStepID(), true);

		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 26
			 * @Reqt  SDAIUIRS1287
			 * @Expected Glucose Reading fourth screen is displayed and it shows Non-Actionable Icon image
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step26);
			swipePage(client, "Right");
			verifyTreatmentDecisionScreen1(client,false);
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 27
			 * @Reqt  SDAIUIRS1288
			 * @Expected Glucose Reading 5th screen is displayed and it shows the action to be performed on observing Non-actionable result
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step27);
			swipePage(client, "Right");
			verifyTreatmentDecisionScreen2(client,false);
			capturescreenshot(client, getStepID(), true);

		}else{
			showNotApplicableScreenShot(client,"Step26 & 27_SDAIUIRS1287 SDAIUIRS1288_Treatment Decisions Info screen_Not applicable as per Configuration for that build");
		}
		/**
		 * @stepId Step 28
		 * @Reqt SDAIUIRS1140
		 * @Expected click on User Manual link from help and verify User Manual is not blank
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step28);
		clickOnBackIcon(client);
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='User’s Manual']", 0, 1000);
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='User’s Manual']", 0, 1);
		waitForProgress(client);
		verifyUsersManualGuide(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 29
		 * @Reqt SDAIUIRS1187
		 * @Expected click on Terms of Use link from help and verify it gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step29);
		clickOnBackIconWebView(client);
		verifyandClickHelpSubMenu(client, "Terms of Use", true);
		verifyPageTitles(client,"termsOfUseTitle");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 30
		 * @Reqt SDAIUIRS1191
		 * @Expected click on Privacy Notice link from help and verify it gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step30);
		clickOnBackIconWebView(client);
		verifyandClickHelpSubMenu(client, "Privacy Notice", true);
		verifyPageTitles(client,"privacyNoticeTitle");
		capturescreenshot(client, getStepID(), true);
				

		if (getSafetyConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 31
			 * @Reqt  SDAIUIRS1289 
			 * @Expected App displays an option to access the Safety Information and on click Safety information page should opened
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step31);
			clickOnBackIconWebView(client);	
			verifyHelpLinksInOrder(client,"Safety Information", "below");
			verifyandClickHelpSubMenu(client, "Safety Information", true);
			verifySafetyInformation(client);
			capturescreenshot(client, getStepID(), true);


		}else{
			showNotApplicableScreenShot(client,"Step31_SDAIUIRS1289_Safety Information screen_Not applicable as per Configuration for that build");
		}

		if (getQuickStartConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 32
			 * @Reqt  SDAIUIRS1290
			 * @Expected App displays an option to access the Quick start guide,On click Quick start guide should be displayed
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step32);
			clickOnBackIconWebView(client);
			verifyHelpLinksInOrder(client,"Quick Start Guide", "above");
			verifyandClickHelpSubMenu(client, "Quick Start Guide", true);
			verifyQuickStartGuide(client);	
			capturescreenshot(client, getStepID(), true);
		}
			else{
				showNotApplicableScreenShot(client,"Step32_SDAIUIRS1290_Quick Start Guide screen_Not applicable as per Configuration for that build");
			}
			
		if (getQuickRefConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 33
			 * @Reqt  SDAIUIRS1291 SDAISRS249
			 * @Expected App displays an option to access the Quick Reference Guide,on click Quick reference guide should displayed
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step33);
			clickOnBackIconWebView(client);
			verifyHelpLinksInOrder(client,"Quick Reference Guide", "above");
			verifyandClickHelpSubMenu(client, "Quick Reference Guide", true);
			verifyQuickReferenceGuide(client);
			capturescreenshot(client, getStepID(), true);
			
		}else{
			showNotApplicableScreenShot(client,"Step33_SDAIUIRS1291_SDAISRS249_Quick Reference Guide screen_Not applicable as per Configuration for that build");
		}
		
		/**
		 * @stepId Step 34
		 * @Reqt SDAIUIRS893
		 * @Expected The Note created with food attribute Breakfast 400 grams with today date and time 05:30
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step34);
		clickOnBackIconWebView(client);
		navigateToScreen(client,"logbook");
		createNewNote(client, getCalendarDate(client), "5.30");
		selectNoteAttribute(client, "food");
		setFoodAttribute(client, "breakfast");
		setFoodValue(client,"400");
		clickOnButtonOption(client, "done", true);
		clickCreatedNote(client, "05:30");
		verifyFoodInLogBookDetailPage(client, "breakfast", "grams", "400");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 35
		 * @Reqt SDAIUIRS1134
		 * @Expected Edit note and enter value 401. Error msg will be displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step35);
		editNote(client);
		setFoodValue(client,"401");
		clickOnButtonOption(client, "done", true);
		verifyFoodError(client,"grams");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 36
		 * @Reqt SDAIUIRS894
		 * @Expected The Note created with food attribute Breakfast 0 grams with today date and time 05:30 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step36);
		clickErrorOk(client);
		setFoodValue(client,"0");
		clickOnButtonOption(client, "done", true);
		verifyFoodInLogBookDetailPage(client, "breakfast", "grams", "0");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 37
		 * @Reqt SDAIUIRS893
		 * @Expected The Note created with Rapid_Acting Insulin 200 units with yesterday date and time 12:00 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step37);
		clickOnBackIcon(client);
		clickCalendarArrow(client,-1);
		createNewNote(client, getCalendarDate(client), "12.00");
		selectNoteAttribute(client, "rapidActingInsulin");
		addNoteForInsulin(client,0, "200");
		clickOnButtonOption(client, "done", true);
		clickCreatedNote(client, "12:00");
		verifyInsulinLogBookDetailPage(client,"rapidActingInsulin", "200");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 38
		 * @Reqt SDAIUIRS1201
		 * @Expected Edit insulin note for 201 and verify the error msg
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step38);
		editNote(client);
		addNoteForInsulin(client,0, "201");
		clickOnButtonOption(client, "done", true);
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 39
		 * @Reqt SDAIUIRS894
		 * @Expected The Note created with Rapid_Acting Insulin 0.1 units 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step39);
		clickErrorOk(client);
		addNoteForInsulin(client,0, "0.1");
		clickOnButtonOption(client, "done", true);
		verifyInsulinLogBookDetailPage(client,"rapidActingInsulin", "0.1");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 40
		 * @Reqt SDAIUIRS893
		 * @Expected The Note created with Long_Acting Insulin 0.1 units

		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step40);
		clickOnBackIcon(client);
		createNewNote(client, getCalendarDate(client), "23.59");
		selectNoteAttribute(client, "longActingInsulin");
		addNoteForInsulin(client,0, "0.1");
		clickOnButtonOption(client, "done", true);
		clickCreatedNote(client, "23:59");
		verifyInsulinLogBookDetailPage(client,"longActingInsulin", "0.1");
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 41
		 * @Reqt SDAIUIRS1201
		 * @Expected Edit insulin note for 201 and verify the error msg
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step41);
		editNote(client);
		addNoteForInsulin(client, 0,"201");
		clickOnButtonOption(client, "done", true);
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 42
		 * @Reqt SDAIUIRS894
		 * @Expected Enter value 200 and submit the note and verify The Note created with Long_Acting Insulin 200 units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step42);
		clickErrorOk(client);
		addNoteForInsulin(client,0, "200");
		clickOnButtonOption(client, "done", true);
		verifyInsulinLogBookDetailPage(client,"longActingInsulin", "200");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		if(getCountryCode().contains("United States")){
			/**
			 * @stepId Step 43
			 * @Reqt SDAIUIRS909_SDAIUIRS908
			 * @Expected Create a Manual BG note value 20 mg/dL
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step43);
			clickCalendarArrow(client,1);
			createManualBGNote(client,20,getCalendarDate(client),"5.30");
			verifyManualBGinLogbookList(client,"20","05:30");
			capturescreenshot(client, getStepID(), true);

			/**
			 * @stepId Step 44
			 * @Reqt SDAIUIRS1188
			 * @Expected Error displayed when Manual BG value is less than 20
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step44);
			clickCalendarArrow(client,-2);
			createManualBGNote(client,19,getCalendarDate(client),"12.30");
			verifyBGError(client);
			capturescreenshot(client, getStepID(), true);

			/**
			 * @stepId Step 45
			 * @Reqt SDAIUIRS909 SDAIUIRS1182
			 * @Expected The Manual BG is displayed at Logbook list:value 500 mg/dL
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step45);
			clickErrorOk(client);
			createManualBGNote(client,500,null,null);
			verifyManualBGinLogbookList(client,"500","12:30");
			capturescreenshot(client, getStepID(), true);
			clickCalendarArrow(client,1);
		}
		
		else{
			showNotApplicableScreenShot(client,"Step43,44 & 45 ReqtNo SDAIUIRS908_SDAIUIRS909 SDAIUIRS1188_SDAIUIRS1182 ManualBG_NotApplicable for Non US build");
		}
		
		/**
		 * @stepId Step 46
		 * @Reqt SDAIUIRS893
		 * @Expected The Note created with Exercise attribute 12 hr 59 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step46);
		clickCalendarArrow(client,1);
		createNewNote(client, getCalendarDate(client), "12.00");
		selectNoteAttribute(client, "exercise");
		addNoteForExercise(client, "lowIntensity", 12, 59);
		clickOnButtonOption(client, "done", true);
		clickCreatedNote(client, "12:00");
		verifyExerciseIntensityInLogBookDetailPage(client, "lowIntensity", 12, 59);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 47
		 * @Reqt SDAIUIRS894
		 * @Expected Verify The Note created with comment attribute:
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step47);
		editNote(client);
		unSelectNoteAttribute(client,"exercise");
		scrollToBottomAddNotePage(client);
		enterNotesComments(client,
				LibrelinkConstants.TWENTY_CHARACTERS_COMMENTS);
		clickOnButtonOption(client, "done", true);
		verifyNotesComments(client,
				LibrelinkConstants.TWENTY_CHARACTERS_COMMENTS);
		capturescreenshot(client, getStepID(), true);

        /**
         * @stepId Step 48
         * @Reqt SDAIUIRS879_SDAIUIRS1219
         * @Expected Verify Created notes icon on Logbook list screen
         * @Dependancy Script cannot proceed if this step fails
         * 
          **/
         setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step48_1);
         clickOnBackIcon(client);
         verifyNotesInLogBookList(client,"12:00","1");
         verifyNotesInLogBookList(client,"05:30","1");
         if(getCountryCode().contains("United States")){
                         verifyManualBGinLogbookList(client,"20","05:30");
         }
         capturescreenshot(client, getStepID(), true);
         setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step48_2);
         clickCalendarArrow(client,-1);
         verifyNotesInLogBookList(client,"23:59","1");
         verifyNotesInLogBookList(client,"12:00","1");
         capturescreenshot(client, getStepID(), true);     

         /**
         * @stepId Step 49
         * @Reqt SDAIUIRS891_SDAIUIRS1014
         * @Expected Verify Created notes icon on Logbook detail and Daily Graph screen
         * @Dependancy Script cannot proceed if this step fails
         * 
          **/
         setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step49_1);
         clickCreatedNote(client, "12:00");
         capturescreenshot(client, getStepID(), true);
         setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step49_2);
         clickOnBackIcon(client);
         clickCalendarArrow(client,1);
         clickCreatedNote(client, "12:00");
         capturescreenshot(client, getStepID(), true);
         setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step49_3);
         clickOnBackIcon(client);
         navigateToScreen(client,"daily_graph");
         capturescreenshot(client, getStepID(), true);
         setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step49_4);
         clickArrowOnTopLeftOfTheGraph(client,1);
         capturescreenshot(client, getStepID(), true);
         navigateToScreen(client,"home");

		
		/**
		 * @stepId Step 50
		 * @Reqt SDAIUIRS1239_SDAIUIRS1145_SDAIUIRS1146
		 * @Expected Home screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T001_ReleaseBuild_Part1_Step50);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		unInstall(client);
		install(client);
		launch(client);
		signIn(client, getEmail(),LibrelinkConstants.CURRENT_PASSWORD);
		defaultSettings(client,"servings",12.5);
		allowNotifications(client);
		launch(client);
		verifyHomePage(client);
		capturescreenshot(client, getStepID(), true);

	}
}
