package com.abbott.project37375iOS.uigeneral;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.abbott.project37375iOS.main.PreRequisite;

@RunWith(Suite.class)
@Suite.SuiteClasses({PreRequisite.class,
	GeneralFunction_T001_ReleaseBuild_Part1.class, GeneralFunction_T002_ReleaseBuild_Part2.class})
public class TestSuite {
  //nothing
}
