package com.abbott.project37375iOS.uigeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.abbott.project37375iOS.uigeneral.GeneralReleaseBaseHelper;

public class GeneralFunction_T003_DebugBuild_Part3 extends GeneralReleaseBaseHelper {

//ONLY FOR SIT Execution
	/**
	 * Author: ShabinaSherif
	 * 
	 * Script to verify Debug Build - Covers Below areas 
	 * This test covers screens including Result Home screen, logbook and reports
	 * 
	 * 	Test area include:
	 * 	SDAIUIRS861, SDAIUIRS863, SDAIUIRS864, SDAIUIRS868, SDAIUIRS871 
	 * 	SDAIUIRS937, SDAIUIRS938, SDAIUIRS939, SDAIUIRS963, SDAIUIRS967 
	 * 	SDAIUIRS970, SDAIUIRS971, SDAIUIRS977, SDAIUIRS1021, SDAIUIRS1238 
	 * 	SDAIUIRS1239, SDAIUIRS992 SDAIUIRS993 SDAIUIRS995, SDAIUIRS1004 SDAIUIRS1005 SDAIUIRS1195 
	 * 	SDAIUIRS1250, SDAIUIRS1018, SDAIUIRS1131, SDAIUIRS1243, SDAIUIRS1168
	 * 	SDAIUIRS1127, SDAIUIRS860 SDAIUIRS870, SDAIUIRS1241, SDAIUIRS878, SDAIUIRS879, SDAIUIRS880
	 * 	SDAIUIRS884, SDAIUIRS885, SDAIUIRS886, SDAIUIRS888, SDAIUIRS889 
	 * 	SDAIUIRS981, SDAIUIRS982, SDAIUIRS983, SDAIUIRS984 
	 * 	SDAIUIRS1007, SDAIUIRS1011, SDAIUIRS1012, SDAIUIRS1014 
	 * 	SDAIUIRS954, SDAIUIRS1131 SDAIUIRS1127 
	 * 	 
	 * 	Datasets:
	 * 	90days_autoDate_Notes.json
	 * 	9hr-notes-chicago.json
	 * 
	 *  @throws Exception
	 *  		Throws Exception as it involves date selection
	 */

	@Test
	public void test_T003_DebugBuild_Part3() throws Exception {

		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		setTheTimeAlone(client,"12:00");
		selectSkipForDebugging(client);
		loadTestData(client,  "MOCK_2","ADC","90days_autoDate_Notes.json");
		

		/**
		 * @stepId Step 1
		 * @Reqt SDAIUIRS861 SDAIUIRS863 SDAIUIRS864 SDAIUIRS868 SDAIUIRS871
		 * @Expected Verify the HomeScreen with data
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step1);
		navigateToScreen(client, "home");
		verifyHomeScreenDetails(client);
		client.verifyElementFound("NATIVE","xpath=//*[contains(@text,':') and ./preceding-sibling::*[@accessibilityLabel='LAST SCAN']]" ,0);		
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 2
		 * @Reqt SDAIUIRS963 SDAIUIRS967
		 * @Expected Verify the Daily Pattern Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step2);
		navigateToScreen(client, "navigation_drawer_daily_patterns");
		clickOnDays(client, 7);
		swipeOnReport(client,"Right");
		swipeOnReport(client,"Right");
		swipeOnReport(client,"Right");
		verifyReportDataAvailableForNdays(client,  "DAILY PATTERNS",90);
		capturescreenshot(client, getStepID(), true);

		/**
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1021
		 * @Expected Verify the Sensor Usage Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step3);
		navigateToScreen(client, "navigation_drawer_sensor_usage");
		clickOnDays(client, 90);
		swipeOnReport(client,"Left");
		swipeOnReport(client,"Left");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 4
		 * @Reqt SDAIUIRS970 SDAIUIRS971 SDAIUIRS977
		 * @Expected Verify the Time In target Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step4);
		navigateToScreen(client, "navigation_drawer_time_in_target");
		clickOnDays(client, 7);
		verifyReportDataAvailableForNdays(client,  "TIME IN TARGET",7);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 5
		 * @Reqt SDAIUIRS992 SDAIUIRS993 SDAIUIRS995
		 * @Expected Verify the Average Glucose Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step5);
		navigateToScreen(client, "navigation_drawer_average_glucose");
		clickOnDays(client, 30);
		verifyReportDataAvailableForNdays(client,  "AVERAGE GLUCOSE",30);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1004 SDAIUIRS1005 SDAIUIRS1195
		 * @Expected Verify the Daily Graph Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step6);
		navigateToScreen(client, "navigation_drawer_daily_graph");
		clickOnCalendarDate(client);
		pickDate(client, getDateFormat(-89));
		capturescreenshot(client, getStepID(), true);
		
		if(getEstimatedA1c().equalsIgnoreCase("yes")){
		/**
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1250 SDAIUIRS1018
		 * @Expected Verify the Estimated A1c Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step7);
		navigateToScreen(client, "navigation_drawer_estimated_a1c");
		verifyReportDataAvailableForNdays(client,  "ESTIMATED A1C",90);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='a1cDensity' and contains(@text,'mmol/mol')]", 0);
		capturescreenshot(client, getStepID(), true);
		}
		else{
			showNotApplicableScreenShot(client,"Step7_Estimated A1c_NotApplicable");
		}
		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		changeTimeZone(client, LibrelinkConstants.USZone);
		setTheTimeAlone(client,"16:00");
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		launch(client);
		navigateToScreen(client, "settingsMenuTitle");
		if(getUnits().contains("mg")){
			verifyandsetTGfromSettings(client,150,180);
		}else{
			verifyandsetTGfromSettings(client,8.3,10.0);
		}
		loadTestData(client,  "MOCK_2","ADC","9hr-notes-chicago.json");
		
		/**
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1131 SDAIUIRS1243 SDAIUIRS1168
		 * @Expected Verify the Estimated A1c Report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step8);
		navigateToMyGlucosePage(client);
		if (getUnits().equals("mg/dL")) {
			verifyGlucoseValueandUnitsMyGlucose(client,"50");
		}else{
			verifyGlucoseValueandUnitsMyGlucose(client,"2.8");
		}
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1127
		 * @Expected Low Glucose - Check Glucose Alarm
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step9_1);
		clickAlertIcon(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step9_2);
		clickSetCheckGlucoseReminder(client);
		selectLowReminderTime(client, 15);
		clickOnButtonOption(client, "start", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "reminders");
		verifyCheckGlucoseReminderCountdown(client, "14:");
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * @stepId Step 10
		 * @Reqt SDAIUIRS860 SDAIUIRS870
		 * @Expected Verify the Home Screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step10);
		navigateToScreen(client, "home");
		verifyHomeScreenDetails(client);
		client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'"+getUnits()+"') and ./preceding-sibling::*[@accessibilityLabel='LAST SCAN']]" ,0);		
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1241
		 * @Expected Verify the Time Zone text
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step11);
		clickOnNotesorTimeZoneorBG(client, "timeChangePointWithIndex",0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[contains(@text,'Time zone change from')]",
				0);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "ok", true);
		
		/**
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1127
		 * @Expected Verify the Timer Expired Notification
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step12);
		advanceTime(client, 0, 12);
		waitFor(client, 2);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");
		launch(client);
		
		/**
		 * @stepId Step 13
		 * @Reqt SDAIUIRS878 SDAIUIRS879 SDAIUIRS880
		 * @Expected Verify the Logbook
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step13);
		navigateToScreen(client, "logbook");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 14
		 * @Reqt SDAIUIRS884 SDAIUIRS885 SDAIUIRS886 SDAIUIRS888 SDAIUIRS889
		 * @Expected Verify the Logbook detail screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step14);
		if (getUnits().equals("mg/dL")) {
			clickCreatedNote(client, "50");
		}else{
			clickCreatedNote(client, "2.8");
		}
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * @stepId Step 15
		 * @Reqt SDAIUIRS981 SDAIUIRS982 SDAIUIRS983 SDAIUIRS984
		 * @Expected Verify the Low Glucose events report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step15);
		navigateToScreen(client, "navigation_drawer_low_glucose");
		clickOnDays(client, 14);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @accessibilityLabel='Data available for 1 of 14 days']",
				0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Total Events: 1']",
				0);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 16
		 * @Reqt SDAIUIRS1007 SDAIUIRS1011 SDAIUIRS1012 SDAIUIRS1014
		 * @Expected Verify the daily graph report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step16);
		navigateToScreen(client, "navigation_drawer_daily_graph");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * @stepId Step 17
		 * @Reqt SDAIUIRS954
		 * @Expected Share the report
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.GeneralFunction_T003_DebugBuild_Part3_Step17);
		clickShareButton(client);
		clickAddToNotes(client);
		capturescreenshot(client, getStepID(), true);
		saveNotes(client);
		
		selectingSASMode(client,"DEFAULT");
        currentSystemTime(client);
	}
}
