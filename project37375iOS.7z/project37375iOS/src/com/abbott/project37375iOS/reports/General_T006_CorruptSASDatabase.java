package com.abbott.project37375iOS.reports;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class General_T006_CorruptSASDatabase extends ReportsHelper {

	@Test
	public void test_T006_CorruptSASDatabase() throws Exception {

		/**
		 * 
		 * @stepId Step 1:Pre-Condition
		 * @Reqt NA
		 * @Expected Settings:Set the smart device Date to Sept 12 2016.From
		 *           Debug Drawer and set the test data
		 *           Load Data file to"S24_ThreeHours.json" using MOCK_2 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T006_CorruptSASDatabase_Step1);
		setTheDateAndTime(client, 12, 9, 2016, "00:00");
		loadTestData(client, "MOCK_2","ADC", "S24_ThreeHours.json");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAISRS829
		 * @Expected Navigate to Time In Target report and verify if graph is displayed
		 * 			for 7 and 14 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T006_CorruptSASDatabase_Step2);
		navigateToScreen(client, "Time In Target");
		clickOnDays(client, 14);
		verifyTITGraphDisplayed(client,true);
		clickOnDays(client, 7);
		verifyTITGraphDisplayed(client,true);
		capturescreenshot(client, getStepID(), true);
		navigateToScreen(client, "Home");

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAISRS829
		 * @Expected Select corrupt option from Debug drawer and on selecting
		 * 			14 days app should crash
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T006_CorruptSASDatabase_Step3);
		openDebugDrawer(client);
		client.click("NATIVE", "accessibilityLabel=CORRUPT IT", 0, 1);
		navigateToScreen(client, "Time In Target");
		clickOnDays(client, 7);
		verifyTITGraphDisplayed(client,true);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment14Days']", 0);
		client.click("NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReportSegment14Days']", 0, 1);
		waitFor(client,1);

		verifyTITGraphDisplayed(client,false);
		client.verifyElementNotFound("NATIVE", "xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo']", 0);
		capturescreenshot(client, getStepID(), true);

		unInstall(client);
		currentSystemTime(client);
		install(client);
		

	}
}
