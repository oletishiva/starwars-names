package com.abbott.project37375iOS.reports;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class General_T004_Time_NetworkTime_Setting_Check extends ReportsHelper {

	@Test
	public void test_T004_Time_NetworkTime_Setting_Check() throws Exception {

		/**
		 *
		 * @stepId Pre-Condition
		 * @Reqt NA
		 * @Expected Log out the application and enable automatic date and
		 			 time in Device
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		unInstall(client);
		install(client);

		/**
		 *
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1148_SDAISRS126
		 * @Expected Auto Date & Time disabled: Automatic Date and Time error
		 * 			 message pop up is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step1);
		advanceTime(client, 0, -5);
		launch(client);
		createDefaultAccount(client,"Adult");
		launch(client);
		verifyNetworkWarningMsg(client);
		selectOptioninNetworkWarning(client, "OK");
		verifyNetworkWarningMsg(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time enabled pop up vanished. 
		 * 			 The Logbook screen is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step2);

		selectOptioninNetworkWarning(client, "SETTINGS");
		advanceTime(client, 0, 1);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		navigateToScreen(client, "Logbook");
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time disabled: Automatic Date and Time error
		 * 			 message pop up is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step3);
		logOutUser(client);
		advanceTime(client, 0, -1);
		launch(client);
		clickSignInButton(client, true);
		signInClick(client, getEmail(),LibrelinkConstants.CURRENT_PASSWORD, true);
		clickAndAcceptPage(client,"Terms of Use");
		clickAndAcceptPage(client,"Privacy Notice");
		defaultSettings(client,"grams");
		allowNotifications(client);
		verifyHomePage(client);
		verifyNetworkWarningMsg(client);
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time enabled pop up vanished.
		 * 			 The Logbook screen is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step4);
		selectOptioninNetworkWarning(client, "SETTINGS");
		advanceTime(client, 0, 1);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		navigateToScreen(client, "Logbook");
		capturescreenshot(client, getStepID(), true);
		logOutUser(client);

		
		/**
		 *
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time disabled: Automatic Date and Time error
		 *           while creating minor account
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step5);

		advanceTime(client, 0, 11);
		launch(client);
		createDefaultAccount(client,"Minor");
		verifyNetworkWarningMsg(client);
		selectOptioninNetworkWarning(client, "OK");
		verifyNetworkWarningMsg(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time enabled pop up vanished.
		 *           The LogBook screen is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step6);

		selectOptioninNetworkWarning(client, "SETTINGS");
		advanceTime(client, 0, -2);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		navigateToScreen(client, "Logbook");
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time disabled: Automatic Date and Time error
		 *           message pop up is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step7);

		logOutUser(client);
		advanceTime(client, 0, 2);
		launch(client);
		clickSignInButton(client, true);
		signInClick(client, getEmail(),
				LibrelinkConstants.CURRENT_PASSWORD, true);
		clickAndAcceptPage(client,"Terms of Use");
		clickAndAcceptPage(client,"Privacy Notice");
		defaultSettings(client,"grams");
		allowNotifications(client);
		verifyHomePage(client);
		verifyNetworkWarningMsg(client);
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time enabled pop up vanished . The Logbook
		 *           screen is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step8);
		selectOptioninNetworkWarning(client, "SETTINGS");
		advanceTime(client, 0, -2);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		navigateToScreen(client, "Logbook");
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time disabled: Automatic Date and Time error
		 *           message pop up is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step9);

		advanceTime(client, 0, 2);
		launch(client);
		selectOptioninNetworkWarning(client, "OK");
		verifyNetworkWarningMsg(client);
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1148
		 * @Expected Auto Date & Time enabled pop up vanished.
		 *           The LogBook screen is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step10);

		enableNetwork(client, false);
		launch(client);
		selectOptioninNetworkWarning(client, "OK");
		verifyUpdateDateandTimePopUpNotFound(client);
		navigateToScreen(client, "Logbook");
		capturescreenshot(client, getStepID(), true);


		/**
		 * 
		 * @stepId Pre-Condition
		 * @Reqt NA
		 * @Expected Log out the application and enable automatic date and time
		 *           in Device
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		openDateTimeSettings(client);
		automaticDateAndTime(client, true);
		closePhoneSettings(client);
		enableNetwork(client, true);
		launch(client);
		logOutUser(client);

		/**
		 *
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1148
		 * @Expected Home screen is displayed
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.General_T004_Time_NetworkTime_Setting_Check_Step11);

		advanceTime(client, 0, -5);
		launch(client);
		createDefaultAccount(client,"Adult");
		selectOptioninNetworkWarning(client, "SETTINGS");
		changeTimeZone(client, LibrelinkConstants.ESTZone);
		advanceTime(client, 0, 1);
		launch(client);
		verifyUpdateDateandTimePopUpNotFound(client);
		verifyHomePage(client);
		capturescreenshot(client, getStepID(), true);

		selectingSASMode(client,"DEFAULT");
		changeTimeZone(client, getDefaultTimeZone());
		currentSystemTime(client);

	}

}
