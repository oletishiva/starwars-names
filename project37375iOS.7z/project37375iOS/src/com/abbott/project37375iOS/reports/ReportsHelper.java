package com.abbott.project37375iOS.reports;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.abbott.project37375iOS.main.BaseHelper;
import com.experitest.client.Client;


public class ReportsHelper extends BaseHelper {

	/**
	 * Author: ShabinaSherif
	 * 
	 * Click On Glucose Units
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param glucoseUnits
	 *            Selecting Glucose Units
	 * 
	 */

	public void clickOnGlucoseUnits(Client client, String glucoseUnits) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='Logbook']", 0, 10000)) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityLabel='"+ glucoseUnits +"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, 1);
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Selecting Notes
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param note
	 *            Selecting Note from AddNote(Logbook)
	 * 
	 */

	public void selectingNotes(Client client, String note) {
		if (client.waitForElement("NATIVE", "text=Add Note", 0, 10000)) {
			String isselected = client.runNativeAPICall("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='"+note+"']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
			if(isselected.equals("0")){
				client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='"+note+"']]", 0, 1);
			}

		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Netwrok warning message
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyNetworkWarningMsg(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'Update Date')]", 0,
				5000);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Update Date & Time']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='SETTINGS']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0);
		client.verifyElementFound("NATIVE", "text=${iosEnableNetworkTime}", 0);

	}

	/**
	 * Author: LourdeNoelRini/ShabinaSherif
	 * 
	 * Select OK option on time Update in Date and Time settings
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param option
	 *            Selecting option
	 */

	public void selectOptioninNetworkWarning(Client client, String option) {

		if (client.isElementFound("NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'Update Date')]", 0)) {
			client.click("NATIVE", "accessibilityLabel=" + option, 0, 1);
			waitFor(client,1);
			if (option.equalsIgnoreCase("Settings")) {
				client.waitForElement("NATIVE",
						"xpath=//*[@accessibilityLabel='Settings']", 0, 10000);

			} 
			waitFor(client, 1);
		}
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify Update Date and Time is not displayed
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyUpdateDateandTimePopUpNotFound(Client client) {
		client.verifyElementNotFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Update Date & Time']", 0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify Update Date and Time is displayed in Sign In steps
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param on
	 *            true/false
	 */

	public void enableNetwork(Client client, boolean on) {
		client.swipe("Down", 0, 500);
		if (on) {
			if (client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityLabel='wifi-button' and @value='0']",
							0)) {
				client.click("NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button']", 0, 1);
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button' and @value='1']",
						0);
			}
		} else {
			if (client
					.isElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityLabel='wifi-button' and @value='1']",
							0)) {
				client.click("NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button']", 0, 1);
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityLabel='wifi-button' and @value='0']",
						0);
			}
		}
		client.swipe("Up", 0, 500);

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Any Report
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param reportname
	 *            Verify report name
	 */

	public void verifyReportName(Client client, String reportname) {
		reportname=reportname.toUpperCase();
		if (client.waitForElement("NATIVE", "xpath=//*[@text='"+reportname+"']", 0, 10000)) {
			client.verifyElementFound("NATIVE", "xpath=//*[@text='"+reportname+"']", 0);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify the report
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyHistoricUserTimeReportFor4hrTo5dDatafile(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@class='LibreLink.SensorUsageView']", 0, 10000)) { 
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='scanCountLabel' and @text='10']",
					0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='averageScanLabel' and @text='1']",
					0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='dataCapturedLabel' and @text='12']",
					0);
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Click on Share Sign Button from the Bottom of screen 
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickShareButton(Client client) {
		if (client
				.waitForElement(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and ./parent::*[@class='_UIModernBarButton'] and @y>300]",
						0, 10000)) {
			client.click(
					"NATIVE",
					"xpath=//*[@class='UIImageView' and ./parent::*[@class='_UIModernBarButton'] and @y>300]",
					0, 1);
		}
		waitFor(client, 1);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Click on Mail option
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickEmail(Client client) {
		client.clickIn("NATIVE", "nixpath=//*[@class='UIAView' and @height>0 and ./*[@class='UIAView' and @height>0 and ./*[@class='UIAView' and @height>0]] and ./parent::*[@class='UIAView' and @width>0 and ./parent::*[@class='UIACollectionView']]]", 0, "Inside", "TEXT", "Mail", 0, 0, 0, 1);
		waitFor(client,1);
		client.waitForElement("NATIVE", "nixpath=//*[@text='Cancel']", 0, 2000);


	}


	/**
	 * Author: LourdeNoelRini
	 * 
	 * Send email
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void sendEmail(Client client) {

		waitFor(client, 1);
		client.elementSendText("NATIVE", "nixpath=//*[@value='To:']", 0,
				"abbott.automation@icloud.com");
		waitFor(client, 1);
		client.click("NATIVE",
				"nixpath=//*[@value='Send' and @class='UIAButton']", 0, 1);
		waitFor(client, 1);
		launch(client);
	}



	/**
	 * Author: ShabinaSherif
	 * 
	 * Navigate To graph by selecting from drop down
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param reportname 
	 * 				Set report name
	 * 
	 */

	public void navigateToReportBySelectingFromDropDown(Client client, String reportname) {
		client.click("NATIVE", "xpath=//*[@class='LibreLink.LLBanner']", 0, 1);
		waitFor(client,1);
		reportname=reportname.toUpperCase();
		client.click("NATIVE", "xpath=//*[@text='"+reportname+"' and @top='true']", 0, 1);
		waitFor(client,1);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"+reportname+"']", 0);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify date header on the report
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Number of days Data
	 * 
	 * @param reportName
	 *            report name
	 *            
	 */

	public void verifyDatePeriodForNDays(Client client, String reportName, int noOfDays) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='"+reportName+"']", 0, 10000)) {
			if (noOfDays == 7) {

				if (getUnits().equalsIgnoreCase("mg/dL")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='February 22 – 28, 2013']", 0);
				} else if (getUnits().equalsIgnoreCase("mmol/L")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='22–28 February 2013']", 0);
				}

			} else if (noOfDays == 14) {

				if (getUnits().equalsIgnoreCase("mg/dL")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='February 15 – 28, 2013']", 0);
				} else if (getUnits().equalsIgnoreCase("mmol/L")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='15–28 February 2013']", 0);
				}

			} else if (noOfDays == 30) {

				if (getUnits().equalsIgnoreCase("mg/dL")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='January 30 – February 28, 2013']", 0);
				} else if (getUnits().equalsIgnoreCase("mmol/L")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='30 January – 28 February 2013']", 0);
				}
			} else if (noOfDays == 90) {

				if (getUnits().equalsIgnoreCase("mg/dL")) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@text='December 1, 2012 – February 28, 2013']",
							0);
				} else if (getUnits().equalsIgnoreCase("mmol/L")) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@text='1 December 2012 – 28 February 2013']",
							0);
				}

			}

		}
	}


	/**
	 * Author: ShabinaSherif (Completed)
	 * 
	 * Verify EstimatedA1c DatePeriod For NDays
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param daysData
	 *            Number of days Data
	 * 
	 */

	public void verifyEstimatedA1cReportDatePeriodForNdays(Client client,
			String daysData) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='ESTIMATED A1C']", 0, 10000)) {
			if (daysData.equals("24May")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='24 February – 24 May 2013']",
						0);
			} else if (daysData.equals("22May")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='22 February – 22 May 2013']",
						0);
			} else if (daysData.equals("15May")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='15 February – 15 May 2013']",
						0);
			} else if (daysData.equals("29Apr")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='30 January – 29 April 2013']",
						0);
			} else if (daysData.equals("28Feb")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='1 December 2012 – 28 February 2013']",
						0);
			} else if (daysData.equals("5Jan")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='8 October 2012 – 5 January 2013']",
						0);
			} else if (daysData.equals("4Jan")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='7 October 2012 – 4 January 2013']",
						0);
			}
		}

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify EstimatedA1c,A1c percentage(%) is displayed or not.
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param days
	 *            Number of days Data
	 * 
	 */

	public void verifyEstimatedA1cReportCalPercentageForNdays(Client client,
			String days) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='ESTIMATED A1C']", 0, 10000)) {
			if (days.equalsIgnoreCase("24May")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='8.5']", 0);
			} else if (days.equalsIgnoreCase("22May")) {
				if (getUnits().equalsIgnoreCase("mg/dL")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='8.6']", 0);
				} else if (getUnits().equalsIgnoreCase("mmol/L")) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='8.5']", 0);
				}
			} else if (days.equalsIgnoreCase("15May")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='8.1']", 0);
			} else if (days.equalsIgnoreCase("29Apr")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='6.8']", 0);
			} else if (days.equalsIgnoreCase("28Feb")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='7.4']", 0);
			} else if (days.equalsIgnoreCase("5Jan")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='5.7']", 0);
			}
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify EstimatedA1c, A1c mmol/mol is displayed
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param days
	 *            Number of days Data
	 * 
	 */

	public void verifyEstimatedA1cReportCalmmolForNdays(Client client,
			String days) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='ESTIMATED A1C']", 0, 10000)) {
			if (days.equalsIgnoreCase("24May")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 69 mmol/mol )']", 0);
			} else if (days.equalsIgnoreCase("22May")) {
				if (getUnits().equalsIgnoreCase("mg/dL")) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 70 mmol/mol )']",
							0);
				} else if (getUnits().equalsIgnoreCase("mmol/L")) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 69 mmol/mol )']",
							0);
				}
			} else if (days.equalsIgnoreCase("15May")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 65 mmol/mol )']", 0);
			} else if (days.equalsIgnoreCase("29Apr")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 51 mmol/mol )']", 0);
			} else if (days.equalsIgnoreCase("28Feb")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 57 mmol/mol )']", 0);
			} else if (days.equalsIgnoreCase("5Jan")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 39 mmol/mol )']", 0);
			}
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify LowGlucoseEvents Report For TotalEvents
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Number of days Data
	 * 
	 */

	public void verifyLowGlucoseEventsReportForTotalEvents(Client client,
			int noOfDays) {
		if (client
				.waitForElement("NATIVE", "text=Low Glucose Events", 0, 10000)) {
			if (noOfDays==7) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Total Events: 0']",
						0);
			} else if (noOfDays==14) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Total Events: 0']",
						0);
			} else if (noOfDays==30) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Total Events: 8']",
						0);
			} else if (noOfDays==90) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Total Events: 8']",
						0);
			}
		}
	}



	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify  XaxisWith_3_HoursPeriod in 12Hours Format
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param report 
	 * 				Set report name
	 * 
	 */

	public void verifyReportXAxisWith3HoursPeriodFor12Hours(
			Client client,String report) {
		client.waitForElement("NATIVE", "text="+report, 0, 1000);
		client.verifyElementFound("TEXT", "am", 0);
		//Remaining points verified manually
	}

	/**
	 * Author: ShabinaSherif (Completed)
	 * 
	 * Verify XaxisWith_3_HoursPeriod in 24Hours Format
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 *  @param report 
	 *  		Set report name
	 *  
	 */

	public void verifyReportXAxisWith3HoursPeriodFor24Hours(
			Client client,String report) {
		client.waitForElement("NATIVE", "text="+report, 0, 1000);
		client.verifyElementFound("TEXT", "00:00", 1);
		client.verifyElementFound("TEXT", "00:00", 0);
		//Remaining points verified manually

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * verify report available period for n days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Number of days Data available
	 * 
	 * @param reportName 
	 *  		  Set report name
	 */

	public void verifyReportDataAvailableForNdays(Client client, String reportName, int noOfDays) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='"+reportName+"']", 0, 1000)) {
			if (noOfDays==7) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @accessibilityLabel='Data available for 4 of 7 days']",
						0);
			} else if (noOfDays==14) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @accessibilityLabel='Data available for 6 of 14 days']",
						0);
			} else if (noOfDays==30) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @accessibilityLabel='Data available for 6 of 30 days']",
						0);
			} else if (noOfDays==90) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @accessibilityLabel='Data available for 6 of 90 days']",
						0);
			}
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify TimeInTarget Range 100-140 mg/dL or 5.6-7.8 mmol/L
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyTimeInTargetRange100To140(Client client) {
		if (client.waitForElement("NATIVE", "text=TIME IN TARGET", 0, 1000)) {

			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Target Range: 100 - 140 mg/dL']",
						0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Target Range: 5.6 - 7.8 mmol/L']",
						0);
			}
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify TimeInTarget Range 70-180 mg/dL or3.9-10.0 mmol/L
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyTimeInTargetRange70To180(Client client) {
		if (client.waitForElement("NATIVE", "text=TIME IN TARGET", 0, 1000)) {

			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Target Range: 70 - 180 mg/dL']",
						0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel' and @accessibilityLabel='Target Range: 3.9 - 10.0 mmol/L']",
						0);
			}
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Average Historic Glucose for Ndays
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Select the Number of Days for Average Historical Data
	 * 
	 */

	public void verifyAverageHistoricGlucoseForNdays(Client client, int noOfDays) {

		if (client.waitForElement("NATIVE", "text=AVERAGE GLUCOSE", 0, 10000)) {
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				if (noOfDays==7) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 199 mg/dL']",
							0);
				} else if (noOfDays==14) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 185 mg/dL']",
							0);
				} else if (noOfDays==30) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 149 mg/dL']",
							0);
				} else if (noOfDays==90) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 165 mg/dL']",
							0);
				}
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {

				if (noOfDays==7) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 11.0 mmol/L']",
							0);
				} else if (noOfDays==14) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 10.3 mmol/L']",
							0);
				} else if (noOfDays==30) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 8.3 mmol/L']",
							0);
				} else if (noOfDays==90) {
					client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 9.1 mmol/L']",
							0);
				}

			}

		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify AverageHistoricGlucose Range 155-180 for 7 days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyAverageHistoricGlucoseRange155To180For7Days(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='AVERAGE GLUCOSE']", 0, 10000)) {
			client.verifyElementFound("NATIVE", "xpath=//*[@class='LibreLink.ReportCollectionViewCell' and @hidden='false']", 0);
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 250 mg/dL']",
						0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 13.9 mmol/L']",
						0);
			}
		}
	}




	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Total Average Historical Glucose Reading For 7 Days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyTotalAverageHistoricalGlucoseReadingFor7Days(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='AVERAGE GLUCOSE']", 0, 1000)) {
			client.verifyElementFound("NATIVE", "xpath=//*[@class='LibreLink.ReportCollectionViewCell' and @hidden='false']", 0);
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 501 mg/dL']",
						0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 27.8 mmol/L']",
						0);
			}
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify Low Average Historical Glucose Reading Values For 7Days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyLowAverageHistoricalGlucoseReadingValuesFor7Days(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='AVERAGE GLUCOSE']", 0, 1000)) {
			client.verifyElementFound("NATIVE", "xpath=//*[@class='LibreLink.ReportCollectionViewCell' and @hidden='false']", 0);
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 39 mg/dL']",
						0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel'and @accessibilityLabel='Average: 2.2 mmol/L']",
						0);
			}
		}
	}



	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Daily Graph View Date 90Days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyDailyGraphViewDate90Days(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='DAILY GRAPH']", 0,
				10000)) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Not Enough Sensor Data' and @class='LibreLink.BoldLabel']",
					0);
			client.verifyElementNotFound("NATIVE", "xpath=//*[@class='LibreLink.RegularButton' and @enabled='true' and @x='0']", 0);
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Click Arrow On Top Right Of The Graph
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param count 
	 * 			set the count number
	 * 
	 */

	public void clickArrowOnTopRightOfTheGraph(Client client, int count) {
		if (client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.RegularButton' and @x>100]", 0)) {
			try {
				String dateToBeDisplayed = getNewDate(client,count);

				for (int i = 1; i <= count; i++) {
					client.click("NATIVE", "xpath=//*[@class='LibreLink.RegularButton' and @x>100]", 0, 1);
				}
				waitFor(client,1);
				client.verifyElementFound("NATIVE","accessibilityLabel="+dateToBeDisplayed, 0);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public String getNewDate(Client client, int count) throws ParseException {
		String currentDate = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and @textColor='0x000000' and @top='true' and ./parent::*[@class='UIView' ]]", 0);
		SimpleDateFormat sdf;
		Date date;
		String dateToBeDisplayed=null;
		Calendar c1 = null;
		if (getLanguage().contains("U.S.")) {
			sdf = new SimpleDateFormat("MMMMM d, yyyy");
			date = sdf.parse(currentDate);
			c1 = Calendar.getInstance();
			c1.setTime(date);
			c1.add(Calendar.DATE, count);
			dateToBeDisplayed = sdf.format(c1.getTime());


		} else if (getLanguage().contains("U.K.")) {
			sdf = new SimpleDateFormat("d MMMMM yyyy");
			date = sdf.parse(currentDate);
			c1 = Calendar.getInstance();
			c1.setTime(date);
			c1.add(Calendar.DATE, count);
			dateToBeDisplayed = sdf.format(c1.getTime());
		}
		return dateToBeDisplayed;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Click Arrow On Top Left Of The Graph
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param count
	 *            Number of times to Click on Top Left Arrow
	 * 
	 */

	public void clickArrowOnTopLeftOfTheGraph(Client client, int count) {

		if (client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.RegularButton'and @x='0']", 0)) {
			try {
				int newcount=-count;
				String dateToBeDisplayed = getNewDate(client,newcount);

				for (int i = 1; i <= count; i++) {
					client.click("NATIVE", "xpath=//*[@class='LibreLink.RegularButton'and @x='0']", 0, 1);
				}
				waitFor(client,1);
				client.verifyElementFound("NATIVE","accessibilityLabel="+dateToBeDisplayed, 0);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Click Arrow On Top Left For Logbook
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param count
	 *            Number of times to Click on Top Left Arrow
	 * 
	 */

	public void clickArrowOnTopLeftForLogbook(Client client, int count) {
		if (client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='PrevButtonArrow']", 0)) {
			for (int i = 1; i <= count; i++) {
				client.click("NATIVE", "xpath=//*[@accessibilityLabel='PrevButtonArrow']", 0, 1);
			}
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify DailyGraph is not displayed for period beyond 90 days
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyDailyGraphForPeriodBeyond90days(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0,
				1000)) {
			client.verifyElementNotFound("NATIVE", "xpath=//*[@text='DAILY GRAPH']", 0);

		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to click on cancel from the calendar
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickCancelfromCalendar(Client client) {
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='Cancel']", 0, 1);
	}



	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify SensorUsage Date For 14 Days With Additional Two Days
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifySensorUsageDateFor14DaysWithAdditionalTwoDays(
			Client client) {
		if (client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='SENSOR USAGE']", 0, 10000)) {

			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='February 17 – March 2, 2013']", 0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='17 February – 2 March 2013']", 0);                        
			}

		}

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify SensorUsage Date For 14 Days With LeapYear
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifySensorUsageDateFor14DaysWithLeapYear(Client client) {
		if (client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='SENSOR USAGE']", 0, 10000)) {

			if (getUnits().equalsIgnoreCase("mg/dL")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='February 18 – March 2, 2016']", 0);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='18 February – 2 March 2016']", 0);
			}

		}

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Sensor Usage Scan Attempts For BasicData
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Selecting Number of Days Data for SensorUsage
	 * 
	 */

	public void verifySensorUsageScanAttemptsForBasicData(Client client,
			int noOfDays) {
		if (client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='SENSOR USAGE']", 0, 10000)) {
			if (noOfDays==7) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='scanCountLabel' and @text='18']", 0);
			} else if (noOfDays==14) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='scanCountLabel' and @text='49']", 0);
			} else if (noOfDays==30) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='scanCountLabel' and @text='109']", 0);
			} else if (noOfDays==90) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='scanCountLabel' and @text='227']", 0);
			}
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify SensorUsage AverageScans Per Day For Basic Data
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Selecting Number of Days Data for SensorUsage
	 * 
	 */

	public void verifySensorUsageAverageScansPerDayForBasicData(Client client,
			int noOfDays) {
		if (client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='SENSOR USAGE']", 0, 10000)) {
			if (noOfDays==7) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='averageScanLabel' and @text='3']", 0);
			} else if (noOfDays==14) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='averageScanLabel' and @text='4']", 0);
			} else if (noOfDays==30) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='averageScanLabel' and @text='4']", 0);
			} else if (noOfDays==90) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='averageScanLabel' and @text='3']", 0);
			}
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify SensorUsage Percentage Of High Glucose Data For Basic Data
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param noOfDays
	 *            Selecting Number of Days Data for SensorUsage
	 * 
	 */

	public void verifySensorUsagePercentageOfHGDataForBasicData(Client client,
			int noOfDays) {
		if (client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='SENSOR USAGE']", 0, 10000)) {
			if (noOfDays==7) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='dataCapturedLabel' and @text='74']", 0);
			} else if (noOfDays==14) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='dataCapturedLabel' and @text='88']", 0);
			} else if (noOfDays==30) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='dataCapturedLabel' and @text='96']", 0);
			} else if (noOfDays==90) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='dataCapturedLabel' and @text='68']", 0);
			}
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Click On Icon Under Reports Page and verify report message
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param report
	 *            report to be selected
	 * 
	 */

	public void clickOnIconAndVerifyReportMessage(Client client, String report) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityIdentifier='Information']", 0, 3000);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='Information']", 0);
		client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='Information']", 0, 1);

		if (report.equals("Daily Patterns")) {
			client.verifyElementFound("NATIVE", "text=DAILY PATTERNS", 0);
			client.verifyElementFound("NATIVE", "text=${daily_patterns_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='DailyPatternsIcon']", 0);

		} else if (report.equals("Time In Target")) {
			client.verifyElementFound("NATIVE", "text=TIME IN TARGET", 0);
			client.verifyElementFound("NATIVE", "text=${time_in_target_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TimeInTargetIcon']", 0);

		} else if (report.equals("Low Glucose Events")) {
			client.verifyElementFound("NATIVE", "text=LOW GLUCOSE EVENTS", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LowGlucoseEventsIcon']", 0);
			if(getUnits().contains("mg")){
				client.verifyElementFound("NATIVE", "text=${low_glucose_info_msg_mg}", 0);
			}else{
				client.verifyElementFound("NATIVE", "text=${low_glucose_info_msg_mmol}", 0);
			}
		} else if (report.equals("Average Glucose")) {
			client.verifyElementFound("NATIVE", "text=AVERAGE GLUCOSE", 0);
			client.verifyElementFound("NATIVE", "text=${average_glucose_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='AverageGlucoseIcon']", 0);

		} else if (report.equals("Daily Graph")) {
			client.verifyElementFound("NATIVE", "text=DAILY GRAPH", 0);
			client.verifyElementFound("NATIVE", "text=${daily_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='DailyGraphIcon']", 0);

		} else if (report.equals("Estimated A1c")) {
			client.verifyElementFound("NATIVE", "text=ESTIMATED A1c", 0);
			client.verifyElementFound("NATIVE", "text=${a1c_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='EstimatedA1CIcon']", 0);

		} else if (report.equals("Sensor Usage")) {
			client.verifyElementFound("NATIVE", "text=SENSOR USAGE", 0);
			client.verifyElementFound("NATIVE", "text=${sensor_usage_info_msg}", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='SensorUsageIcon']", 0);

		}

		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='OK' and @class='LibreLink.LLDialogButton']", 0);

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Click OK In Reports Page Pop-Up
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void clickOk(Client client) {
		if (client.isElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='OK' and @class='LibreLink.LLDialogButton']", 0)) {
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK' and @class='LibreLink.LLDialogButton']",
					0, 1);
			client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Reports' and @top='true']", 0, 1000);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reports' and @top='true']", 0);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify Not Enough Sensor Data Message
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyNotEnoughSensorDataMessage(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@class='LibreLink.ReportCollectionViewCell']", 0, 1000)) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Not Enough Sensor Data' and @onScreen='true']",
					0);
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify EstimatedA1c Report Calculated Values
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */

	public void verifyEstimatedA1cReportCalculatedValues(Client client) {
		if (client.waitForElement("NATIVE", "xpath=//*[@text='ESTIMATED A1C']", 0, 10000)) {
			client.verifyElementFound("NATIVE", "xpath=//*[@text='ESTIMATED A1C']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@class='LibreLink.EstimatedA1CView']", 0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='a1cPercent' and @text='9.4']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='%']", 0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='a1cDensity' and @text='( 79 mmol/mol )']", 0);
		}
	}



	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify EstimatedA1c Date on Top of Header
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param date
	 *            Number of Days data
	 *            
	 */

	public void verifyEstimatedA1cDateHeader(Client client, String date) {
		if (client.waitForElement("NATIVE", "text=ESTIMATED A1C", 0, 10000)) {
			client.verifyElementFound("NATIVE", "text=ESTIMATED A1C", 0);
			if (date.equalsIgnoreCase("Apr5")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='6 January – 5 April 2014']",                                    
						0);
			} else if (date.equalsIgnoreCase("Apr8")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='9 January – 8 April 2014']",
						0);

			} else if (date.equalsIgnoreCase("Apr11")) {
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='12 January – 11 April 2014']",
						0);
			}

		}

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify EstimatedA1c Data Span
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param nofDays 
	 * 				no of days available
	 * 
	 */

	public void verifyEstimatedA1cReportDataSpanForNdays(Client client, int nofDays) {
		if (client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='ESTIMATED A1C']", 0, 10000)) {
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='ESTIMATED A1C']", 0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Data spans "+nofDays+" of 90 days']",
					0);

		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Time In Target graph is displayed
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param isDisplayed
	 * 			graph is displayed or not
	 */

	public void verifyTITGraphDisplayed(Client client, boolean isDisplayed) {
		if(isDisplayed){
			client.verifyElementFound("NATIVE", "xpath=//*[@class='CPTGraphHostingView']", 0);
		}else{
			client.verifyElementNotFound("NATIVE", "xpath=//*[@class='CPTGraphHostingView']", 0);
		}
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * verify color of the content displayed below the graph
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param days 
	 * 			no of days available
	 * 
	 * @param color 
	 * 			set the color
	 * 
	 */

	public void verifyDataAvailableColor(Client client, String days, String color) {

		client.verifyElementFound("NATIVE", "xpath=//*[@text='Data available for "+days+"' and @onScreen='true']", 0);
		if(color.equalsIgnoreCase("Red")){
			client.verifyElementFound("NATIVE","xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @textColor='0xED1C24' and @onScreen='true']",0);
		}else{
			client.verifyElementFound("NATIVE","xpath=//*[@accessibilityIdentifier='ReportsDataAvailableLabel' and @textColor='0x000000' and @onScreen='true']",0);
		}
	}

}