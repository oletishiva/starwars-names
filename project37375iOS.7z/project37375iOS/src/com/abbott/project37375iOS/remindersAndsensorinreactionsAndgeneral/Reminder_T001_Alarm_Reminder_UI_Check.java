package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class Reminder_T001_Alarm_Reminder_UI_Check extends TestReminderHelper {

	@Test
	public void test_T001_Alarm_Reminder_UI_Check() throws Exception {

		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		launch(client);
		navigateToScreen(client, "Reminders");
		if (!client.isElementFound("NATIVE",
				"xpath=//*[contains(@text,'No active reminders.') and @hidden='false']",
				0)) {
			startUp(client);
			navigateToScreen(client, "Reminders");
		}
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS912 SDAIUIRS914 SDAISRS1156 SDAIUIRS915 SDAIUIRS1203
		 * @Expected Reminder created successfully in 24 hr format
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/

		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step1);
		verifyRemindersPage(client);
		addReminderandSetAlarm(client, "My Glucose", 13, 00);
		verifyReminder(client, "My Glucose", "13:00", false);
		verifyNextReminderwithBackGroundColor(client, "My Glucose", "13:00");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS912_SDAIUIRS914_SDAIUIRS915
		 * @Expected Reminder created successfully in 12 hr format
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step2);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		reLaunch(client);
		addReminderandSetAlarm(client, "My Glucose 1", 13, 00);
		verifyReminder(client, "My Glucose 1", "1:00 PM", false);
		verifyReminder(client, "My Glucose", "1:00 PM", false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS260_SDAIUIRS916_SDAIUIRS915_SDAIUIRS1156
		 * @Expected Reminder created with repeating options
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step3);
		editReminder(client, "My Glucose", 23, 0, "AAAAAA");
		clickRepeatingOption(client, true);
		selectRepeatingOption(client,"Monday",true);
		selectRepeatingOption(client,"Tuesday",true);
		selectRepeatingOption(client,"Wednesday",true);
		selectRepeatingOption(client,"Thursday",true);
		startReminder(client,true);
		verifyReminder(client, "AAAAAA", "11:00 PM", true);
		verifyReminder(client, "My Glucose 1", "1:00 PM", false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS260_SDAIUIRS914_SDAIUIRS915
		 * @Expected Reminder updates not saved on clicking cancel
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step4);
		editReminder(client, "AAAAAA", 12, 0, "BBBBBB");
		selectRepeatingOption(client,"Friday",true);
		selectRepeatingOption(client,"Saturday",true);
		startReminder(client,false);
		verifyReminder(client, "AAAAAA", "11:00 PM", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1123_SDAIUIRS914_SDAIUIRS1156
		 * @Expected Reminder AAAAAA successfully deleted
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step5);
		deleteReminder(client, "AAAAAA");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS913_SDAIUIRS914
		 * @Expected more than 12 reminders are created and verified
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step6);
		addReminderandSetAlarm(client, "My Glucose 2", 2, 00);
		addReminderandSetAlarm(client, "My Glucose 3", 3, 00);
		addReminderandSetAlarm(client, "My Glucose 4", 4, 00);
		addReminderandSetAlarm(client, "My Glucose 5", 5, 00);
		addReminderandSetAlarm(client, "My Glucose 6", 6, 00);
		addReminderandSetAlarm(client, "My Glucose 7", 7, 00);
		addReminderandSetAlarm(client, "My Glucose 8", 8, 00);
		addReminderandSetAlarm(client, "My Glucose 9", 2, 00);
		addReminderandSetAlarm(client, "My Glucose 10", 3, 00);
		addReminderandSetAlarm(client, "My Glucose 11", 4, 00);
		addReminderandSetAlarm(client, "My Glucose 12", 5, 00);
		addReminderandSetAlarm(client, "My Glucose 13", 6, 00);
		navigateToReminderTop(client);
		verifyReminder(client, "My Glucose 1", "1:00 PM", false);
		verifyReminder(client, "My Glucose 2", "2:00 AM", false);
		verifyReminder(client, "My Glucose 3", "3:00 AM", false);
		verifyReminder(client, "My Glucose 4", "4:00 AM", false);
		verifyReminder(client, "My Glucose 5", "5:00 AM", false);
		verifyReminder(client, "My Glucose 6", "6:00 AM", false);
		verifyReminder(client, "My Glucose 7", "7:00 AM", false);
		verifyReminder(client, "My Glucose 8", "8:00 AM", false);
		verifyReminder(client, "My Glucose 9", "2:00 AM", false);
		verifyReminder(client, "My Glucose 10", "3:00 AM", false);
		verifyReminder(client, "My Glucose 11", "4:00 AM", false);
		verifyReminder(client, "My Glucose 12", "5:00 AM", false);
		verifyReminder(client, "My Glucose 13", "6:00 AM", false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS915_SDAIUIRS1155
		 * @Expected Reminder name is created with only 50 characters not more than that 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step7);
		verifyDefaultReminder(client);
		selectandVerifyreminderWithFiftyPlusCharacters(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS915
		 * @Expected Reminder name displays special characters
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step8);
		selectandVerifyReminderWithSpecialCharacters(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS262_SDAIUIRS1183
		 * @Expected Reminder created with ~ current time + few mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/

		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step9);
		deleteReminder(client,LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME);
		addReminderWithAdvancedTime(client, "Before Lunch", 2);
		verifyReminderStatus(client, "Before Lunch", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS262_SDAIUIRS916_SDAIUIRS1158
		 * @Expected Reminder notification is displayed when app is running background and on clicking the notification, App will be opened
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step10);
		moveApptoBackground(client);
		waitForNotification(client);
		openNotification(client);
		capturescreenshot(client, getStepID(), true);
		verifyReminderNotification(client, "Before Lunch",true);
		verifyHomePage(client);
		//App is relaunched so that API command can be executed
		reLaunch(client);
		navigateToScreen(client, "Reminders");
		verifyReminderStatus(client, "Before Lunch", false);
		

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS262_SDAIUIRS916
		 * @Expected Reminder notification is displayed when app is closed and on clicking the notification App is opened
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step11);
		editReminderWithAdvancedTime(client, "Before Lunch", 2);
		closeApplication(client);
		waitForNotification(client);
		openNotification(client);
		verifyReminderNotification(client, "Before Lunch",true);
		verifyHomePage(client);
		//App is relaunched so that API command can be executed
		launch(client);
		navigateToScreen(client, "Reminders");
		verifyReminderStatus(client, "Before Lunch", false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS262
		 * @Expected Multiple reminders edited with ~ current time + few mins and verified
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step12);
		editReminderWithAdvancedTime(client, "My Glucose 2", 3);
		editReminderWithAdvancedTime(client, "My Glucose 3", 3);
		editReminderWithAdvancedTime(client, "My Glucose 4", 3);
		editReminderWithAdvancedTime(client, "My Glucose 5", 3);
		editReminderWithAdvancedTime(client, "Before Lunch", 3);
		navigateToReminderTop(client);
		verifyReminderStatus(client, "My Glucose 2", true);
		verifyReminderStatus(client, "My Glucose 3", true);
		verifyReminderStatus(client, "My Glucose 4", true);
		verifyReminderStatus(client, "My Glucose 5", true);
		verifyReminderStatus(client, "Before Lunch", true);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS262_SDAIUIRS916_SDAIUIRS1183_SDAIUIRS1158
		 * @Expected Reminder notification dialog is displayed after few minutes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step13);
		waitForNotificationDialog(client);
		waitFor(client,60);
		verifyReminderNotificationDialog(client, "My Glucose 2",true);
		verifyReminderNotificationDialog(client, "My Glucose 3",true);
		verifyReminderNotificationDialog(client, "My Glucose 4",true);
		verifyReminderNotificationDialog(client, "My Glucose 5",true);
		waitForNotificationDialog(client);
		capturescreenshot(client, getStepID(), true);
		verifyReminderNotificationDialog(client, "Before Lunch",true);
		launch(client);
		navigateToScreen(client, "Reminders");
		verifyReminderStatus(client, "My Glucose 2", false);
		verifyReminderStatus(client, "My Glucose 3", false);
		verifyReminderStatus(client, "My Glucose 4", false);
		verifyReminderStatus(client, "My Glucose 5", false);
		verifyReminderStatus(client, "Before Lunch", false);
		
		
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS262
		 * @Expected Multiple reminders edited with current time + few mins and verified
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step14);
		editReminderWithAdvancedTime(client, "My Glucose 2", 4);
		editReminderWithAdvancedTime(client, "My Glucose 3", 4);
		editReminderWithAdvancedTime(client, "My Glucose 4", 4);
		editReminderWithAdvancedTime(client, "My Glucose 5", 4);
		editReminderWithAdvancedTime(client, "Before Lunch", 4);
		navigateToReminderTop(client);
		verifyReminderStatus(client, "My Glucose 2", true);
		verifyReminderStatus(client, "My Glucose 3", true);
		verifyReminderStatus(client, "My Glucose 4", true);
		verifyReminderStatus(client, "My Glucose 5", true);
		verifyReminderStatus(client, "Before Lunch", true);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS262_SDAIUIRS916_SDAIUIRS1183
		 * @Expected Reminder notification is displayed after few mins when app is running background and reminders are disabled
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step15);
		moveApptoBackground(client);
		waitForNotification(client);
		waitFor(client,120);
		openNotification(client);
		verifyReminderNotification(client, "My Glucose 2",false);
		verifyReminderNotification(client, "My Glucose 3",false);
		verifyReminderNotification(client, "My Glucose 4",false);
		verifyReminderNotification(client, "My Glucose 5",false);
		verifyReminderNotification(client, "Before Lunch",false);
		reLaunch(client);
		navigateToReminderTop(client);
		verifyReminderStatus(client, "My Glucose 2", false);
		verifyReminderStatus(client, "My Glucose 3", false);
		verifyReminderStatus(client, "My Glucose 4", false);
		verifyReminderStatus(client, "My Glucose 5", false);
		verifyReminderStatus(client, "Before Lunch", false);
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS262
		 * @Expected Multiple reminders edited with current time + few mins and verified
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step16);
		editReminderWithAdvancedTime(client, "My Glucose 2", 4);
		editReminderWithAdvancedTime(client, "My Glucose 3", 4);
		editReminderWithAdvancedTime(client, "My Glucose 4", 4);
		editReminderWithAdvancedTime(client, "My Glucose 5", 4);
		editReminderWithAdvancedTime(client, "Before Lunch", 4);
		navigateToReminderTop(client);
		verifyReminderStatus(client, "My Glucose 2", true);
		verifyReminderStatus(client, "My Glucose 3", true);
		verifyReminderStatus(client, "My Glucose 4", true);
		verifyReminderStatus(client, "My Glucose 5", true);
		verifyReminderStatus(client, "Before Lunch", true);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS262_SDAIUIRS916_SDAIUIRS1183
		 * @Expected Reminder notification is displayed after few mins when app is closed and reminders are disabled
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step17);
		closeApplication(client);
		waitForNotification(client);
		waitFor(client,120);
		openNotification(client);
		verifyReminderNotification(client, "My Glucose 2",false);
		verifyReminderNotification(client, "My Glucose 3",false);
		verifyReminderNotification(client, "My Glucose 4",false);
		verifyReminderNotification(client, "My Glucose 5",false);
		verifyReminderNotification(client, "Before Lunch",false);
		reLaunch(client);
		navigateToScreen(client, "Reminders");
		navigateToReminderTop(client);
		verifyReminderStatus(client, "My Glucose 2", false);
		verifyReminderStatus(client, "My Glucose 3", false);
		verifyReminderStatus(client, "My Glucose 4", false);
		verifyReminderStatus(client, "My Glucose 5", false);
		verifyReminderStatus(client, "Before Lunch", false);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS918
		 * @Expected Enable reminder trigger is verified for multiple reminders
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step18);
		enableordisableReminder(client, "My Glucose 2",true);
		enableordisableReminder(client, "My Glucose 3",true);
		enableordisableReminder(client, "My Glucose 4",true);
		enableordisableReminder(client, "My Glucose 5",true);
		enableordisableReminder(client, "Before Lunch",true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1183
		 * @Expected Disable reminder trigger is verified for multiple reminders
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/

		setStepID(LibrelinkConstants.Reminder_TC001_Alarm_Reminder_UI_Check_Step19);
		enableordisableReminder(client, "My Glucose 2",false);
		enableordisableReminder(client, "My Glucose 3",false);
		enableordisableReminder(client, "My Glucose 4",false);
		enableordisableReminder(client, "My Glucose 5",false);
		enableordisableReminder(client, "Before Lunch",false);
		capturescreenshot(client, getStepID(), true);
	
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
	
	}

}