package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.experitest.client.Client;

public class General_T006_Results_WithUOM extends UIGeneralHelper {

	@Test
	public void test_General_T006_Results_WithUOM() throws Exception {

		/**
		 * 
		 * @stepId Pre Condition
		 * @Reqt
		 * @Expected Carbohydrate Unit is set to grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client, "Carbohydrate Units");
		setCarbohydrateUnits(client, "grams");

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAISRS1175
		 * @Expected About screen is displayed the smart device Model and OS version details
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step1);
		navigateToScreen(client,"About");
		capturescreenshot(client, getStepID(), true);
		verifyOSDetails(client);

		/**
		 *
		 * @stepId Step 2
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected The Add Note screen unit-of-measure is displays as:Breakfast - grams,Rapid-Acting Insulin - units,Long-acting Insulin - units
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step2);
		navigateToScreen(client,"Logbook");
		createNewNote(client,getCalendarDate(client), "3.30");
		clickAndSetFoodAttribute(client, "Breakfast", "20");
		addNoteForRapidActingInsulin(client, "2.0");
		addNoteForLongActingInsulin(client, "3.0");
		addNoteForExercise(client, "Low Intensity", 12, 02);
		client.swipe("Up", 500, 500);
		verifyFoodEntry(client,"Breakfast","grams","20");
		verifyInsulinUnits(client,"Rapid");
		verifyInsulinUnits(client,"Long");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 3
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected In Logbook Details screen, the numerical values unit of measurements are displayed for selected attributes
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step3);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "03:30");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "grams", "20");
		verifyInsulinLogBookDetailPage(client, "Rapid", "2");
		verifyInsulinLogBookDetailPage(client, "Long", "3");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 12, 2);		
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected The Average Glucose readings displayed with unit of measurement mg/dL or mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step4);
		loadTestData(client, "MOCK_2", "Autodated","90days_autoDate.json");
		navigateToScreen(client,"Home");
		verifyAvgGlucoseUnitsinHome(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 5
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected DAILY PATTERNS report Y-axis Glucose values are displayed with unit of measurement mg/dL or mmol/L  for 7 days, 14 days, 30 days and 90 days date ranges.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step5);
		navigateToScreen(client, "Daily Patterns");
		clickOnDays(client, 7);
		capturescreenshot(client, getStepID().replace("Step5", "Step5.1") + "_7 days", true);
		clickOnDays(client, 14);
		capturescreenshot(client, getStepID().replace("Step5", "Step5.2") + "_14 days", true);
		clickOnDays(client, 30);
		capturescreenshot(client, getStepID().replace("Step5", "Step5.3") + "_30 days", true);
		clickOnDays(client, 90);
		capturescreenshot(client, getStepID().replace("Step5", "Step5.4") + "_90 days", true);

		/**
		 *
		 * @stepId Step 6
		 * @Reqt SDAISRS354 _SDAIUIRS842
		 * @Expected The Target Glucose Range glucose values displays with UOM mg/dL or mmol/L for 7 days, 14 days, 30 days & 90 days� range. and The Target Glucose Range report display each bar with numerical %
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step6);
		navigateToScreen(client, "Time In Target");
		clickOnDays(client, 7);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step6", "Step6.1") + "_7 days", true);
		clickOnDays(client, 14);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step6", "Step6.2") + "_14 days", true);
		clickOnDays(client, 30);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step6", "Step6.3") + "_30 days", true);
		clickOnDays(client, 90);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step6", "Step6.4") + "_90 days", true);

		/**
		 *
		 * @stepId Step 7
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected AVERAGE GLUCOSE report is displayed the Average  Glucose value with unit of measurement mg/dL or mmol/L for 7 days, 14 days, 30 days and 90 days.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step7);
		navigateToScreen(client, "Average Glucose");
		clickOnDays(client, 7);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step7", "Step7.1") + "_7 days", true);
		clickOnDays(client, 14);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step7", "Step7.2") + "_14 days", true);
		clickOnDays(client, 30);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step7", "Step7.3") + "_30 days", true);
		clickOnDays(client, 90);
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID().replace("Step7", "Step7.4") + "_90 days", true);

		/**
		 *
		 * @stepId Step 8
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected DAILY GRAPH report is displayed  the Y-axis Glucose values with unit of measurement mg/dL or mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step8);
		navigateToScreen(client, "Daily Graph");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 9
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected 'In Target Glucose Range screen, the Target Glucose Range values are displayed with UOM as mg/dL or mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step9);
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client, "Target Glucose Range");
		verifyTargetRangeUOM(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 10
		 * @Reqt SDAISRS354
		 * @Expected In Carbohydrate Units screen, the UOM for Carbohydrate is displayed as grams and servings. ( for UK, it is displayed as gram and portions)
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step10);
		clickOnBackIcon(client);
		navigateToSubMenuScreens(client, "Carbohydrate Units");
		verifyCarbohydrateOptions(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 11
		 * @Reqt SDAISRS354
		 * @Expected 'The unit-of-measure for Breakfast is displayed as servings. ( for UK , it is displayed as portions)
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step11);
		clickCarbohydrateUnit(client,"servings");
		clickOnButtonOption(client,"SAVE", true);
		navigateToScreen(client, "Logbook");
		createNewNote(client,getCalendarDate(client), "4.30");
		clickAndSetFoodAttribute(client, "Breakfast", "20");
		verifyFoodEntry(client,"Breakfast","servings","20");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 12
		 * @Reqt SDAISRS354
		 * @Expected The unit-of-measure for Breakfast is displayed as svg (servings); For UK, it is displayed as ptn (portions).
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step12);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "04:30");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "servings", "20");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 13
		 * @Reqt SDAISRS354_SDAIUIRS842
		 * @Expected  My Glucose screen is displayed the values with UOM as:Breakfast servings(20.0svg)  ( or Portions( 20.0 ptns) for UK build ),Rapid-Acting Insulin units(2 units),Long-acting Insulin units(3 units),Exercise Low Intensity Hrs(12 hours 2 minutes).
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step13);
		clickOnBackIcon(client);
		navigateToMyGlucosePage(client);
		clickAddNoteInMyGlucose(client);
		clickAndSetFoodAttribute(client, "Breakfast", "20");
		addNoteForRapidActingInsulin(client, "2.0");
		addNoteForLongActingInsulin(client, "3.0");
		addNoteForExercise(client, "Low Intensity", 12, 02);
		clickOnButtonOption(client, "DONE", true);
		waitFor(client, 2);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Rapid-Acting Insulin (2 units)']", 0)){
			clickOnButtonOption(client, "OK", true);
			clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",1);
		}
		verifyNotePopUpDetail(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 *
		 * @stepId Step 14
		 * @Reqt SDAISRS354
		 * @Expected Home screen is displayed the values with UOM as:Breakfast servings(20.0svg)  ( or Portions( 20.0 ptns) for UK build ),Rapid-Acting Insulin units(2 units),Long-acting Insulin units(3 units),Exercise Low Intensity Hrs(12 hours 2 mins).
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step14);
		clickOnBackIcon(client);
		waitFor(client, 1);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",1);
		verifyNotePopUpDetail(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 *
		 * @stepId Step 15
		 * @Reqt  SDAISRS354_SDAIUIRS842
		 * @Expected Home screen is displayed Sensor Life in 'DAYS' and UOM for Glucose Reading as mg/dL or mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step15);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		debugDrawerClearData(client);
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Realtime","100",false,0,0);
		scanMockSensor(client, null);
		clickOnBackIcon(client);
		navigateToScreen(client, "Home");
		verifySensorlife(client, "DAYS");
		verifyGlucoseUnits(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 16
		 * @Reqt SDAISRS354
		 * @Expected Home screen displayed the Sensor life in HOURS.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step16);
		debugDrawerClearData(client);
		editConfiguration(client, -13, -21, -30,"1/14");
		verifySensorlife(client, "HOURS");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 17
		 * @Reqt SDAISRS354
		 * @Expected Home screen displayed the Sensor life in MINUTES.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step17);
		editConfiguration(client, -13, -23, -30,"1/14");
		verifySensorlife(client, "MINUTES");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 18
		 * @Reqt SDAIUIRS842
		 * @Expected No unit of measure for numerical value with a percentage
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step18);
		debugDrawerClearData(client);
		loadTestData(client, "MOCK_2", "Autodated","90days_autoDate.json");
		verifyTimeintargetinHome(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 19
		 * @Reqt SDAIUIRS842
		 * @Expected No unit of measure for numerical value with Time
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step19);
		verifyTimeinLastScan(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 20
		 * @Reqt SDAIUIRS842
		 * @Expected No unit of measure for numerical value with a count
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step20);
		navigateToScreen(client, "Sensor Usage");
		verifySensorscanpage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 21
		 * @Reqt SDAIUIRS842
		 * @Expected No unit of measure for numerical value with a date
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step21);
		navigateToScreen(client, "Logbook");
		client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell']", 0, 1);
		verifyTimeinLogbookDetails(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 *
		 * @stepId Step 22
		 * @Reqt SDAIUIRS842
		 * @Expected No unit of measure for the numerical value is associated with a bar in a graph
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.General_T006_Results_WithUOM_Step22);
		navigateToScreen(client, "Average Glucose");
		verifyAverageGlucoseValue(client);
		capturescreenshot(client, getStepID(), true);
		selectingSASMode(client,"DEFAULT");

	}

	/**
	 * Author:NagarajuKasarla
	 * 
	 * verify Note Pop-Up
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	public void verifyNotePopUpDetail(Client client) {
		verifyNotePopUpDetails(client,"Breakfast (20 svg)");
		verifyNotePopUpDetails(client, "Rapid-Acting Insulin (2 units)");
		verifyNotePopUpDetails(client, "Long-Acting Insulin (3 units)");
		verifyNotePopUpDetails(client, "Exercise Low Intensity (12 hours 2 minutes)");
	}

}
