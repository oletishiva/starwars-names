package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.experitest.client.Client;


public class General_T004_DefaultLang_SysInfo extends UIGeneralHelper {


	@Test
	public void test_General_T004_DefaultLang_SysInfo() throws Exception {

		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		logOutUser(client);

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1167,SDAISRS133
		 * @Expected Welcome Screen all strings are displayed in selected language that is supported by App
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step1);
		getStartedNowScreens(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1167,SDAISRS133
		 * @Expected Terms of Use and  Privacy Notice all strings are displayed in selected language that is supported by App
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step2);
		getStarted(client,true);
		clickOnCountryOfOrigin(client);
		verifyTermsAndPolicyPageDetails(client,"Terms of Use");
		clickCheckBox(client, "Terms of Use", true);
		verifyTermsAndPolicyPageDetails(client, "Privacy Notice");
		capturescreenshot(client, getStepID(), true);
		clickAndAcceptPage(client, "Privacy Notice");
		
		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1167,SDAISRS133
		 * @Expected Create My Account screen all Strings are displayed in selected language that is supported by App
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step3);
		verifyCreateAccountScreen(client);
		capturescreenshot(client, getStepID()+"_Language Selected: "+getLanguage(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1167,SDAISRS133
		 * @Expected Home,Logbook,Reminders, all reports all Strings are displayed in selected language that is supported by App
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step4);
		clickOnBackIcon(client);
		clickOnBackIcon(client);
		clickSignInButton(client,true);
		signInClick(client, LibrelinkConstants.Username, LibrelinkConstants.Password,true);
		clickAndAcceptPage(client, "Terms of Use");
		clickAndAcceptPage(client, "Privacy Notice");
		defaultSettings(client,"grams");
		loadTestData(client, "MOCK_2", "Autodated","90days_autoDate.json");
		navigateToScreen(client, "Home");
		navigateToScreen(client, "Logbook");
		navigateToScreen(client, "Reminders");
		navigateToScreen(client, "Daily Patterns");
		navigateToScreen(client, "Time In Target");
		navigateToScreen(client, "Low Glucose Events");
		navigateToScreen(client, "Average Glucose");
		navigateToScreen(client, "Daily Graph");
		navigateToScreen(client, "Sensor Usage");
		capturescreenshot(client, getStepID()+"_Language Selected: "+getLanguage(), true);
		navigateToScreen(client, "Home");

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1167,SDAISRS133
		 * @Expected App Settings,Account Settings,Change Password,Help,About are displayed in selected language that is supported by App
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step5);
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client, "Account Settings");
		clickOnBackIcon(client);
		navigateToSubMenuScreens(client, "Account Password");
		clickOnBackIcon(client);
		navigateToScreen(client, "Help");
		navigateToScreen(client, "About");
		capturescreenshot(client, getStepID()+"_Language Selected: "+getLanguage(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAISRS668 SDAISRS133
		 * @Expected App displayed all the strings in default language US English when unsupported language is selected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step6);
		System.out.println("========"+getLanguage());
		changeLanguageinDevice(client,getProperty("unsupportedlanguage"));
		waitFor(client,2);
		client.launch("com.apple.Preferences", true, true);
		waitFor(client,5);
		capturescreenshot(client, "TestPrecondition: Selected Unsupported Language "+getProperty("unsupportedlanguage"),true);
		deletePreferredLanguages(client);
		setInputLanguage(client, "Base");
		launch(client);
		logOutUser(client);
		getStartedNowScreens(client);
		getStarted(client,true);
		clickOnCountryOfOrigin(client);
		verifyTermsAndPolicyPageDetails(client,"Terms of Use");
		clickCheckBox(client, "Terms of Use", true);
		verifyTermsAndPolicyPageDetails(client, "Privacy Notice");
		clickCheckBox(client, "Privacy Notice", true);
		verifyCreateAccountScreen(client);
		clickOnBackIcon(client);
		clickOnBackIcon(client);
		createDefaultAccount(client,"Adult");
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client, "Carbohydrate Units");
		capturescreenshot(client, getStepID()+"_Displayed Default Language is English (U.S.)", true);
		clickOnBackIcon(client);
		changeLanguageinDeviceToNormal(client,getLanguage());
		launch(client);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1166
		 * @Expected About screen displays the smart device OS version details
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T004_DefaultLang_SysInfo_Step7);
		navigateToScreen(client,"About");
		verifyOSDetails(client);
		navigateToScreen(client,"About");
		capturescreenshot(client, getStepID(), true);



		selectingSASMode(client,"DEFAULT");
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to click on Add Note
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param tobeSetLanguage
	 * 			language to be set
	 */

	public void changeLanguageinDeviceToNormal(Client client,String tobeSetLanguage) {
		waitFor(client,2);
		client.launch("com.apple.Preferences", true, true);
		waitFor(client,5);
		client.click("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeCell']", 0, 1);
		waitFor(client,1);
		String language = client.elementGetText("NATIVE", "xpath=//*[@class='UIAStaticText' and ./following-sibling::*[@class='UIAButton']]", 0);

		if (!(language.equals(tobeSetLanguage))) {
			waitFor(client, 2);
			System.out.println("=========="+tobeSetLanguage);
			client.elementSendText(
					"NATIVE",
					"xpath=//*[@XCElementType='XCUIElementTypeSearchField' and @class='UIATextField']",
					0, tobeSetLanguage);
			client.waitForElement("NATIVE", "xpath=//*[@text='" + tobeSetLanguage
					+ "']", 0, 10000);
			client.click("NATIVE", "xpath=//*[@text='" + tobeSetLanguage + "']", 0,
					1);
			client.click("NATIVE", "xpath=//*[@class='UIAButton']", 2, 1);			


			if(client.isElementFound("NATIVE", "xpath=//*[@class='UIAButton' and @label='Continue']",0)){
				client.click("NATIVE", "xpath=//*[@class='UIAButton' and @label='Continue']", 0, 1);
			}else{
				client.waitForElement("NATIVE", "xpath=//*[@class='UIAView' and @height>0 and ./parent::*[@class='UIAView' and ./parent::*[./parent::*[./preceding-sibling::*[@class='UIAView']]]] and ./*[@class='UIAButton']]", 0, 10000);
				client.click("NATIVE", "xpath=//*[@class='UIAView' and @height>0 and ./parent::*[@class='UIAView' and ./parent::*[./parent::*[./preceding-sibling::*[@class='UIAView']]]] and ./*[@class='UIAButton']]", 0, 1);
			}
			waitFor(client,3);			
			client.closeDevice();
			client.openDevice();
			closePhoneSettings(client);
			waitFor(client,12);

		}
		else{
			client.click("NATIVE", "xpath=//*[@class='UIAButton']", 0, 1);//CANCEL button
			closePhoneSettings(client);
		}


		System.out.println("*************Language Changed !!! *************");
	}


	public void deletePreferredLanguages(Client client) {
		client.click("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeButton']", 1, 1);
		waitFor(client,1);
		client.click("NATIVE", "xpath=(//*/*[@class='UIAButton' and @x='0'])", 1, 1);
		waitFor(client,1);
		client.click("NATIVE", "xpath=//*[@knownSuperClass='UISwipeActionStandardButton']", 0, 1);
		waitFor(client,1);
		client.click("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeButton']", 1, 1);
		waitFor(client,1);
		client.click("NATIVE", "xpath=//*[@knownSuperClass='_UIAlertControllerActionView']", 0, 1);
		waitFor(client,3);			
		client.closeDevice();
		client.openDevice();
		waitFor(client,12);


	}

}
