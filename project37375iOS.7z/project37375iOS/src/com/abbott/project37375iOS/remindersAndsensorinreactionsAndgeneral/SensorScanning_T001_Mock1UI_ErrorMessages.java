package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;


public class SensorScanning_T001_Mock1UI_ErrorMessages
extends SensorHelper {

	@Test
	public void test_SensorScanning_T001_Mock1UI_ErrorMessages() throws Exception {

		/**
		 * @stepId Pre-Condition Update the Time Format
		 * 
		 * @Dependancy Script fails if the Set-Up file is not updated with build
		 *             details
		 */
		setTheDateAndTime(client, 0, 0, 0, "12:00");
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt
		 * @Expected Home screen shows "Check Glucose"  on the bottom, "130 mg/dL" or 7.2 mmol/L for "Last Scan", 110 mg/dL or 6.2 mmol/L for average.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step1);
		addAndVerifyHistoricalAndRealtimeData(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt  SDAIUIRS1097 
		 * @Expected A dialog for SensorRfTransmissionError is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step2);
		openDebugDrawer(client);
		scanMockSensor(client,"TRANSMISSION_ERROR");
		verifySensorDialogScreen(client,"error_sensor_transmission_title","iosDefaultSensorErrorMsg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1097
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step3);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1096
		 * @Expected A dialog for SensorNotActive is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step4);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_ACTIVE");
		verifyNotActiveSensorScreen(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1096
		 * @Expected App returns to Home screen, My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step5);
		clickOnButtonOption(client,"NO",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1096
		 * @Expected App returns to 'Scan New Sensor' screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step6);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_ACTIVE");
		clickOnButtonOption(client,"YES",true);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1096
		 * @Expected App shows Home screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step7);
		verifyHomePage(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"CANCEL",true);
		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1103_SDAISRS330
		 * @Expected A dialog for SensorTemperatureTooHigh is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step8);
		openDebugDrawer(client);
		scanMockSensor(client,"TEMP_HIGH");
		verifySensorDialogScreen(client,"error_sensor_too_hot_title","error_sensor_too_hot_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1103_SDAISRS330 
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step9);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1104_SDAISRS330
		 * @Expected A dialog for SensorTemperatureTooLow is shown 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step10);
		openDebugDrawer(client);
		scanMockSensor(client,"TEMP_LOW");
		verifySensorDialogScreen(client,"error_sensor_too_cold_title","error_sensor_too_cold_msg");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1104_SDAISRS330
		 * @Expected Sensor Error dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step11);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1105 SDAISRS827 
		 * @Expected A dialog for SensorTemporaryProblem  is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step12);
		openDebugDrawer(client);
		scanMockSensor(client,"TEMPORARY_PROBLEM");
		verifySensorDialogScreen(client,"error_sensor_temporary_problem_title","error_sensor_temporary_problem_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1105
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step13);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1108
		 * @Expected A dialog for SensorNotCompatible  is shown 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step14);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_COMPATIBLE");
		verifySensorDialogScreen(client,"error_sensor_incompatible_title","error_sensor_incompatible_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS1108
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step15);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS1101
		 * @Expected A dialog for SensorInWarmup  is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step16);
		openDebugDrawer(client);
		scanMockSensor(client,"IN_WARMUP");
		verifySensorDialogScreen(client,"error_sensor_inwarmup_title","error_sensor_inwarmup_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS1101
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step17);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS1099
		 * @Expected A dialog forResponseCorrupt is shown
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step18);
		openDebugDrawer(client);
		scanMockSensor(client,"RESPONSE_CORRUPT");
		verifySensorDialogScreen(client,"error_sensor_corrupt_title","iosDefaultSensorErrorMsg");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1099
		 * @Expected App returns to Home screen. My glucose screen is not displayed.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step19);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyScreenNotFound(client,"My Glucose");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAISRS257_SDAISRS368
		 * @Expected Event log should display the error messages
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorScanning_T001_Mock1UI__ErrorMessages_Step20);
		navigateToScreen(client, "Help");
		navigateToSubMenuScreens(client,"Event Log");
		verifyEventLogContent(client, "error_sensor_transmission_title","iosDefaultSensorErrorMsg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_not_active_title","error_sensor_not_active_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_too_hot_title","error_sensor_too_hot_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_too_cold_title","error_sensor_too_cold_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_temporary_problem_title","error_sensor_temporary_problem_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_incompatible_title","error_sensor_incompatible_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_inwarmup_title","error_sensor_inwarmup_msg");
		eventlogScrollUp(client);
		verifyEventLogContent(client, "error_sensor_corrupt_title","iosDefaultSensorErrorMsg");
		eventlogScrollUp(client);
		capturescreenshot(client, getStepID(), true);

		selectingSASMode(client,"DEFAULT");
		currentSystemTime(client);
	}

}
