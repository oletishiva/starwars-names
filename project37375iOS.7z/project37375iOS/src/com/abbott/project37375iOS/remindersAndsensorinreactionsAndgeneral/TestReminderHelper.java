package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.junit.Assert;

import com.abbott.project37375iOS.main.BaseHelper;
import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.experitest.client.Client;


public class TestReminderHelper extends BaseHelper {

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to get the current hours
	 *	 
	 * @return hrs
	 * 		hrs is returned     
	 */
	public int getCurrentHours() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH");
		String formattedDate = dateFormat.format(new Date()).toString();
		int hrs = Integer.parseInt(formattedDate);
		return hrs;
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to wait for the notifications
	 *
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 */
	public void waitForNotification(Client client) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='NotificationShortLookView' and contains(@value,'Reminder')]", 0, 240000);
		waitFor(client,2);
	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to wait for the notification dialog
	 *
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 */
	public void waitForNotificationDialog(Client client) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Reminder' and ../parent::*[@class='LibreLink.LLCustomDialog']]", 0, 240000);
	
	}
	
	/**
	 * Author: ShabinaSherif   
	 * 
	 * Method to get the current minutes
	 *
	 * @return mins
	 * 		Mins is returned
	 */
	public int getCurrentMinutes() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("mm");
		String formattedDate = dateFormat.format(new Date()).toString();
		int mins = Integer.parseInt(formattedDate);
		return mins;
	}


	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify the repeating options status
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param isChecked
	 *        true/false
	 */
	public void verifyRepeatingOptions(Client client, boolean isChecked) {

		String daysArray[] = new String[] { "All", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" , "Saturday"};

		for (int i=0;i<daysArray.length;i++){

			String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+daysArray[i]+"']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
			if(isChecked){
				Assert.assertEquals("1", checkedStatus);
			}else{
				Assert.assertEquals("0", checkedStatus);
			}
		}
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Repeating Options are visible or not
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param isNotVisible
	 *        true/false
	 */
	public void verifyRepeatingOptionsNotVisible(Client client, boolean isNotVisible) {
		String daysArray[] = new String[] { "All", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };

		for (int i=0;i<daysArray.length;i++){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @parentHidden='"+isNotVisible+"' and ./following-sibling::*[@accessibilityLabel='"+daysArray[i]+"']]", 0);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify Reminders Page UI
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void verifyRemindersPage(Client client) {
		client.verifyElementFound("NATIVE", "text=Reminders", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'No active reminders.') and @hidden='false']", 0);
		client.verifyElementFound("NATIVE", "text=Scan Sensor", 0);
		client.verifyElementFound("NATIVE", "text=TIMERS", 0);
		client.verifyElementFound("NATIVE", "text=REMINDERS", 0);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=TimerIcon", 0);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=AlarmIcon", 0);
		client.verifyElementFound("NATIVE", "class=UISwitch", 0);
		client.verifyElementFound("NATIVE", "text=ADD REMINDER", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=SensorIcon", 0);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to click the add reminder button
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void clickAddReminder(Client client) {
		client.click("NATIVE", "accessibilityLabel=ADD REMINDER", 0, 1);
		waitFor(client,1);
		client.verifyElementFound("NATIVE", "accessibilityLabel=Add Reminder", 0);		
	}


	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify the default Reminder
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * 
	 */

	public void verifyDefaultReminder(Client client) {
		clickAddReminder(client);
		String isSelected = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UISwitch']", 0, "invokeMethod:'{\"selector\":\"isOn\",\"arguments\":[]}'");
		Assert.assertEquals("0", isSelected);
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=CANCEL", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=DONE",
				0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=Add Reminder",
				0);

		client.verifyElementFound("NATIVE", "text=Repeating", 0);
		String isEnabled =  client.runNativeAPICall("NATIVE", "xpath=//*[@class='LibreLink.LLSubmitButton']", 0, "invokeMethod:'{\"selector\":\"isEnabled\",\"arguments\":[]}'");
		Assert.assertEquals("1", isEnabled);

	}
	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to add the reminder for a given time
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param name
	 *        send the name for reminder
	 * @param hrs
	 *        set the hours
	 * @param mins
	 *        set the minutes
	 *            
	 */
	public void addReminderandSetAlarm(Client client, String name,
			int hrs, int mins) {
		clickAddReminder(client);
		enterReminderName(client,name);
		reminderSetTime(client, hrs, mins);
		startReminder(client,true);

	}



	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to enter Reminder Name
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          Name to be entered
	 *            
	 */
	public void enterReminderName(Client client, String name) {
		if (client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='ReminderTextField']")) {
			client.elementSendText("NATIVE", "xpath=//*[@accessibilityIdentifier='ReminderTextField']", 0, name);
			client.closeKeyboard();
		}
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to select the repeating option
	 * 
	 * @param client
	 *			Integrate SeeTestAutomation 
	 * @param dayName
	 *          dayName to be select/unselect
	 * @param check
	 *            true/false
	 * 
	 */
	public void selectRepeatingOption(Client client, String dayName, boolean check) {
		String selectedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+dayName+"']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
		if((selectedStatus.equalsIgnoreCase("0") & check)||(selectedStatus.equalsIgnoreCase("1") & !check)){
			client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./following-sibling::*[@text='"+dayName+"']]", 0, 1);
			client.sleep(500);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify whether specific repeating option is checked/unchecked
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param dayName
	 *          dayName status to be checked
	 * @param check
	 *            true/false
	 *            
	 */
	public void verifySingleRepeatingOption(Client client, String dayName, boolean check) {
		String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+dayName+"']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
		if(check){
			Assert.assertEquals("1", checkedStatus);
		}else{
			Assert.assertEquals("0", checkedStatus);
		}
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to select/unselect the repeating option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param enable
	 *          true/false
	 *            
	 */
	public void clickRepeatingOption(Client client, boolean enable) {
		String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UISwitch']", 0, "invokeMethod:'{\"selector\":\"isOn\",\"arguments\":[]}'");
		if(checkedStatus.equalsIgnoreCase("0")){
			if(enable)
				client.click("NATIVE", "xpath=//*[@class='UISwitch']", 0, 1);
		}else if(checkedStatus.equalsIgnoreCase("1")){
			if(!enable)
				client.click("NATIVE", "xpath=//*[@class='UISwitch']", 0, 1);
		}
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to swipe down and select the reminder
	 * 
	 * @param client
	 *			Integrate SeeTestAutomation
	 * @param reminderName
	 *          reminderName to be selected
	 * @param click
	 *            true/false
	 *            
	 */
	public void selectReminder(Client client, String reminderName, boolean click) {
		if(!client.isElementFound("NATIVE","xpath=//*[@text='"+reminderName+"' and ../parent::*[@class='LibreLink.ReminderTableCell' ] and @onScreen='true']",0)){
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']",
					"Down", 300, 300, "NATIVE", "xpath=//*[@text='"+reminderName+"' and ../parent::*[@class='LibreLink.ReminderTableCell' ] and @onScreen='true']", 0, 1000, 5, false);
		}
		if(click){
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@text='"+reminderName+"' and ../parent::*[@class='LibreLink.ReminderTableCell' ] and @onScreen='true']", 0, 1);
		}

		waitFor(client,1);
	}

	
	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to navigate top of the Reminder screen
	 * 
	 * @param client
	 *		Integrate SeeTestAutomation
	 * 
	 */
	public void navigateToReminderTop(Client client) {
		if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor' and @top='true']", 0))
			client.swipeWhileNotFound("Up", 500, 1000, "NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor' and @top='true']", 0, 1000, 3, false);

	}

	/**
	 * Author: ShabinaSherif
	 *   
	 * Method to edit the Existing Reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder
	 * @param hrs
	 *          select hours
	 * @param mins
	 *          select the minutes
 	 * @param newName
	 *          select the new name for reminder
	 *            
	 */
	public void editReminder(Client client, String name, int hrs, int mins, String newName) {

		selectReminder(client,name,true);
		enterReminderName(client,newName);
		reminderSetTime(client,hrs,mins);
	}


	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to Start or cancel the reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param click
	 *          true/false to start/cancel
	 *          
	 */

	public void startReminder(Client client, boolean click) {
		if (click) {
			client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='ReminderSetButton']", 0, 1);
		} else {
			client.click("NATIVE", "xpath=//*[@class='LibreLink.LLCancelButton']", 0,1);
		}
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to delete all the reminders
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void deleteAllReminders(Client client) {
		int count = client.getElementCount("NATIVE", "class=LibreLink.ReminderTableCell");
		for (int i=1;i<count;i++){
			client.elementSwipe("NATIVE", "class=LibreLink.ReminderTableCell", i, "Right", 0, 500);
			client.waitForElement(
					"NATIVE",
					"xpath=//*[@class='UISwipeActionStandardButton']",
					0, 500);
			client.click(
					"NATIVE",
					"xpath=//*[@class='UISwipeActionStandardButton']",
					0, 1);
			waitFor(client,1);
		}

	}

	/**
	 * Author: ShabinaSherif
	 *  
	 * Method to verify Delete reminder option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 *          
	 */

	public void verifyDeleteReminder(Client client, String name) {
		selectReminder(client,name,false);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Right", 0, 1000);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0, 500);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Left", 0, 500);
		waitFor(client,1);
		client.verifyElementNotFound(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				1);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to delete the reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 *            
	 */

	public void deleteReminder(Client client, String name) {
		selectReminder(client,name,false);
		client.elementSwipe("NATIVE", "text=" + (name), 0, "Right", 0, 500);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0, 500);
		client.click(
				"NATIVE",
				"xpath=//*[@class='UISwipeActionStandardButton']",
				0, 1);
		waitFor(client,1);

		client.verifyElementNotFound("NATIVE", "text=" + (name), 0);
	}


	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify Reminder 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          reminder name
	 * @param time
	 *			reminder time
	 * @param isRepeatEnabled
	 *          true/false
	 *            
	 */
	public void verifyReminder(Client client, String name, String time,boolean isRepeatEnabled) {
		selectReminder(client,name,false);
        
		if(time!=null){
			if (getLanguage().contains("U.K.")) {
	        	time = time.toLowerCase();

	        	}
			client.verifyElementFound("NATIVE", "xpath=//*[@text='"+time+"' and ./preceding-sibling::*[@text='"+name+"']]", 0);
		}

		if (isRepeatEnabled) {
			verifyRepeatOption(client, name);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify Reminder with Repeat option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 */
	public void verifyRepeatOption(Client client, String name) {

		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reload' and ./following-sibling::*[@accessibilityLabel='"+name+"']]", 0);

	}


	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder notification dialog
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @param clearDialog
	 *          true/false
	 *            
	 */
	public void verifyReminderNotificationDialog(Client client, String name, boolean clearDialog) {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reminder']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"+name+"' and @class='UITextView']", 0);
		if(clearDialog){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0, 1);	
			
		}
	}

	
	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder notification dialog
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 *            
	 */
	public void verifyReminderStatuswithReload(Client client, String name) {
		if(client.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Reload' and @hidden='false' and ./following-sibling::*[contains(@accessibilityLabel,'"+name+"')]]", 0)){
			Assert.assertEquals("1", returnSwitchStatus(client,name));
		}else{
			Assert.assertEquals("0", returnSwitchStatus(client,name));
		}

		
	}
	
	
	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify Reminder notification 
	 * 
	 * @param client
	 * 			  Integrate SeeTestAutomation
	 * @param name
	 *            choose the reminder name
	 * @param openReminder
	 *            true/false
	 *
	 */
	public void verifyReminderNotification(Client client, String name, boolean openReminder) {
		
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'LIBRELINK,')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Reminder, "+name+"')]", 0);
		if(openReminder){
			client.elementSwipe("NATIVE", "xpath=//*[contains(@text,'Reminder, "+name+"')]", 0, "Left", 100, 500);
			waitFor(client,5);
		}else{
			clearSingleNotification(client,name);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify scan sensor notification 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param openReminder
	 *          true/false
	 */
	public void verifyScanSensorNotification(Client client, boolean openReminder) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='NotificationShortLookView' and contains(@value,'Timer Expired')]", 0, 240000);
		waitFor(client,2);
		openNotification(client);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'LIBRELINK,')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Timer Expired, Scan Sensor')]", 0);
		if(openReminder){
			client.elementSwipe("NATIVE", "xpath=//*[contains(@text,'Timer Expired, Scan Sensor')]", 0, "Left", 0, 500);
			waitFor(client,5);
		}else{
			clearSingleNotification(client,"Scan Sensor");
			closeNotification(client);
		}

	}


	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Reminder switch is enabled/disabled
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *         	reminder name
	 * @param isEnabled
	 *         true/false
	 *         
	 */
	public void verifyReminderStatus(Client client, String name, boolean isEnabled) {
		selectReminder(client,name,false);
		if(isEnabled){
			Assert.assertEquals("1", returnSwitchStatus(client,name));}
		else{
			Assert.assertEquals("0", returnSwitchStatus(client,name));
		}

	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to create reminder with advanced time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @param time
	 *          set the advanced minute
	 *            
	 */
	public void addReminderWithAdvancedTime(Client client, String name, Integer time) {

		clickAddReminder(client);
		enterReminderName(client,name);
		advanceReminderTimer(client, time);
		startReminder(client,true);
		client.waitForElement("NATIVE", "xpath=//*[@class='LibreLink.RegularLabel' and ./parent::*[@class='LibreLink.LLBanner'] and contains(@text,'"+name+"')]", 0, 1000);
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to set reminder time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hrs
	 *          set the hours
	 * @param mins
	 *          set the minutes
	 *
	 */
	public void reminderSetTime(Client client, int hrs, int mins) {
		String time = null;
        if (getLanguage().contains("U.K.")) {

            if (client.isElementFound("NATIVE",
                         "xpath=//*[@accessibilityLabel='am']", 0)) {
                  String _24HourTime = hrs + ":" + mins;
                  SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
                  SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh.mm a");

                  try {
                         Date _24HourDt = _24HourSDF.parse(_24HourTime);
                         time = _12HourSDF.format(_24HourDt).toLowerCase();
                  } catch (ParseException e) {
                         // TODO Auto-generated catch block
                         e.printStackTrace();
                  }
            } else {
                  time = hrs + "." + mins;
            }
     
     } else {
            time = hrs + "." + mins;
     }
     client.elementSetProperty("NATIVE", "xpath=//*[@class='UIDatePicker']",
                  0, "time", time);
     waitFor(client, 1);

	}

	/**
	 * Author: ShabinaSherif 
	 *
	 * Method to advance the Reminder Time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param addTime
	 *          set the advanced time
	 *            
	 */
	public void advanceReminderTimer(Client client, Integer addTime) {

		int hr = getCurrentHours();
		int min1 = getCurrentMinutes();
		int min;
		int hour;
		int minute = min1 + addTime;
		if (minute > 60) {
			hour = hr + 1;
			min = minute - 60;
		} else if (minute < 60) {
			hour = hr;
			min = minute;
		} else {
			hour = hr + 1;
			min = 00;
		}
		if(hour>=24){
			hour=hour-24;
		}
		reminderSetTime(client,hour,min);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to edit the existing Reminder With advanced Time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder to be edited
	 * @param time
	 *          set the advance time
	 *            
	 */

	public void editReminderWithAdvancedTime(Client client, String name, Integer time) {
		navigateToReminderTop(client);
		selectReminder(client,name,true);
		enterReminderName(client,name);
		advanceReminderTimer(client, time);
		startReminder(client,true);
	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify Repeating Options visibility
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param isEnabled
	 *          true/false
	 *            
	 */
	public void verifyRepeatingOptionsAvailability(Client client, boolean isEnabled) {

		clickRepeatingOption(client, isEnabled);
		String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='All']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");

		if(isEnabled){
			verifyRepeatingOptionsNotVisible(client, false);
			if(checkedStatus.equals("1")){
				verifyRepeatingOptions(client,true);}
			else{
				verifyRepeatingOptions(client,false);
			}
		}
		else{
			verifyRepeatingOptionsNotVisible(client, true);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to click on all check box
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void selectAllCheckBox(Client client) {
		String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='All']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
		if(checkedStatus.equals("0")){
			client.click("NATIVE","xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./following-sibling::*[@text='All']]", 0, 1);
		
		}
		verifyRepeatingOptions(client, true);

	}

	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to click on all the days except All
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void selectAlldays(Client client) {
		String daysArray[] = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };

		for (int i=0;i<daysArray.length;i++){

			String checkedStatus = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+daysArray[i]+"']]", 0, "invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
			if(checkedStatus.equals("0")){
				client.click("NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UIView'] and ./following-sibling::*[@text='"+daysArray[i]+"']]", 0, 1);
			}
		}
		verifyRepeatingOptions(client, true);
	}


	/**
	 * Author: ShabinaSherif
	 *            
	 * Method to verify enable or disable reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @param enable
	 *          true/false
	 *            
	 */
	public void enableordisableReminder(Client client, String name, boolean enable) {
		navigateToReminderTop(client);
		selectReminder(client,name,false);
		String enabledStatus = returnSwitchStatus(client,name);
		if((enabledStatus.equals("1") && !enable) || (enabledStatus.equals("0") && enable) ){
			client.click("NATIVE",
					"xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, 1);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to verify Reminder Scan Sensor
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void verifyRemindersScanSensor(Client client) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor']", 0, 1000);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='Scan Sensor']]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='--:--']", 0);

	}

	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to Enable or Disable the Scan Sensor
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param enable
	 *          true/false
	 *            
	 */

	public void enableORdisableScanSensor(Client client, boolean enable) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor']", 0, 1000);
		String enabledStatus = returnSwitchStatus(client,"Scan Sensor");
		if((enabledStatus.equals("1") && !enable) || (enabledStatus.equals("0") && enable) ){
			client.click("NATIVE",
					"xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='Scan Sensor']]", 0, 1);
		}
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to Verify Scan Sensor Reminder
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hour
	 *          select the reminder hour
	 *            
	 */

	public void setHourAndscanSensorTimerReminder(Client client, int hour) {
		clickScanSensor(client);
		selectScanSensorTime(client,hour);
		client.click("NATIVE", "xpath=//*[@accessibilityIdentifier='ReminderSetButton']", 0, 1);
		waitFor(client, 1);
		Assert.assertEquals("1", returnSwitchStatus(client,"Scan Sensor"));
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to click scan Sensor
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void clickScanSensor(Client client) {

			if (client
					.isElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor']", 0)) {
				client.click("NATIVE", "xpath=//*[@accessibilityLabel='Scan Sensor']", 0, 1);
			}
	
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to select scan sensor time
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param hr
	 *          select the reminder hour
	 *            
	 */

	public void selectScanSensorTime(Client client, int hr) {
		hr=hr-1;
		client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIPickerColumnView']", 0, "invokeMethod:'{\"selector\":\"selectRow:animated:notify:\",\"arguments\":[\"0\", \"true\", \"true\"]}'");
		client.runNativeAPICall("NATIVE", "xpath=//*[@class='UIPickerColumnView']", 0, "invokeMethod:'{\"selector\":\"selectRow:animated:notify:\",\"arguments\":[\""+hr+"\", \"true\", \"true\"]}'");
		waitFor(client,1);
	}

	/**
	 * Author: ShabinaSherif 
	 *  
	 * Method to click scan Sensor and verify Hours
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void clickScanSensorandVerifyHours(Client client) {

		clickScanSensor(client);
		for (int i = 1; i <= 12; i++) {
			selectScanSensorTime(client,i);
			int count=0;
			if(i==1){
				client.verifyElementFound("NATIVE", "xpath=//*[@text='"+i+" hr']", 0);
				count = client.getElementCount("NATIVE", "xpath=//*[@text='"+i+" hr']");
			}else{
				client.verifyElementFound("NATIVE", "xpath=//*[@text='"+i+" hrs']", 0);
				count = client.getElementCount("NATIVE", "xpath=//*[@text='"+i+" hrs']");
			}
			Assert.assertEquals(3, count);

		}

	}


	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify scan sensor notification dialog
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param clearDialog
	 *          true/false
	 *            
	 */
	public void verifyScanSensorNotificationDialog(Client client, boolean clearDialog) {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Timer Expired']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Scan Sensor' and @class='UITextView']", 0);
		if(clearDialog){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='OK']", 0, 1);	
			waitFor(client,1);
		}
	}


	/**
	 * Author: ShabinaSherif 
	 * 
	 * Method to return reminder switch status 
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param name
	 *          choose the reminder name
	 * @return isSelected
	 * 			Return switch status           
	 */

	public String returnSwitchStatus(Client client, String name) {
		String isSelected = client.runNativeAPICall("NATIVE", "xpath=//*[@class='UISwitch' and ./following-sibling::*[@text='"+name+"']]", 0, "invokeMethod:'{\"selector\":\"isOn\",\"arguments\":[]}'");
		return isSelected;
	}

	/**
	 * Author: ShabinaSherif 
	 *            
	 * Method to verify scan sensor reminder status
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param countdown
	 *          set time
	 * @param isEnabled
	 *          true/false
	 *            
	 */

	public void verifyScanSensorStatus(Client client, boolean isEnabled, String countdown) {

		client.verifyElementFound("NATIVE", "accessibilityLabel=Scan Sensor", 0);
		if (isEnabled) {
			Assert.assertEquals("1", returnSwitchStatus(client, "Scan Sensor"));

		}
		else{
			Assert.assertEquals("0", returnSwitchStatus(client, "Scan Sensor"));
			
		}

		if(countdown!=null){
			if(countdown.equals("--:--")){
				client.verifyElementFound("NATIVE", "text=--:--", 0);
			}else{
				String t1 = client
						.elementGetText(
								"NATIVE",
								"xpath=//*[@class='UILabel' and ./preceding-sibling::*[@accessibilityLabel='Scan Sensor']]",
								0);
				waitFor(client,5);
				String t2 = client
						.elementGetText(
								"NATIVE",
								"xpath=//*[@class='UILabel' and ./preceding-sibling::*[@accessibilityLabel='Scan Sensor']]",
								0);
				String t3 = t2.substring(0, t2.length() - 2);
				String newtime=countdown.substring(0,countdown.length()-2);


				if (!t1.equals(t2)) {
					Assert.assertTrue(t3.contains(newtime));

					System.out
					.println("Scan Sensor TIMERS reminder displayed a countdown timer which started from "
							+ t3 + "XX");
				}

			}
		}
	}

		/**
		 * Author: ShabinaSherif 
		 * 
		 * Method for an reminder content to vanish
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */
		public void reminderAlarmContentvanish(Client client) {
			String content = client.elementGetText("NATIVE", "xpath=//*[@class='LibreLink.RegularLabel' and ./parent::*[@class='LibreLink.LLBanner']]",
					0);
			client.waitForElementToVanish("NATIVE", "text=" + content, 0, 120000);

		}
		
		/**
		 * Author: ShabinaSherif 
		 * 
		 * Method for an reminder content to vanish
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */
		public void reminderTimerContentvanish(Client client) {
			client.waitForElementToVanish("NATIVE", "xpath=//*[contains(@text,'Next Reminder')]", 0, 120000);

		}

		/**
		 * Author: ShabinaSherif
		 * 
		 * Method to select and verify Reminder With special Characters
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */
		public void selectandVerifyReminderWithSpecialCharacters(Client client) {
			selectReminder(client,LibrelinkConstants.FIFTYCHARACTER_REMINDER_NAME,true);
			enterReminderName(client,LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME);
			startReminder(client,true);
			selectReminder(client,LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME,false);
			client.verifyElementFound("NATIVE", "text=" + LibrelinkConstants.FIFTYCHARACTER_Mixed_REMINDER_NAME, 0);

		}

		/**
		 * Author: ShabinaSherif 
		 *            
		 * Method to verify Next Reminder with BackGround Color
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * @param name
		 *          reminder name
		 * @param time
		 *          reminder time
		 *            
		 */

		public void verifyNextReminderwithBackGroundColor(Client client,
				String name, String time) {

			client.verifyElementFound("NATIVE",
					"xpath=//*[@class='LibreLink.RegularLabel' and contains(@text,'" + time
					+ ", " + name + "') and ./parent::*[@class='LibreLink.LLBanner']]", 0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@class='LibreLink.LLBanner' and @backgroundColor='0x138BE8']",
					0);
		}


		/**
		 * Author: ShabinaSherif 
		 *            
		 * Method to select and verify Reminder With 50+ Characters
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * 
		 */

		public void selectandVerifyreminderWithFiftyPlusCharacters(Client client) {
			enterReminderName(client,LibrelinkConstants.FIFTYPLUSCHARACTER_REMINDER_NAME);
			advanceReminderTimer(client, 5);
			startReminder(client,true);
			selectReminder(client,LibrelinkConstants.FIFTYCHARACTER_REMINDER_NAME,false);
			client.verifyElementFound("NATIVE", "text=" + LibrelinkConstants.FIFTYCHARACTER_REMINDER_NAME, 0);
			client.verifyElementNotFound("NATIVE","text=" + LibrelinkConstants.FIFTYPLUSCHARACTER_REMINDER_NAME, 0);
		}


		/**
		 * Author: ShabinaSherif
		 *            
		 * Method to return the day of the week
		 * 
		 * @param day
		 *            Choose day of week
		 * @return day
		 * 			returns day of the Week           
		 */

		public int dayoftheWeek(String day) {
			if(day.equals("Monday")){
				return Calendar.MONDAY;
			}else if(day.equals("Tuesday")){
				return Calendar.TUESDAY;
			} else if(day.equals("Wednesday")){
				return Calendar.WEDNESDAY;
			}else if(day.equals("Thursday")){
				return Calendar.THURSDAY;
			}else if(day.equals("Friday")){
				return Calendar.FRIDAY;
			}else if(day.equals("Saturday")){
				return Calendar.SATURDAY;
			}else if(day.equals("Sunday")){
				return Calendar.SUNDAY;
			} else return 0;
		}

		/**
		 * Author: ShabinaSherif
		 *            
		 * Method to change device day
		 * 
		 * @param client
		 * 			Integrate SeeTestAutomation
		 * @param day
		 *          Choose day of week
		 * @param timeduration
		 * 			Time to be updated
		 * @throws ParseException
		 * 			Throws Parse exception for date selection
		 * 
		 */
		public void changeDeviceDay(Client client, String day, String timeduration) throws ParseException {
			waitFor(client,1);
			DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance(Locale.US);
			System.out.println(sdf.format(cal.getTime()));
			int weekday = dayoftheWeek(day);
			while (cal.get(Calendar.DAY_OF_WEEK) != weekday) {
				cal.add(Calendar.DATE, 1);
			}
			String timeSplit[] = timeduration.split(":");
			cal.set(Calendar.HOUR, Integer.parseInt(timeSplit[0]));
			cal.set(Calendar.MINUTE, Integer.parseInt(timeSplit[1]));
			cal.add(Calendar.MINUTE, -2);
			
			String timeDuration =cal.get(Calendar.HOUR) +":"+cal.get(Calendar.MINUTE);
			 String month_name =new SimpleDateFormat("MMM d").format(cal.getTime()).toString();
             
			 openDateTimeSettings(client);
				if (!client
						.isElementFound(
								"NATIVE",
								"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
								0)) {
					client.click(
							"NATIVE",
							"xpath=//*[@text='24-Hour Time' and @class='UIASwitch']",
							0, 1);
				}
				client.verifyElementFound(
						"NATIVE",
						"xpath=//*[@text='24-Hour Time' and @class='UIASwitch' and contains(@value,'1')]",
						0);
			automaticDateAndTime(client, false);
			openDeviceDatePicker(client);
			 setTime(client, timeDuration);
             client.elementSetProperty("NATIVE", "xpath=//*[@class='UIAPicker']", 0, "text", month_name);
             waitFor(client,1);
             closePhoneSettings(client);
             launch(client);
             selectSkipForDebugging(client);
             navigateToScreen(client, "Reminders");
		}


	}
