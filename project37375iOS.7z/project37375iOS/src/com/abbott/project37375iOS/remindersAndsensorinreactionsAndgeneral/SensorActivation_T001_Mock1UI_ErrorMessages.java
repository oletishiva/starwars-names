package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class SensorActivation_T001_Mock1UI_ErrorMessages
extends SensorHelper {

	@Test
	public void test_SensorActivation_T001_Mock1UI_ErrorMessages() throws Exception {

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1174
		 * @Expected HomeScreen shows CHECK GLUCOSE screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step1);
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,-1, 0, 0,"1/14");
		verifyPageTitles(client,"CHECK GLUCOSE");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1174
		 * @Expected HomeScreen shows Apply New Sensor screen is displayed and Scan New Sensor button is displayed on Next screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step2);
		debugDrawerClearData(client);
		editConfiguration(client, -15,-1, 0,"1/14");
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1084
		 * @Expected Sensor Expired dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step3);
		debugDrawerClearData(client);
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Realtime","100",false,0,0);
		scanMockSensor(client,"EXPIRED");
		verifySensorDialogScreen(client,"sensorExpired","sensorExpiredContent");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1084
		 * @Expected App returns back to Home screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step4);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1085
		 * @Expected Sensor Already Used dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step5);
		debugDrawerClearData(client);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_ACTIVE");
		clickOnButtonOption(client,"YES",true);
		openDebugDrawer(client);
		scanMockSensor(client,"ALREADY_STARTED");
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifySensorDialogScreen(client,"error_sensor_already_started_title","error_sensor_already_started_msg");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifySensorDialogScreen(client,"error_sensor_already_started_title","error_sensor_already_started_msg_llj");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1085
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step6);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1087
		 * @Expected Scan Error dialog is displayed for Response Corrupt error
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step7);
		openDebugDrawer(client);
		scanMockSensor(client,"RESPONSE_CORRUPT");
		verifySensorDialogScreen(client,"error_sensor_corrupt_title","iosDefaultSensorErrorMsg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1087
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step8);
		clickOnButtonOption(client,"OK",true);
		verifyHomePage(client);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1088
		 * @Expected Replace Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step9);
		openDebugDrawer(client);
		scanMockSensor(client,"TERMINATED");
		verifySensorDialogScreen(client,"error_sensor_terminated_title","error_sensor_terminated_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1088
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step10);
		clickOnButtonOption(client,"OK",true);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1089
		 * @Expected Replace Sensor dialog is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step11);
		openDebugDrawer(client);
		scanMockSensor(client,"REMOVED");
		verifySensorDialogScreen(client,"error_sensor_removed_title","error_sensor_removed_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1089
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step12);
		clickOnButtonOption(client,"OK",true);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1090
		 * @Expected Incompatible Sensor dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step13);
		openDebugDrawer(client);
		scanMockSensor(client,"NOT_COMPATIBLE");
		verifySensorDialogScreen(client,"error_sensor_incompatible_title","error_sensor_incompatible_msg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1090
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step14);
		clickOnButtonOption(client,"OK",true);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS1083
		 * @Expected Scan Error dialog is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step15);
		openDebugDrawer(client);
		scanMockSensor(client,"TRANSMISSION_ERROR");
		verifySensorDialogScreen(client,"error_sensor_transmission_title","iosDefaultSensorErrorMsg");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS1083
		 * @Expected App returns back to Home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.SensorActivation_T001_Mock1UI_ErrorMessages_Step16);
		clickOnButtonOption(client,"OK",true);
		verifyPageTitles(client, "SCAN NEW SENSOR");
		capturescreenshot(client, getStepID(), true);

		selectingSASMode(client,"DEFAULT");
	}

}
