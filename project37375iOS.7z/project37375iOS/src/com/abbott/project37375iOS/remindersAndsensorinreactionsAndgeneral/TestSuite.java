package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ General_T001_GlucoseGraph_TimeZoneChange.class, General_T002_GlucoseGraph_HG_21mGap_Connect35m.class,
		General_T003_GlucoseValue_distinguish.class, General_T004_DefaultLang_SysInfo.class,
		General_T005_Results_Resolution.class, General_T006_Results_WithUOM.class,
		Reminder_T001_Alarm_Reminder_UI_Check.class, Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check.class,
		Reminder_T003_Timer_Reminder_UI_Check.class ,SensorActivation_T001_Mock1UI_ErrorMessages.class,
		SensorScanning_T001_Mock1UI_ErrorMessages.class,
		SensorScanning_T002_Mock1UI_ErrorMessages_Change_Sensor_State.class 
		})
public class TestSuite {

}
