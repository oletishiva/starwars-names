package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Assert;

import com.abbott.project37375iOS.main.BaseHelper;
import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.experitest.client.Client;

public class UIGeneralHelper extends BaseHelper {

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Average Glucose Units in Home screen
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */
	public void verifyAvgGlucoseUnitsinHome(Client client)  {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo' and @onScreen='true']",
				0, 10000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='AVERAGE' and @text='AVERAGE']",
				0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[contains(@text,'"+getUnits()+"') and ./preceding-sibling::*[@accessibilityLabel='AVERAGE']]",
				0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Time in target in Home screen
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void verifyTimeintargetinHome(Client client) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo' and @onScreen='true']",
				0, 10000);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='TIME IN TARGET']",
				0);
		String timeintarget = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='LibreLink.BoldLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[@text='TIME IN TARGET']]",
						0);
		Assert.assertTrue(timeintarget.contains("%"));
		String time=timeintarget.replace(" %", "");
		Integer timeintargetVal = Integer.parseInt(time);
		Assert.assertTrue("Value in range", 0 <= timeintargetVal
				&& timeintargetVal <= 100);
	}





	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Target Range Unit Of Measurement
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */
	public void verifyTargetRangeUOM(Client client) {
		client.waitForElement("NATIVE",
				"accessibilityLabel=Target Glucose Range", 0, 10000);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='"
				+ getUnits() + "']", 0);
	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify GetStartedNow Screens which support multi language
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */
	public void getStartedNowScreens(Client client) {
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 2);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 3);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 4);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 5);
	}



	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Click On Country Of Origin Page which support multi language
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 *           
	 */
	public void clickOnCountryOfOrigin(Client client) {
		client.waitForElement("NATIVE", "text=${countryOfOriginTitle}", 0,10000);
		client.click("NATIVE", "xpath=//*[@class='LibreLink.LLButton1']", 0, 1);
	}


	/**
	 * Author:NagarajuKasarla
	 * 
	 * Method to Verify Sensor scan page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */
	public void verifySensorscanpage(Client client) {
		client.waitForElement("NATIVE", "accessibilityLabel=SENSOR USAGE", 0,
				5000);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='Total Scans' and @text='Total Scans']",
				0);
		String totalScans = client.elementGetText("NATIVE",
				"xpath=//*[@accessibilityIdentifier='scanCountLabel']", 0);
		assertverifyForSensorUsageScan(client, totalScans);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='Scans Per Day' and @text='Scans Per Day']",
				0);
		String scansPerDay = client.elementGetText("NATIVE",
				"xpath=//*[@accessibilityIdentifier='averageScanLabel']", 0);
		assertverifyForSensorUsageScan(client, scansPerDay);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='% of Sensor Data Captured' and @text='% of Sensor Data Captured']",
				0);
		String sensorData = client.elementGetText("NATIVE",
				"xpath=//*[@accessibilityIdentifier='dataCapturedLabel']", 0);
		assertverifyForSensorUsageScan(client, sensorData);
	}

	public void assertverifyForSensorUsageScan(Client client, String scans) {
		int scanvalue = Integer.parseInt(scans);
		Assert.assertTrue("Value in range", 0 <= scanvalue && scanvalue <= 1000);
	}

	/**
	 * Author:NagarajuKasarla
	 * 
	 * Method to Verify Time in Last Scan
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 */
	public void verifyTimeinLastScan(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='LAST SCAN' and @text='LAST SCAN']",
				0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@class='UIView' and @width>0 and ./*[@accessibilityLabel='LAST SCAN']]",
				0);
		String lastScan = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='LibreLink.BoldLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[@text='LAST SCAN']]",
						0);
		String lastScanHours = lastScan.substring(0, 2);
		String lastScanMin = lastScan.substring(3, 5);
		Integer scanvalueHours = Integer.parseInt(lastScanHours);
		Integer scanvalueMin = Integer.parseInt(lastScanMin);
		Assert.assertTrue("Value in range", 00 <= scanvalueHours
				&& scanvalueHours <= 23 && 00 <= scanvalueMin
				&& scanvalueMin <= 59);
	}

	/**
	 * Author:NagarajuKasarla
	 * 
	 * Method to Verify Time in Logbook Details Screen
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */
	public void verifyTimeinLogbookDetails(Client client) {
		client.waitForElement("NATIVE", "accessibilityLabel=Logbook Detail", 0,
				5000);
		client.verifyElementFound("NATIVE",
				"accessibilityIdentifier=LogbookDetailTimeLabel", 0);

		String scanResultDate = client.elementGetText("NATIVE",
				"xpath=//*[@accessibilityIdentifier='LogbookDetailDateLabel']",
				0);
		String LogbookScanResultDate = scanResultDate.replaceAll("\\D+", "");
		int scanvalue = Integer.parseInt(LogbookScanResultDate);
		Assert.assertTrue("Value in range", 1 <= scanvalue && scanvalue <= 31);
	}

	/**
	 * Author:NagarajuKasarla
	 * 
	 * Method to Verify OS details
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 */
	public void verifyOSDetails(Client client) {
		String DeviceOs = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='UITableViewLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[contains(@text,'OS Version')]]",
						0);
		closeRunningBrowser(client);
		String osversion = getDeviceOSVersion(client);
		System.out.println("========"+osversion);
		Assert.assertEquals(DeviceOs, osversion);
		launch(client);
	}


	/**
	 *  Author: NagarajuKasarla
	 * 
	 * Method to Get Device OS-Version
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *  @return osversion
	 *      Returns OS version
	 */
	public String getDeviceOSVersion(Client client) {
		closePhoneSettings(client);
		openSettings(client);
		if(client.isElementFound("NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'Language & Region') and @XCElementType='XCUIElementTypeNavigationBar']",
				0)){
			
			client.click("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeButton']", 0, 1);
			waitFor(client,1);
			client.click("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeButton']", 0, 1);
			waitFor(client,1);
		}
		searchInSettings(client,"General");
		waitFor(client, 2);
		client.click("NATIVE", "xpath=//*[@text='About' and @XCElementType='XCUIElementTypeStaticText']", 0, 1);
		waitFor(client, 2);
		String osVer = client.elementGetText("NATIVE", "xpath=//*[@XCElementType='XCUIElementTypeStaticText' and @class='UIAStaticText' and ./preceding-sibling::*[@text='Version']]", 0);
		String[] osversion = osVer.split(" ");
		System.out.println("======"+osversion[0]);
		closePhoneSettings(client);
		return osversion[0];
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Click On Calendar Arrow Button
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param direction
	 * 			Which arrow has to be clicked
	 */

	public void clickOnCalanderArrowButton(Client client,String direction) {
		client.click("NATIVE", "accessibilityIdentifier="+direction, 0, 1);	
	}





	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Glucose Value Type either show in Whole number(mg/dL) or one
	 *         decimal for (mmol/L) in Logbook Screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param count
	 *          set the count value           
	 */
	public void verifyGlucoseValueTypeInLogbook(Client client, int count) {
		client.waitForElement("NATIVE","xpath=//*[@accessibilityLabel='Logbook' and @onScreen='true']", 0, 10000);
		if (getUnits().equals("mg/dL")) {
			for (int click = 0; click < count; click++) {
				String str0 = client
						.elementGetText("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookGlucoseValueLabel' and @onScreen='true']", click);
				Assert.assertFalse(str0, str0.contains("."));
				System.out.println("mg/dL values displayes in whole number ");
			}
		} else {
			for (int click = 0; click < count; click++) {
				String value = client.elementGetText("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookGlucoseValueLabel' and @onScreen='true']",
						click);
				Assert.assertTrue(value, value.contains("."));
				System.out.println("mmol/L values displayes in one decimal  ");
			}
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify AverageGlucose Value Type either show in Whole number(mg/dL)
	 *         or one decimal for (mmol/L)
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void verifyAverageGlucoseValueType(Client client) {
		String str = client.elementGetText("NATIVE", "accessibilityIdentifier=ReportsExtraInfoLabel", 0);
		String[] splited = str.split(" ");
		if (getUnits().equals("mg/dL")) {
			Assert.assertFalse(splited[1], splited[1].contains("."));
			System.out.println("mg/dL values displayes in whole number ");
		} else {
			Assert.assertTrue(splited[1], splited[1].contains("."));
			System.out.println("mmol/L values displayes in one decimal  ");
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify TimeInTarget Value Type either show in Whole number(mg/dL) or
	 *         one decimal for (mmol/L)
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void verifyTimeInTargetValueType(Client client) {
		String str = client.elementGetText("NATIVE","accessibilityIdentifier=ReportsExtraInfoLabel",0);
		String[] splited = str.split(" ");
		if (getUnits().equals("mg/dL")) {
			Assert.assertFalse(splited[2], splited[2].contains("."));
			Assert.assertFalse(splited[4], splited[4].contains("."));
			System.out.println("mg/dL values displayes in whole number ");
		} else {
			Assert.assertTrue(splited[2], splited[2].contains("."));
			Assert.assertTrue(splited[4], splited[4].contains("."));
			System.out.println("mmol/L values displayes in one decimal  ");
		}
	}




	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify LogBook Details Screen Value
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *            set the Scan Value           
	 */
	public void verifyLogBookDetailsScreenValue(Client client, String value) {
		verifyGlucoseValueInLogBookDetailsScreen(client,value);
		if (!(value.equals("HI") || value.equals("LO"))) {
			if (getUnits().equals("mg/dL")) {
				Assert.assertFalse(value, value.contains("."));
				System.out.println("mg/dL values displayes in whole number ");
			} else  {
				Assert.assertTrue(value, value.contains("."));
				System.out.println("mmol/L values displayes in one decimal  ");
			}
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 *  Method to Click on Blood Drop Icon
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void clickBloodDropIcon(Client client) {
		client.click("NATIVE",
				"xpath=//*[@accessibilityIdentifier='BGM_Drop_Plus' and @onScreen='true']", 0, 1);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 *  Method to Set the blood glucose result in mg/dL
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param value
	 *            select the value
	 */
	public void setBGR(Client client, String value) {
		client.verifyElementFound("NATIVE", "xpath=//*[@class='_UITextFieldContentView']", 0);
		client.elementSendText("NATIVE", "xpath=//*[@class='_UITextFieldContentView' and ./*[@class='UITextSelectionView']]", 0, value);
		client.closeKeyboard();
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 *  Method to Verify BGR Type show in Whole number(mg/dL)
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void verifyBGRValueType(Client client) {
		String value = client.elementGetText("NATIVE", "xpath=//*[@class='UITextField']", 0);
		Assert.assertFalse(value, value.contains("."));
		System.out.println("mg/dL values displayes in whole number ");

	}



	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to verify Insulin Units
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param insulin
	 *            verify the insulin(Rapid/Long - Acting Insulin)
	 */
	public void verifyInsulinUnits(Client client, String insulin){
		client.verifyIn(
				"NATIVE",
				"xpath=(//*[@class='UITableView' and ./parent::*[@class='UIView']]/*/*[@class='UITableViewCellContentView' and ./*[@text='"+insulin+"-Acting Insulin']])",
				0, "Down", "NATIVE", "xpath=//*[@text='units']", 0, 0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Click on Carbohydrate Unit
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param carbunit
	 *            set and Click the Carbohydrate units
	 */
	public void clickCarbohydrateUnit(Client client, String carbunit) {
		client.waitForElement("NATIVE", "text=${servings}", 0,
				10000);
		client.click("NATIVE", "text=${" + carbunit + "}", 0, 1);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Click On NoteIcon
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param page
	 *            Verify the page title
	 */
	public void clickOnNoteIcon(Client client,String page) {
		verifyPageTitles(client, page);
		client.waitForElement("NATIVE",
				"accessibilityIdentifier=LogbookGlucoseValueLabel", 0, 10000);
		client.click("NATIVE",
				"accessibilityIdentifier=LogbookGlucoseValueLabel", 0, 1);
		verifyPageTitles(client, "Logbook Detail");
	}



	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify sensor life
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param time
	 *          verify the remain sensor life time
	 */
	public void verifySensorlife(Client client, String time) {
		verifyHomePage(client);
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityIdentifier='sensorLife']", 0, 60000);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityIdentifier='sensorLife']", 0, "Inside", "TEXT",
				time, 0, 0);

	}
	/**
	 * Author:NagarajuKasarla
	 * 
	 * Method to Verify Average Glucose Value
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 */
	public void verifyAverageGlucoseValue(Client client) {
		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='AVERAGE GLUCOSE']",0);
		String avgGlucose = client.elementGetText("NATIVE","xpath=//*[@accessibilityIdentifier='ReportsExtraInfoLabel']",0);
		String[] splited = avgGlucose.split(" ");
		if (getUnits().equals("mg/dL")) {
			int avgValue=Integer.parseInt(splited[1]);
			Assert.assertTrue("glucoseValue", 0<=avgValue && avgValue<=500);	
		}else{
			double avgvalue=Double.parseDouble(splited[1]);
			Assert.assertTrue("glucoseValue", 0.0<=avgvalue && avgvalue<=28.0);
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Glucose Value and Units In Logbook Screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param color           
	 *           verify the color
	 *           
	 * @param glucoseValue
	 *            verify the scanned glucose value
	 */
	public void verifyGlucoseValueInLogbook(Client client,String color, String glucoseValue) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Logbook']", 0, 6000);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + glucoseValue
				+ "']", 0); 
		verifyColorInLogbookList(client, color, glucoseValue);
		if (!(glucoseValue.equals("HI") || glucoseValue.equals("LO"))) {
			verifyGlucoseUnits(client);
		}
	}
	public void verifyColorInLogbookList(Client client, String colorCode, String value){
			if(colorCode.contains("orange")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0xEF6C00' and ../parent::*[contains(@accessibilityLabel,'"+value+"')]]", 0);
			}else if(colorCode.contains("green")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0x8FCB3A' and ../parent::*[contains(@accessibilityLabel,'"+value+"')]]", 0);
			}else if(colorCode.contains("yellow")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0xFFBC00' and ../parent::*[contains(@accessibilityLabel,'"+value+"')]]", 0);
			}else if(colorCode.contains("red")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0xED1C24' and ../parent::*[contains(@accessibilityLabel,'"+value+"')]]", 0);
			}
		
	}
	
	/**
	 * Author:NagarajuKasarla
	 * 
	 *  Method to Verify GlucoseValue In LogBook Details Screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *            verify the glucose value           
	 */
	public void verifyGlucoseValueInLogBookDetailsScreen(Client client, String value) {
		client.waitForElement("NATIVE", "text=Logbook Detail", 0, 10000);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value+ "']", 0);
		if (!(value.equals("HI") || value.equals("LO"))) {
			verifyGlucoseUnits(client);
		}
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Timezone Change details from CST to PST
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyTimezoneChangeDetailsFromCstToPst(Client client) {
		client.sleep(1000);
		System.out.println("==========="+getCstformat());
		System.out.println("==========="+getPstformat());
		System.out.println("==========="+getTimeZoneValue(LibrelinkConstants.US));
		System.out.println("==========="+getTimeZoneValue(LibrelinkConstants.CST));
		if (!getLanguage().contains("English (U.K.)")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getCstformat()+" to "+getPstformat()+" (-2h)']",
					0);
		} else {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getTimeZoneValue(LibrelinkConstants.CST)+" to "+getTimeZoneValue(LibrelinkConstants.US)+" (-2h)']", 0);
		}

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify Timezone Change details from PST to AKDT
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */

	public void verifyTimezoneChangeDetailsFromPstToAkdt(Client client) {
		client.sleep(1000);
		System.out.println("==========="+getAkdtformat());
		System.out.println("==========="+getPstformat());
		if (!getLanguage().contains("English (U.K.)")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getPstformat()+" to "+getAkdtformat()+" (-1h)']",
					0);
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getAkdtformat()+" to "+getPstformat()+" (1h)']",
					0);
		} else {

			client.verifyElementFound("NATIVE","xpath=//*[@text='Time zone change from "+getTimeZoneValue(LibrelinkConstants.AKDT)+" to "+getTimeZoneValue(LibrelinkConstants.US)+" (1h)']",	0);
			client.verifyElementFound("NATIVE","xpath=//*[@text='Time zone change from "+getTimeZoneValue(LibrelinkConstants.US)+" to "+getTimeZoneValue(LibrelinkConstants.AKDT)+" (-1h)']",	0);

		}

	}



	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Set the carbohydrate units and save it
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * 
	 * @param unit
	 *            set the unit to be selected
	 */
	public void setCarbohydrateUnits(Client client, String unit)	{
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Carbohydrate Units", 0);
		client.click("NATIVE", "accessibilityLabel=Carbohydrate Units", 0, 1);
		client.waitForElement("NATIVE", "text=${servings}", 0,
				10000);
		client.click("NATIVE", "text=${" + unit + "}", 0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SAVE' and @onScreen='true']", 0);
		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='SAVE' and @onScreen='true']",
				0, 1);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Method to Verify TimezoneChange Details From PST To AKDT In Logbook Detail screen
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 */
	public void verifyTimezoneChangeDetailsFromPstToAkdtInLogbookDetail(Client client){
		if (!getLanguage().contains("English (U.K.)")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Time zone change from "+getPstformat()+" to "+getAkdtformat()+" (-1h)']",
					0);

		} else {
			client.verifyElementFound("NATIVE","xpath=//*[@text='Time zone change from "+getTimeZoneValue(LibrelinkConstants.US)+" to "+getTimeZoneValue(LibrelinkConstants.AKDT)+" (-1h)']",	0);
		}
	}


}