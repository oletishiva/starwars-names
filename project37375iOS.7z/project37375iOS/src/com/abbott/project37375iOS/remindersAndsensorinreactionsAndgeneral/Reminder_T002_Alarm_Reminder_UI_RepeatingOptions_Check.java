package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;


public class Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check extends TestReminderHelper {

	@Test
	public void test_T002_Alarm_Reminder_UI_RepeatingOptions_Check() throws Exception {

		/**
		 * 
		 * @stepId Pre requisites
		 * @Reqt NA
		 * @Expected
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		launch(client);
		navigateToScreen(client, "Reminders");
		if (!client.isElementFound("NATIVE",
				"xpath=//*[contains(@text,'No active reminders.') and @hidden='false']",
				0)) {
			startUp(client);
			navigateToScreen(client, "Reminders");
		}
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS916
		 * @Expected The below checkboxes are displayed and not checked.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step1);
		clickAddReminder(client);
		clickRepeatingOption(client, true);
		verifyRepeatingOptions(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS916
		 * @Expected All checkboxes are checked.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step2);
		selectAllCheckBox(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS916
		 * @Expected check boxes are not displayed when repeating option is disabled
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step3);
		clickRepeatingOption(client, false);
		verifyRepeatingOptionsNotVisible(client,true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS916
		 * @Expected Check boxes are displayed and checked when repeating option is enabled again
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step4);
		clickRepeatingOption(client, true);
		verifyRepeatingOptions(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS916
		 * @Expected Monday and All options checkbox are only unchecked
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step5);
		selectRepeatingOption(client,"Monday",false);
		verifySingleRepeatingOption(client,"Monday",false);
		verifySingleRepeatingOption(client,"All",false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS916
		 * @Expected All checkboxes are checked.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step6);
		selectRepeatingOption(client,"Monday",true);
		verifyRepeatingOptions(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS916
		 * @Expected checkboxes are not checked when every single day option is unchecked
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step7);
		selectRepeatingOption(client,"All",false);
		verifyRepeatingOptions(client, false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS916
		 * @Expected All checkboxes are checked when every single day option is checked
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/

		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step8);
		selectRepeatingOption(client,"Monday",true);
		selectRepeatingOption(client,"Tuesday",true);
		selectRepeatingOption(client,"Wednesday",true);
		selectRepeatingOption(client,"Thursday",true);
		selectRepeatingOption(client,"Friday",true);
		selectRepeatingOption(client,"Saturday",true);
		selectRepeatingOption(client,"Sunday",true);
		verifyRepeatingOptions(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step9);
		enterReminderName(client,"Before Dinner");
		advanceReminderTimer(client, 2);
		startReminder(client,true);
		String timeduration = client.elementGetText("NATIVE", "xpath=//*[@class='UILabel' and ./preceding-sibling::*[@text='Before Dinner']]", 0);
		changeDeviceDay(client,"Monday",timeduration);
		reminderAlarmContentvanish(client);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step10);
		changeDeviceDay(client,"Tuesday",timeduration);
		reminderAlarmContentvanish(client);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step11);
		changeDeviceDay(client,"Wednesday",timeduration);
		reminderAlarmContentvanish(client);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step12);
		changeDeviceDay(client,"Thursday",timeduration);
		reminderAlarmContentvanish(client);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step13);
		changeDeviceDay(client,"Friday",timeduration);
		reminderAlarmContentvanish(client);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step14);
		changeDeviceDay(client,"Saturday",timeduration);
		reminderAlarmContentvanish(client);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS916_SDAIUIRS917
		 * @Expected After one minute there is a notification displayed in
		 *           mobile that the Alarm is Expired and Before Diner Alarm
		 *           reminder is enabled with repeating symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Reminder_T002_Alarm_Reminder_UI_RepeatingOptions_Check_Step15);
		changeDeviceDay(client,"Sunday",timeduration);
		reminderAlarmContentvanish(client);
		capturescreenshot(client, getStepID()+"_Displaying Notification", true);
		verifyReminderNotificationDialog(client, "Before Dinner",true);
		verifyReminderStatuswithReload(client,"Before Dinner");
		capturescreenshot(client, getStepID()+"_After clicking OK for the notification", true);

	
		
		/**
		 * 
		 * @stepId Clean up
		 * @Reqt
		 * @Expected
		 * @Dependancy NA
		 **/

		selectingSASMode(client,"DEFAULT");
	    currentSystemTime(client);
	}

	

}