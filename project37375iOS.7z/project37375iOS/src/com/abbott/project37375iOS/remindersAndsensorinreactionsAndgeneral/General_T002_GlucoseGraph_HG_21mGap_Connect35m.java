package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;


public class General_T002_GlucoseGraph_HG_21mGap_Connect35m extends UIGeneralHelper {


	@Test
	public void test_General_T002_GlucoseGraph_HG_21mGap_Connect35m() throws Exception {


		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1192
		 * @Expected My Glucose Screen displays No gaps around 09:19 to 09:39; No gaps around 12:30 to 12:50 ; Gap around 07:39 to 08:00 and Gap around 10:54 to 11:15
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step1);
		setTheDateAndTime(client,0,0,0,"14:00");
		loadTestData(client, "MOCK_2", "ADC","Gaps21min-19m20m.json");
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS873
		 * @Expected Home screen glucose graph displays No gaps from 09:19 to 09:39;No gaps from 12:30 to 12:50 ; Gap from 07:39 to 08:00 ;Gap from 10:54 to 11:15
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step2);
		clickOnBackIcon(client);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS887
		 * @Expected Logbook Detail screen glucose graph displays No gaps from 09:19 to 09:39;No gaps from 12:30 to 12:50 ;Gap from 07:39 to 08:00 ;Gap from 10:54 to 11:15
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step3);
		navigateToScreen(client, "Logbook");
		clickOnNoteIcon(client,"Logbook");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1192
		 * @Expected My Glucose Screen displays No gaps from 09:19 to 09:39;No gaps from 12:30 to 12:50 with TZ change icon; Gap from 07:39 to 08:00 ;Gap from 10:54 to 11:15
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step4);
		setTheDateAndTime(client,0,0,0,"14:00");
		loadTestData(client, "MOCK_2", "ADC","Gaps21min-19m20m-Anchorage80m.json");
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS873
		 * @Expected Home screen glucose graph displays No gaps from 09:19 to 09:39 ;No gaps from 12:30 to 12:50 with TZ change icon ;Gap from 07:39 to 08:00 ;Gap from 10:54 to 11:15
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step5);
		clickOnBackIcon(client);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS887
		 * @Expected Logbook Detail Screen glucose graph No gaps from 09:19 to 09:39;Gaps from 11:40 to 12:40 with TZ change icon ;Gap from 06:39 to 07:00;Gap from 09:54 to 10:15
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step6);
		navigateToScreen(client, "Logbook");
		clickOnNoteIcon(client,"Logbook");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1232 
		 * @Expected The scan results screen glucose graph connects the scan result and the last historical glucose
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step7);
		setTheDateAndTime(client,0,0,0,"12:00");
		loadTestData(client, "MOCK_2", "ADC","4hrs-withNotes-35min.json");
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1230
		 * @Expected The Home screen glucose graph connects the scan result and the last historical glucose
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step8);
		clickOnBackIcon(client);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1231
		 * @Expected The Logbook Details screen glucose graph connects the scan result and the last historical glucose
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step9);
		navigateToScreen(client, "Logbook");
		clickOnNoteIcon(client,"Logbook");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1232  
		 * @Expected The scan results screen glucose graph doesn't connect the scan result and the last historical glucose as the time difference is greater than 35 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step10);
		debugDrawerClearData(client);
		loadTestData(client, "MOCK_2", "ADC","4hrs-withNotes-36min.json");
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1230
		 * @Expected The Home screen glucose graph doesn't connect  the scan result and the last historical glucose as the time difference is greater than 35 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step11);
		clickOnBackIcon(client);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1231
		 * @Expected The Logbook Details screen glucose graph doesn't connect  the scan result and the last historical glucose as the time difference is greater than 35 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.General_T002_GlucoseGraph_HG_21mGap_Connect35m_Step12);
		navigateToScreen(client, "Logbook");
		clickOnNoteIcon(client,"Logbook");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		selectingSASMode(client,"DEFAULT");
		currentSystemTime(client);
	}

}
