package com.abbott.project37375iOS.remindersAndsensorinreactionsAndgeneral;

import com.abbott.project37375iOS.main.BaseHelper;
import com.experitest.client.Client;

public class SensorHelper extends BaseHelper {

	/**
	 * Author: ShabinaSherif (Completed)/NagarajuKasarla
	 * 
	 * verify Sensor Dialog Screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param errortitle
	 * 			send error title
	 * @param errormessage
	 * 	        send error message
	 */
	public void verifySensorDialogScreen(Client client,String errortitle,String errormessage) {
		client.verifyElementFound("NATIVE","text=${"+errortitle+"}", 0);
		client.verifyElementFound("NATIVE","text=${"+errormessage+"}", 0);
		clickOnButtonOption(client,"OK",false);
		}

	/**
	 * Author:NagarajuKasarla
	 * 
	 * verify HomePage With ScanData
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param lastScan
	 *           sending lastScan value
	 * @param average
	 *        	 sending average value
	 */
	public void verifyHomePageWithScanData(Client client, String lastScan,
			String average) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='LAST 24 HOURS']", 0, 10000);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='CHECK GLUCOSE']", 0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@text='"+average+" "+getUnits()+ "' and ./preceding-sibling::*[@accessibilityLabel='AVERAGE']]", 0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@text='"+lastScan+" "+getUnits()+ "' and ./preceding-sibling::*[@accessibilityLabel='LAST SCAN']]", 0);
	}

	/**
	 * Author: ShabinaSherif (Completed)
	 * 
	 * verify NOT ACTIVE Sensor Screen
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 */
	public void verifyNotActiveSensorScreen(Client client) {
		client.verifyElementFound("NATIVE",
				"text=${error_sensor_not_active_title}", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[contains(@text,'Starting a new Sensor will end the Sensor you are currently using.')]", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[contains(@text,'Would you like to start the new one now?')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='NO']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='YES']", 0);
	}

	/**
	 * Author: ShabinaSherif (Completed)
	 * 
	 * verify event log content
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation Error Title Error Description
	 * @param errTitle
	 *         verifying error Title
	 * @param errDesc
	 *  	   verifying error description
	 */
	public void verifyEventLogContent(Client client, String errTitle,
			String errDesc) {
		if(!client.isElementFound("NATIVE", "text=${" + errTitle + "}", 0)){
		client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.EventLogTableCell']]", "Down", 300,
				1000, "NATIVE", "text=${" + errTitle + "}", 0, 1000, 10, false);
		}
		client.verifyElementFound("NATIVE", "text=${" + errTitle + "}", 0);
		client.verifyElementFound("NATIVE", "text=${" + errDesc + "}", 0);

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * verify event log content
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation Error Title Error Description
	 * 
	 */
	public void eventlogScrollUp(Client client) {
		client.runNativeAPICall("NATIVE", "xpath=//*[@class='UITableView' and ./*[@class='LibreLink.EventLogTableCell']]", 0, "invokeMethod:'{\"selector\":\"pl_scrollToTop:\",\"arguments\":[\"true\"]}'");
    }


	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Screen NotFound
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param screen
	 * 			ScreenName
	 */
	public void verifyScreenNotFound(Client client,String screen) {
		client.verifyElementNotFound("NATIVE","accessibilityLabel="+screen, 0); 	
	}
	
	/**
	 * Author: NagarajuKasarla
	 * 
	 * Add And Verify Historical And RealtimeData
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void addAndVerifyHistoricalAndRealtimeData(Client client) {
		selectingSASMode(client, "MOCK_1");
		debugDrawerClearData(client);
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Historic","100",true,9,00);
		bgValueWithStaticTime(client,"Historic","120",true,9,15);
		bgValueWithStaticTime(client,"Realtime","130",false,0,0);
		scanMockSensor(client, null);
		clickBackFromMyGlucose(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHomePageWithScanData(client, "130", "110");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyHomePageWithScanData(client, "7.2", "6.2");
		}
	}
}
