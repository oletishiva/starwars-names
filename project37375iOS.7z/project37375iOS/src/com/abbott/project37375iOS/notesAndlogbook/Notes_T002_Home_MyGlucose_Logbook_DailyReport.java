package com.abbott.project37375iOS.notesAndlogbook;



import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;


public class Notes_T002_Home_MyGlucose_Logbook_DailyReport extends NoteHelper {
	
	@Test
	public void test_Notes_T002_Home_MyGlucose_Logbook_DailyReport() throws Exception {
		
		
		/**
		 * 
		 * @stepId Pre Condition
		 * @Reqt
		 * @Expected Change date and time to 9/11/2017 7:00AM AND Carb units to grams 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setTheDateAndTime(client,11,9,2017,"07:00");	
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		launch(client);
		setAndGetCarbUnit(client, "grams");
		navigateToScreen(client, "Home");
		String logbookDate = null;

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS893_SDAISRS219
		 * @Expected The Logbook screen provides a means to invoke the Note dialog to add a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step1);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);		
		if(getLanguage().equals("English (U.S.)")){
			addScanDataWithStaticDateAndTime(client, "Realtime", "100", "2017-06-15", true, 0, 0);	
		}else{
			addScanDataWithStaticDateAndTime(client, "Realtime", "100", "2017-06-15", true, 12, 0);
		}
		addScanDataWithStaticDateAndTime(client, "Realtime", "100", "2017-09-11", true, 7, 0);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		navigateToScreen(client, "Logbook");
		logbookDate = getCalendarDate(client);
		clickCreatedNote(client, "7:00 AM");
		clickAddNoteInMyGlucose(client);
		verifyPageTitles(client, "Add Note");
		verifyAddNotePageDateTime(client,logbookDate,"7:00 AM");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS879_SDAIUIRS893_SDAISRS219
		 * @Expected A note with 5 attributes on graph associated with glucose test result at 7AM displayed in Result Screen, Home Screen, Logbook list Screen and Logbook Detail Screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step2_1);
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "Add-logbook 5");
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		navigateToMyGlucosePage(client);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		verifyNotePopUpDetails(client, "Exercise");
		verifyNotePopUpDetails(client, "Food");
		verifyNotePopUpDetails(client, "Long-Acting Insulin");
		verifyNotePopUpDetails(client, "Rapid-Acting Insulin");
		verifyNotePopUpDetails(client, "Add-logbook 5");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step2_2);
		clickBackFromMyGlucose(client);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		verifyNotePopUpDetails(client, "Exercise");
		verifyNotePopUpDetails(client, "Food");
		verifyNotePopUpDetails(client, "Long-Acting Insulin");
		verifyNotePopUpDetails(client, "Rapid-Acting Insulin");
		verifyNotePopUpDetails(client, "Add-logbook 5");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step2_3);
		navigateToScreen(client, "Logbook");
		verifyLogbookListForGlucoseValues(client, "100", "TrendArrow_Straight", "7:00 AM", "green");
		String time = "7:00 AM";
		if(!getLanguage().equals("English (U.S.)")){
			time=time.toLowerCase();
		}
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'5') and @accessibilityIdentifier='LogbookNoteIcon' and ../parent::*[contains(@accessibilityLabel,'"+time+"')]]", 0);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step2_4);
		clickCreatedNote(client, "7:00 AM");
		verifyLogBookDetailPageNotesContent(client, "Food");
		verifyLogBookDetailPageNotesContent(client, "Exercise");
		verifyLogBookDetailPageNotesContent(client, "Long-Acting Insulin");
		verifyLogBookDetailPageNotesContent(client, "Rapid-Acting Insulin");
		verifyLogBookDetailPageNotesContent(client, "Add-logbook 5");
		capturescreenshot(client, getStepID()+"_Logbook Detail Screen", true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS895_SDAISRS219
		 * @Expected The Result screen provides a means to invoke the Note dialog to add a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step3);
		setTheTimeAlone(client, "8:35");
		openDebugDrawer(client);
	    addScanDataWithStaticDateAndTime(client, "Realtime", "200", "2017-09-11", true, 8,35);
		addScanDataWithStaticDateAndTime(client, "Historic", "69", "2017-09-11", true, 8, 30);
		scanMockSensor(client,null);
		clickAddNoteInMyGlucose(client);
		verifyPageTitles(client, "Add Note");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS895_SDAISRS219
		 * @Expected A note associated with glucose test result at 8:35AM displayed on graph
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step4);
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "Add-MyG 5");
		clickOnButtonOption(client, "DONE", true);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyGlucoseValueandUnitsMyGlucose(client,"200");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyGlucoseValueandUnitsMyGlucose(client,"11.1");
		}	
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1252_SDAISRS1188
		 * @Expected The Result screen provides a means to invoke the Note dialog to edit a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step5);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		 editNote(client, "7:00 AM");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1252_SDAISRS1188
		 * @Expected A note displayed from graph at 7:00AM with a badge indicating 2 notes and  Exercise attribute 1hour 1minute  is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step6_1);
		unSelectNoteAttribute(client, "Food");
		unSelectNoteAttribute(client, "Long-Acting Insulin");
		unSelectNoteAttribute(client, "Rapid-Acting Insulin");
		addNoteForExercise(client, null, 1, 1);
		clickOnButtonOption(client, "DONE", true);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step6_2);
		clickOnNotesorTimeZoneorBG(client, "notePointWithIndex", 0);
		verifyTimeInNotePopUp(client, "7:00 AM", true);
		verifyNotePopUpDetails(client, "Exercise (1 hour 1 minute)");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS895_SDAIUIRS1252_SDAISRS219_SDAISRS1188
		 * @Expected A note displayed from graph around 7 AM with a badge indicating 7 notes 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step7_1);
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step7_2);
		navigateToScreen(client, "Logbook");
		verifyLogbookListForGlucoseValues(client, "100", "TrendArrow_Straight", "7:00 AM", "green");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step7_3);
		clickCreatedNote(client, "7:00 AM");
		verifyExerciseIntensityInLogBookDetailPage(client, null, 1, 1);
		capturescreenshot(client, getStepID(), true);
	

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS850_SDAIUIRS896
		 * @Expected Note entry feature provides a means to set the date and time of a Note when adding it: Date September 11, 2017 and time 7:01AM displayed at top of the Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step8);
		clickOnBackIcon(client);
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-09-11"));
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "07.01");
		verifyAddNotePageDateTime(client,logbookDate,"7:01 AM");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS893_SDAISRS837_SDAISRS1189
		 * @Expected A note displayed from list at 7:01AM with a badge indicating 2 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step9);
		clickAndSetFoodAttribute(client, null, "400");
		addNoteForExercise(client, null, 12, 59);
		clickOnButtonOption(client, "DONE", true);
		verifyNotesInLogBookList(client,"7:01 AM","2");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS850_SDAIUIRS896
		 * @Expected Note entry feature provides a means to set the date and time of a Note when adding it:Date September 11, 2017 and time 8:34AM displayed at top of the Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step10);
		createNewNote(client, logbookDate, "08.34");
		verifyAddNotePageDateTime(client,logbookDate,"8:34 AM");
		capturescreenshot(client, getStepID(), true);
	
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS893_SDAISRS837_SDAISRS1189
		 * @Expected A note displayed at 8:34 AM with a badge indicating 3 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step11);
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		verifyNotesInLogBookList(client,"8:34 AM","3");
		capturescreenshot(client, getStepID(), true);
	
		
		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS850_SDAIUIRS896
		 * @Expected Note entry feature provides a means to set the date and time of a Note when adding it:Date June 15, 2017 and time 12:00AM displayed at top of the Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step12);
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-06-15"));
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "00.00");
		verifyAddNotePageDateTime(client,logbookDate,"12:00 AM");
		capturescreenshot(client, getStepID(), true);
	
		
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS893_SDAISRS837_SDAISRS1189
		 * @Expected A note  associated without glucose test result displayed at 12:00AM with a badge indicating 4 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step13);
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		clickOnButtonOption(client, "DONE", true);
		verifyNotesInLogBookList(client,"12:00 AM","4");	
		capturescreenshot(client, getStepID(), true);
	
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS850_SDAIUIRS896
		 * @Expected Note entry feature provides a means to set the date and time of a Note when adding it:Date June 14, 2017 and time 11:59 PM displayed at top of the Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step14);
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-06-14"));
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "23.59");
		verifyAddNotePageDateTime(client,logbookDate,"11:59 PM");
		capturescreenshot(client, getStepID(), true);
	
		
		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS893_SDAISRS837_SDAISRS1189
		 * @Expected A note displayed at 11:59PM.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step15);
		selectNoteAttribute(client, "Food");
		clickOnButtonOption(client, "DONE", true);
		verifyNotesInLogBookList(client,"11:59 PM","1");
		capturescreenshot(client, getStepID(), true);

		
		setTheTimeAlone(client, "12:00");
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		launch(client);
		setAndGetCarbUnit(client, "servings");
		navigateToScreen(client, "Home");
		
		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS850
		 * @Expected The Note entry feature  provides a means to display the date and time of a Note: September 11, 2017 12:00PM
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step16);
		openDebugDrawer(client);
		addScanDataWithStaticDateAndTime(client, "Historic", "501", "2017-09-11", true, 11, 25);
		addScanDataWithStaticDateAndTime(client, "Realtime", "300", "2017-09-11", true, 12, 0);
		scanMockSensor(client,null);
		clickAddNoteInMyGlucose(client);
		verifyAddNotePageDateTime(client,"11.09.2017","12:00 PM");
		capturescreenshot(client, getStepID(), true);
	
		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS850
		 * @Expected The Note entry feature  provides a means to display the date and time of a Note: September 11 2017 12:00PM
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step17);
		clickAndSetFoodAttribute(client, "Lunch", "10.5");
		addNoteForRapidActingInsulin(client, "10.1");
		clickOnButtonOption(client, "DONE", true);
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "Logbook");
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-09-11"));
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "3:00");
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		createNewNote(client, logbookDate, "10:00");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		addNoteForRapidActingInsulin(client, "199.9");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "12:00 PM");
		verifyNotePopUpDetails(client, "Lunch (10.5 svg)");
		verifyNotePopUpDetails(client, "Rapid-Acting Insulin (10.1 units)");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS871_SDAIUIRS891_SDAIUIRS1014_SDAIUIRS1125
		 * @Expected Notes around 3:00AM with a badge indicating 3 notes;Notes around 7:00AM with a badge indicating 4 notes ;Notes around 8:35AM with a badge indicating 8 notes;A note around 10:00AM ;Notes around 12:00PM with a badge indicating 2 notes dispalys in HomeScreen ,Logbook detail and Daily Graph report screen.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step18_1);
	    navigateToScreen(client, "Home");
	    capturescreenshot(client, getStepID(), true);
	    setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step18_2);
	    navigateToScreen(client,"Logbook");
	    clickCreatedNote(client, "12:00 PM");
	    capturescreenshot(client, getStepID(), true);
	    setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step18_3);
	    clickOnBackIcon(client);
	    navigateToScreen(client,"Daily Graph");
	    capturescreenshot(client, getStepID(), true);
	
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS910
		 * @Expected The Note dialog provides a means to delete an existing note and all of its attributes and Delete icon displayed on top of screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step19);
		 navigateToScreen(client, "Home");
		 clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",1);
		 editNote(client, "8:35 AM");
		capturescreenshot(client, getStepID(), true);
	

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS910
		 * @Expected Notes displayed at 8:34 AM with a badge indicating 7 notes and Note at 8:35AM� is not displayed on the pop-up
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step20_1);
		verifyAndClickTrashIcon(client,true);
	   clickOnButtonOption(client, "DELETE", true);
	   capturescreenshot(client, getStepID(), true);
	   setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step20_2);
	   clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",1);
	   verifyTimeInNotePopUp(client,"8:35 AM",false);
	   capturescreenshot(client, getStepID(), true);
	   clickOnButtonOption(client,"OK",true);
	
		
		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAIUIRS910
		 * @Expected The Note dialog provides a means to delete an existing note and all of its attributes and Delete icon displayed on top of screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step21_1);
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step21_2);
		 clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		 editNote(client, "7:00 AM");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS910
		 * @Expected Notes displayed at 7:01 AM� is not displayed on the popup.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step22);
		  clickOnButtonOption(client, "CANCEL", true);
		  clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		  editNote(client, "7:01 AM");
		  verifyAndClickTrashIcon(client,true);
		  clickOnButtonOption(client, "DELETE", true);
		 clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		 verifyTimeInNotePopUp(client,"7:01 AM",false);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);
		
		/**
		 * 
		 * @stepId Step 23
		 * @Reqt SDAIUIRS910
		 * @Expected The Note dialog provides a means to delete an existing note and all of its attributes and Delete icon displayed on top of screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step23);
		clickBackFromMyGlucose(client);
		 navigateToScreen(client, "Logbook");
		  clickCreatedNote(client, "3:00 AM");
		  editNote(client, "3:00 AM");
		  verifyAddNotePageDateTime(client,logbookDate,"3:00 AM");
		  verifyAndClickTrashIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 24
		 * @Reqt SDAIUIRS910
		 * @Expected Note at 3:00AM  is not displayed on the Logbook list
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step24);
		verifyAndClickTrashIcon(client,true);
		 clickOnButtonOption(client, "DELETE", true);
		 verifyElementNotFoundInLogbookList(client,"3:00 AM","3");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 25
		 * @Reqt SDAIUIRS1251
		 * @Expected The Home Screen provides a means to invoke the Note dialog to edit a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step25_1);
		navigateToScreen(client, "Home");
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		 editNote(client, "7:00 AM");
		 unSelectNoteAttribute(client, "Exercise");
		 scrollToBottomAddNotePage(client);
		 waitFor(client, 2);
		 enterNotesComments(client, "");
		addNoteForRapidActingInsulin(client, "10.9");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "DONE", true);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",0);
		editNote(client, "8:34 AM");
		unSelectNoteAttribute(client, "Food");
		unSelectNoteAttribute(client, "Long-Acting Insulin");
		unSelectNoteAttribute(client, "Rapid-Acting Insulin");
		unSelectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "");
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step25_2);
		addNoteForLongActingInsulin(client, "20.9");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "DONE", true);
		
		/**
		 * 
		 * @stepId Step 26
		 * @Reqt SDAIUIRS1252
		 * @Expected New Note created with both Insulin attribute 200 units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step26_1);
		navigateToMyGlucosePage(client);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",2);
		 editNote(client, "10:00 AM");
		unSelectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		clickOnButtonOption(client, "DONE", true);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",3);
		editNote(client, "12:00 PM");
		unSelectNoteAttribute(client, "Food");
		unSelectNoteAttribute(client, "Rapid-Acting Insulin");
		clickAndSetFoodAttribute(client, "Dinner", "10.5");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "DONE", true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step26_2);
		clickOnNotesorTimeZoneorBG(client,"notePointWithIndex",3);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);
		
		/**
		 * 
		 * @stepId Step 27
		 * @Reqt SDAIUIRS871_SDAIUIRS891_SDAIUIRS1014_SDAIUIRS1251_SDAIUIRS1252
		 * @Expected The graph indicates the approximate times when notes were recorded:At 07:00AM Rapid_Acting Insulin;At 08:34AM Long_Acting Insulin;At 10:00AM Exercise;At 12:00PM Food
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step27_1);
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step27_2);
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step27_3);
		navigateToScreen(client, "Logbook");
		clickCreatedNote(client, "12:00 PM");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step27_4);
		navigateToScreen(client, "Daily Graph");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 28
		 * @Reqt SDAIUIRS894
		 * @Expected The Logbook Detail View  provides a means to invoke the Note dialog to edit a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step28_1);
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "Logbook");
		clickCreatedNote(client, "7:00 AM");
		editNote(client, "7:00 AM");
		selectNoteAttribute(client, "Long-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step28_2);
		clickCreatedNote(client, "8:34 AM");
		editNote(client, "8:34 AM");
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "10:00 AM");
		editNote(client, "10:00 AM");
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "My Logbook3");
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "12:00 PM");
		editNote(client, "12:00 PM");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "My Logbook5");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "DONE", true);
		
		/**
		 * 
		 * @stepId Step 29
		 * @Reqt SDAIUIRS871_SDAIUIRS891_SDAIUIRS1014_SDAIUIRS894_SDAIUIRS1125
		 * @Expected The graph indicates the approximate times when notes were recorded:07:00AM note with a badge indicating 2 notes ;08:34AM note with a badge indicating 3 notes;10:00AM note with a badge indicating 4 notes;12:00PM note with a badge indicating 5 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step29_1);
		navigateToMyGlucosePage(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step29_2);
		clickBackFromMyGlucose(client);
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step29_3);
		navigateToScreen(client, "Logbook");
		clickCreatedNote(client, "12:00 PM");
		capturescreenshot(client, getStepID(), true);
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step29_4);
		clickOnBackIcon(client);
		navigateToScreen(client, "Daily Graph");
		capturescreenshot(client, getStepID(), true);
		
		

		/**
		 * 
		 * @stepId Step 30
		 * @Reqt SDAISRS219
		 * @Expected The software provides a means to add notes (RA insulin, LA insulin, carbohydrates, custom notes, exercise) associated with a glucose test result.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step30);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		setTheDateAndTime(client, 13, 9, 2017, "00:05");
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		bgValueWithStaticTime(client, "Historic", "69", true, 00, 00);
		bgValueWithStaticTime(client, "Realtime", "39", true, 00, 05);
		scanMockSensor(client,null);
		clickAddNoteInMyGlucose(client);
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "My Logbook6");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "DONE", true);
		
		/**
		 * 
		 * @stepId Step 31
		 * @Reqt SDAIUIRS837
		 * @Expected The software provides a means to add notes (RA insulin, LA insulin, carbohydrates, custom notes, exercise) that are not associated with a glucose test result.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step31);
		clickBackFromMyGlucose(client);
		navigateToScreen(client, "Logbook");
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-09-13"));
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "00.00");
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "My Logbook-5");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "DONE", true);
		
		/**
		 * 
		 * @stepId Step 32
		 * @Reqt SDAIUIRS891
		 * @Expected The Logbook glucose graph indicates the Notes around 00:00  with a badge indicating 10 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step32);
		clickCreatedNote(client, "00:00");
		//verify Graph Manually
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * 
		 * @stepId Step 33
		 * @Reqt SDAIUIRS891
		 * @Expected The Logbook glucose graph indicates the Notes around 00:00  with a badge indicating 7 notes 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step33);
		clickOnBackIcon(client);
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-09-12"));
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "23.55");
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Long-Acting Insulin");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		createNewNote(client, logbookDate, "23.59");
		selectNoteAttribute(client, "Food");
		selectNoteAttribute(client, "Rapid-Acting Insulin");
		selectNoteAttribute(client, "Exercise");
		scrollToBottomAddNotePage(client);
		waitFor(client, 2);
		enterNotesComments(client, "My Logbook-4");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "23:59");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 34
		 * @Reqt SDAIUIRS1014
		 * @Expected Daily graph displays the Note icon around 00:00  with a badge indicating 10 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step34);
		clickOnBackIcon(client);
		navigateToScreen(client, "Daily Graph");
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-09-13"));
		//verify Graph manually
		capturescreenshot(client, getStepID(), true);
	

		/**
		 * 
		 * @stepId Step 35
		 * @Reqt SDAIUIRS1014
		 * @Expected Daily graph displays the Note icon around 00:00  with a badge indicating 7 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step35);
		clickOnCalendarDate(client);
		pickDate(client,getDateFormat("2017-09-12"));
		waitFor(client, 2);
		//verify Graph manually
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 36
		 * @Reqt SDAIUIRS871_SDAIUIRS1125
		 * @Expected Home Screen glucose graph displays the Note icon around 00:00 with a badge indicating 17 notes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T002_Home_MyGlucose_Logbook_DailyReport_Step36);
		navigateToScreen(client, "Home");
		capturescreenshot(client, getStepID(), true);
		
		
		selectingSASMode(client,"DEFAULT");
		currentSystemTime(client);
				
	}
}
