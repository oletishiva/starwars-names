package com.abbott.project37375iOS.notesAndlogbook;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;




import org.junit.Assert;

import com.abbott.project37375iOS.main.BaseHelper;
import com.abbott.project37375iOS.main.LibrelinkConstants;
import com.experitest.client.Client;

public class NoteHelper extends BaseHelper {

	/**
	 * Author: ShabinaSherif
	 * 
	 * Method to verify Notes in Logbook list page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param time
	 *            time of note created
	 * @param attributesCnt
	 * 				no of attributes tagged to the note
	 */

	public void verifyNotesInLogBookList(Client client, String time, String attributesCnt){
		if(!getLanguage().equals("English (U.S.)")){
			time=time.toLowerCase();
		}
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'"+time+"')]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookTableCell' and contains(@accessibilityLabel,'"+getLangPropValue("note")+"')]", 0);	
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'"+attributesCnt+"') and @accessibilityIdentifier='LogbookNoteIcon' and ../parent::*[contains(@accessibilityLabel,'"+getLangPropValue("note")+", "+time+"')]]", 0);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method for Unselect Note Attribute
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 * @param attribute
	 *          set the Attribute
	 * 
	 */

	public void unSelectNoteAttribute(Client client, String attribute) {

		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
						+ attribute + "']]", 0);
		String option = client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='"
								+ attribute + "']]", 0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'");
		if (option.equalsIgnoreCase("1")) {
			client.click(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and @class='UIImageView' and ./preceding-sibling::*[@text='"
							+ attribute + "']]", 0, 1);
		}
		waitFor(client, 2);
		Assert.assertEquals("0", client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked' and ./preceding-sibling::*[@accessibilityLabel='"
								+ attribute + "']]", 0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'"));

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method for Select And Verify Note Attribute

	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param attribute
	 * 			sending attribute name
	 * 
	 * @param verify 
	 *            true or False
	 */

	public void selectAndVerifyNoteAttribute(Client client, String attribute,
			boolean verify) {
		selectNoteAttribute(client, attribute);
		if (verify) {
			if (attribute.equalsIgnoreCase("Food")) {

				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityLabel='Meal']", 0);
				client.verifyElementFound("NATIVE",
						"xpath=//*[contains(@text,'of carbs')]", 0);
				client.verifyElementFound("NATIVE",
						"xpath=//*[@accessibilityIdentifier='DownCaret']", 0);
			} else if (attribute.equalsIgnoreCase("Exercise")) {
				scrollToBottomAddNotePage(client);
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='Select Intensity']", 0);
				client.verifyElementFound("NATIVE", "xpath=//*[@text='0 hrs']",
						0);
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='0 mins']", 0);

			} else if (attribute.equalsIgnoreCase("Rapid-Acting Insulin")) {
				client.verifyIn(
						"NATIVE",
						"xpath=(//*[@class='UITableView' and ./parent::*[@class='UIView']]/*/*[@class='UITableViewCellContentView' and ./*[@text='Rapid-Acting Insulin']])",
						0, "Down", "NATIVE", "xpath=//*[@text='units']", 0, 0);

			} else if (attribute.equalsIgnoreCase("Long-Acting Insulin")) {
				client.verifyIn(
						"NATIVE",
						"xpath=(//*[@class='UITableView' and ./parent::*[@class='UIView']]/*/*[@class='UITableViewCellContentView' and ./*[@text='Long-Acting Insulin']])",
						0, "Down", "NATIVE", "xpath=//*[@text='units']", 0, 0);

			}

		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Food Attribute Content
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 * 
	 */

	public void verifyFoodAttributeContent(Client client) {
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='DownCaret' and @top='true' and ./preceding-sibling::*[(@text='Meal' or @text='Breakfast' or @text='Snack' or @text='Lunch' or @text='Dinner') ]]",
				0, 1);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Breakfast']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Lunch']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Dinner']", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='Snack']", 0);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify the Food Error
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param units
	 *        sending units(grams/servings(portions))
	 */
	public void verifyFoodError(Client client, String units) {
		if (units.equalsIgnoreCase("grams")) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Value should be a whole number between 0 and 400']",
					0);
		} else {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Value should be a multiple of 0.5 and between 0 and 40']",
					0);
		}
		client.verifyElementFound("NATIVE", "xpath=//*[@text='OK']", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify the Insulin Error
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *
	 */
	public void verifyInsulinError(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Value should be a multiple of 0.1 and between 0.1 and 200']",
				0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='OK']", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click OK On Insulin Error Pop-Up
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *
	 */
	public void clickErrorOk(Client client) {
		client.click("NATIVE", "xpath=//*[@text='OK']", 0, 1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Set and get the Carbohydrate units
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param carbUnit
	 *            set the carbUnits
	 */
	public void setAndGetCarbUnit(Client client, String carbUnit) {
		navigateToScreen(client, "Settings");
		client.waitForElement("NATIVE",
				"xpath=//*[@text='Carbohydrate Units']", 0, 10000);
		client.click("NATIVE", "xpath=//*[@text='Carbohydrate Units']", 0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='grams']", 0, 10000);

		if (carbUnit.equals("grams")) {
			client.click("NATIVE", "text=grams", 0, 1);
		} else {
			client.click("NATIVE", "text=${servings}", 0, 1);
		}
		client.click("NATIVE", "xpath=//*[@text='SAVE']", 0, 1);
		waitFor(client,1);
		if (getUnits().equals("mmol/L")
				&& carbUnit.equalsIgnoreCase("servings")) {
			client.verifyElementFound("NATIVE", "partial_text=portions", 0);
		} else {
			client.verifyElementFound("NATIVE", "partial_text=" + carbUnit, 0);
		}
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify No Food LogBook Detail Page
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param mealType
	 *            set the meal type
	 */
	public void verifyNoFoodInLogBookDetailPage(Client client, String mealType) {
		client.verifyElementNotFound("NATIVE", "xpath=//*[@text='" + mealType+ "]", 0);

	}

	
	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Required Date Is Displayed
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation 
	 *          
	 * @param currentDate
	 *            check current date
	 *            
	 * @param minusDays
	 *             add days for required date  
	 *                 
	 * @throws ParseException
	 * 			throws Parse Exception for date selection
	 */
	public void verifyRequiredDateIsDisplayed(Client client, Date currentDate,
			int minusDays) throws ParseException {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DATE, -minusDays);
		verifyPickedDateIsDisplayed(client, calendar.getTime());
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click On Calendar Right Button
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param count
	 *         click no of times as count
	 */
	public void clickCalanderRightButton(Client client, int count) {

		for (int click = 0; click < count; click++) {
			client.click(
					"NATIVE",
					"xpath=//*[@accessibilityLabel='NextButtonArrow' and @onScreen='true']",
					0, 1);
			client.sleep(1000);

		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Click On Calendar Left Button
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 * @param count
	 *        click no of times as count
	 */
	public void clickCalanderLeftButton(Client client, int count) {

		for (int click = 0; click < count; click++) {
			client.click(
					"NATIVE",
					"xpath=//*[@accessibilityLabel='PrevButtonArrow' and @onScreen='true']",
					0, 1);
			client.sleep(1000);

		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Insulin Note in LogBook Detail Page 
	 * 
	 * @param client
	 *           Itegrate SeeTestAutomation
	 * @param insulinType
	 *            set the insulin type
	 * @param insulinUnit
	 *            set the insulin Units
	 */

	public void verifyInsulinNotFound(Client client, String insulinType,
			String insulinUnit) {

		if (insulinUnit.equals("none")) {
			client.verifyElementNotFound("NATIVE", "xpath=//*[@text='"
					+ insulinType + "-Acting Insulin' and @top='true']", 0);
		} else {
			if ((insulinUnit.equals("1"))) {
				client.verifyElementNotFound("NATIVE", "xpath=//*[@text='"
						+ insulinType
						+ "-Acting Insulin (1 unit)' and @top='true']", 0);
			} else {
				client.verifyElementNotFound("NATIVE", "xpath=//*[@text='"
						+ insulinType + "-Acting Insulin (" + insulinUnit
						+ " units)' and @top='true']", 0);

			}
		}
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify AddNotePage Date and Time
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param datefromLogbook
	 *        set the date from logbook calendar
	 *        
	 * @param time
	 *        set the time
	 *        
	 * @throws ParseException 
	 * 			throws Parse Exception for date selection
	 */
	public void verifyAddNotePageDateTime(Client client, String datefromLogbook, String time) throws ParseException {
		if(!getLanguage().equals("English (U.S.)")){
			time=time.toLowerCase();
		}	
		client.verifyIn(
				"NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and @knownSuperClass='UILabel']",
				0, "Inside", "NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'" + time
				+ "')]", 0, 0);
		SimpleDateFormat deviceFormat = new SimpleDateFormat("dd.MM.yyyy");
		Date d = deviceFormat.parse(datefromLogbook);
		if (getLanguage().contains("U.S.")) {
			deviceFormat.applyPattern("EEE, MMM d");
		}else{
			deviceFormat.applyPattern("EEE d MMM");
		}
		String datenewFormat = deviceFormat.format(d);
		client.verifyIn(
				"NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and @knownSuperClass='UILabel']",
				0, "Inside", "NATIVE",
				"xpath=//*[contains(@accessibilityLabel,'" + datenewFormat
				+ "')]", 0, 0);

	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Exercise Content
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * 
	 */

	public void verifyExerciseContents(Client client) {
		selectNoteAttribute(client, "Exercise");
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='DownCaret' and @top='true' and ./preceding-sibling::*[contains(@text,'Intensity')]]",
				0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='Low Intensity' and @onScreen='true']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='Medium Intensity' and @onScreen='true']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='High Intensity' and @onScreen='true']", 0);

	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Edit Note details
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param time
	 *        click on note time
	 */
	public void editNote(Client client,String time) {
		if(!getLanguage().equals("English (U.S.)")){
			time=time.toLowerCase();
		}
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityIdentifier='EditIconLarger']", 0,
				10000);
		waitFor(client, 2);
		if(client.isElementFound("TEXT", time, 0)){
			try{
				client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Down", 0, 2000, "TEXT", time, 0, 1000, 3, false);
			}catch(Exception e){
				client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Up", 0, 2000, "NATIVE", "xpath=//*[@accessibilityIdentifier='ScrollUpIndicator' and @top='false']", 0, 1000, 5, false);
			}
		}
		if(!client.isElementFound("NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@accessibilityLabel='EditIconLarger' and ./preceding-sibling::*[@accessibilityLabel='"+time+"']]]", 0)){
			
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Down", 0, 2000, "NATIVE", "xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@accessibilityLabel='EditIconLarger' and ./preceding-sibling::*[@accessibilityLabel='"+time+"']]]", 0, 1000, 5, false);	          

		}client.click("NATIVE",
				"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@accessibilityLabel='EditIconLarger' and ./preceding-sibling::*[@accessibilityLabel='"+time+"']]]", 0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='TrashIcon']", 0, 10000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='TrashIcon']", 0);

	}



	/**
	 * Author: Amaresh
	 * 
	 *   Method to  Enter Notes Comments
	 *   
	 * @param client
	 *          Integrate SeeTestAutomation 
	 *           
	 * @param notesComments
	 *            set the comments
	 */
	public void enterNotesComments(Client client, String notesComments) {

		client.click("NATIVE",
				"xpath=//*[@class='_UITextContainerView' and @top='true']", 0, 1);
		waitFor(client, 1);
		client.elementSendText("NATIVE",
				"xpath=//*[@class='LibreLink.LLTextView']", 0, notesComments);
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='Done']", 0, 1);
		waitFor(client, 2);
	}

	/**
	 * Author: Amaresh
	 * 
	 *  Method to  Verify Notes Comments
	 *  
	 * @param client
	 *          Integrate SeeTestAutomation  
	 *          
	 * @param notesComments
	 *            verify the notes comments
	 */
	public void verifyNotesComments(Client client, String notesComments) {
		client.verifyElementFound("NATIVE",
				"text="+notesComments, 0);

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 *         Method to swipe the Notes content in Logbook detail page
	 *         
	 * @param client
	 *          Integrate SeeTestAutomation   
	 */
	public void swipetoSeeNotesContent(Client client) {
		client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Down", 0, 2000);
		waitFor(client,1);

	}



	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Exercise Intensity in LogBook Detail Page
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 *          
	 * @param intensity
	 *            set intensity

	 */
	public void verifyExerciseIntensityRemovedInLogBookDetailPage(Client client,
			String intensity) {

		client.verifyElementNotFound("NATIVE",
				"xpath=//*[@text='Exercise " + intensity
				+ " Intensity ']", 0);


	}	

	/**
	 * Author: Amaresh
	 * 
	 *  Method to Pick and verify the previous date in calendar 
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param currentDate
	 *            check current date
	 *            
	 *  @param count  
	 *          set count of previous days         
	 * @throws ParseException
	 * 			throws Parse Exception for date selection
	 */
	public void pickAndVerifyPreviousDateIsDisplayed(Client client,
			Date currentDate, int count) throws ParseException {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DATE, -count);
		pickDate(client, calendar.getTime());
		verifyPickedDateIsDisplayed(client, calendar.getTime());
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to  Click Blood Drop Icon
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void clickBloodDropIcon(Client client) {
		client.click("NATIVE",
				"xpath=//*[@accessibilityIdentifier='BGM_Drop_Plus' and @hidden='false']", 0, 1);
	}


	/**
	 * Author: Amaresh
	 * 
	 * Method to Open BGR Time Picker
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 *
	 */
	public void openBGRTimePicker(Client client) {
		if(!client.isElementFound("NATIVE", "xpath=//*[@class='LibreLink.BGRDateTimePickerCell' and @onScreen='true']", 0)){
			client.click("NATIVE", "text=Edit Time", 0, 1);
		} 
		waitFor(client, 1);
	}
	/**
	 * Author: Amaresh
	 * 
	 *   Method to Verify selected Blood Glucose Result time
	 *   
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 * @param date
	 *            select the date
	 * @param logBookHour
	 *            select the hour
	 *            
	 * @param logBookMin
	 *            select the min
	 *            
	 * @param logBookAmPm
	 *            select the am/pm
	 */
	public void verifyselectedBGRTime(Client client, String date, int logBookHour,
			int logBookMin, String logBookAmPm) {
		openBGRTimePicker(client);
		String hour, mins;
		int logBookHours;
		String time = date + " " + logBookHour + "." + logBookMin + "";
		if (logBookAmPm != null) {

			if (logBookAmPm.equalsIgnoreCase("PM")&&logBookHour!=12){
				logBookHours=12+logBookHour;
			}else if(logBookAmPm.equalsIgnoreCase("AM")&&logBookHour==12){
				logBookHours=0;
			}
			else{
				logBookHours=logBookHour;
			}
			time = date + " " + logBookHours + "." + logBookMin + "";
		}
		client.elementSetProperty("NATIVE", "xpath=//*[@class='UIDatePicker']",
				0, "datetime", time);
		if (logBookHour<=9){
			hour= "0"+String.valueOf(logBookHour);}
		else{
			hour= String.valueOf(logBookHour);
		}
		if (logBookMin<=9 ){
			mins="0"+String.valueOf(logBookMin);}
		else{
			mins=String.valueOf(logBookMin);
		}

		String settime = hour + ":" + mins + "";
		if (logBookAmPm != null) {
			settime = logBookHour + ":" + mins + " "+ logBookAmPm;
		}
		String appSetTime = client.elementGetText("NATIVE", "xpath=//*[@placeholder='Edit Time' and @top='true']", 0);
		Assert.assertEquals(settime, appSetTime);

	}


	/**
	 * Author: Amaresh
	 * 
	 *   Method to Set the blood glucose result in MGDL
	 *   
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *            select the value
	 */
	public void setBGR(Client client, String value) {
		client.verifyElementFound("NATIVE", "xpath=//*[@class='_UITextFieldContentView']", 0);
		client.elementSendText("NATIVE", "xpath=//*[@class='_UITextFieldContentView']", 0, value);
		client.closeKeyboard();
	}


	/**
	 * Author: Amaresh
	 * 
	 *  Method to Verify Logbook Blood Glucose Result
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param logBookTime
	 *            set the time
	 *            
	 * @param value
	 *        set the scan value
	 */
	public void verifyLogBookBGR(Client client, String value, String logBookTime) {
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']",
				0);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "text=" + getUnits(), 0, 0);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "xpath=//*[@text='" + logBookTime+ "']", 0, 0);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookNoteIcon']", 0, 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0x808080']", 0);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=LogbookNoteIcon", 0);
	}


	/**
	 * Author: Amaresh
	 * 
	 *  Method to Verify BG error
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 */
	public void verifyBGError(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Value should be a whole number between 20 and 500']",
				0);
	}

	/**
	 * Author: Amaresh
	 * 
	 *  Method to Verify number of Blood Glucose values
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 * @param value 
	 *        Set the value
	 *
	 * @param time  
	 *        Set the Time
	 *
	 *@param count 
	 *      set count
	 */
	public void verifyNoOfBGValue(Client client, String value, String time ,int count) {
		int BGcount = client.getElementCount("NATIVE", "xpath=//*[@accessibilityLabel='"+time+"' and @accessibilityIdentifier='LogbookTimeLabel' and ./following-sibling::*[@class='UIView' and ./child::*[@text='"+value+"']]]");

		Assert.assertEquals(count,BGcount);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Verify Logbook Page details
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *        
	 */

	public void verifyLogbookPageContents(Client client) {
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='CalendarIcon']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SensorIcon']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='SliderMenuIcon']" ,0);
		if (getCountryCode().equalsIgnoreCase("United States")) {
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='BGM_Drop_Plus' and @hidden='false']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='EditIconLarger']", 0);

		}
		else{
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='ADD NOTE']", 0);
		}
	}
	/**
	 * Author: Amaresh
	 * 
	 *  Method to  Verify LogBook from menu option
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *  @param click  
	 *          click if true(true/false)        
	 */
	public void verifyLogBookMenu(Client client, boolean click) {
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Logbook' and @textColor='0x1E88E5']",
				0);
		if(click)
			client.click(
					"NATIVE",
					"xpath=//*[@text='Logbook' and @textColor='0x1E88E5']",
					0, 1);
		waitFor(client, 1);
	}

	/**
	 * Author: Amaresh
	 * 
	 *   Method to Verify added Note
	 *   
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param time
	 *        verify added note by using created Time      
	 */
	public void verifyaddedNote(Client client, String time) {		
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='Note' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0);
		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='Note' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "xpath=//*[@text='" + time+ "']", 0, 0);

		client.verifyIn("NATIVE", "xpath=//*[@accessibilityLabel='Note' and @accessibilityIdentifier='LogbookGlucoseValueLabel']", 0, "Right", "NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookNoteIcon']", 0, 0);
		client.verifyElementFound("NATIVE", "accessibilityIdentifier=LogbookNoteIcon", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0x808080']", 0);
	}
	/**
	 * Author: Amaresh
	 * 
	 *   Method to  Verify LogBook is Empty
	 *   
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 */
	public void verifyLogBookEmpty(Client client) {
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='No entries exist for this date.']", 0);
	}

	/**
	 * Author: Amaresh
	 * 
	 *  Method to Verify number of Scan results
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 *@param count 
	 *        set count of scan results
	 */
	public void verifyNoOfScanResult(Client client, int count) {
		int scancount = client.getElementCount("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookGlucoseValueLabel']");
		Assert.assertEquals(count,scancount);
	}

	/**
	 * Author: ShabinaSherif
	 * 
	 *  Method to Verify Glucose details in Logbook Details page
	 *  
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *        set the value
	 *        
	 * @param trend
	 *          set the trend 
	 *            
	 * @param datefromLogbook
	 *          set the datefromLogbook 
	 *          
	 * @param time
	 *         set the time 
	 *         
	 * @param color
	 *          set the color 
	 *          
	 * @throws ParseException 
	 * 			Throws parse exception on setting date
	 * 		
	 */
	public void verifyLogbookDetail(Client client, String value, String trend, String datefromLogbook, String time, String color) throws ParseException {
		client.verifyElementFound("NATIVE", "text=Logbook Detail", 0);
		value=value.replace(" ", "");
		if (!(value.equals("HI") || value.equals("LO"))) {

			if(getUnits().contains("mg")){
				client.verifyElementFound("NATIVE", "text="+value, 0);
			}else{
				float newValue = Float.parseFloat(value);
				newValue=(newValue/18);
				DecimalFormat df = new DecimalFormat("#.#");
				double value1=Double.parseDouble(df.format(newValue));
				client.verifyElementFound("NATIVE", "text="+value1, 0);
			}
		}else{
			client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"+value+"')]", 0);
		}
		if(trend!=null){
			client.verifyElementFound("NATIVE", "accessibilityLabel="+trend, 0);
		}
		client.verifyElementFound("NATIVE", "accessibilityLabel="+time, 0);
		client.verifyElementFound("NATIVE", "text="+getUnits(), 0);	
		SimpleDateFormat deviceFormat = new SimpleDateFormat("dd.MM.yyyy");
		Date d = deviceFormat.parse(datefromLogbook);
		if (getLanguage().contains("U.S.")) {
			deviceFormat.applyPattern("EEE, MMM d");
		}else{
			deviceFormat.applyPattern("EEE d MMM");
		}
		String datenewFormat = deviceFormat.format(d);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'"+datenewFormat +"')]", 0);
		verifyColor(client,color,time,"logbookdetail");

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 *  Method to Verify Glucose details in Logbook List
	 *  
	 *@param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *        set the value
	 *        
	 * @param trend
	 *          set the trend   
	 *          
	 * @param time
	 *         set the time 
	 *         
	 * @param color
	 *          set the color 
	 *          
	 * @throws ParseException 
	 * 		Throws parse exception on setting date
	 */
	public void verifyLogbookListForGlucoseValues(Client client, String value, String trend, String time, String color) throws ParseException {
		client.verifyElementFound("NATIVE", "text=Logbook", 0);
		if(getLanguage().equals("English (U.K.)")){
			time=time.toLowerCase();
		}
		System.out.println("=getTimeZoneValue(LibrelinkConstants.US)="+getTimeZoneValue(LibrelinkConstants.US));

		if(!client.isElementFound("NATIVE", "text="+time, 0)){
			client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "down", 0, 500);
			System.out.println("==trend="+time);
		}
		if(trend!=null){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+trend+"' and ./parent::*[@class='UIView' and ./preceding-sibling::*[@text='"+time+"']]]", 0);
		}
		if(!(value.equalsIgnoreCase("LO")||value.equalsIgnoreCase("HI"))){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+getUnits()+"' and ./parent::*[@class='UIView' and ./preceding-sibling::*[@text='"+time+"']]]", 0);
			if(getUnits().contains("mg")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and ./parent::*[@class='UIView' and ./preceding-sibling::*[@text='"+time+"']]]", 0);
			}else{
				float newValue = Float.parseFloat(value);
				newValue=(newValue/18);
				DecimalFormat df = new DecimalFormat("#.#");
				double value1=Double.parseDouble(df.format(newValue));
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value1+"' and ./parent::*[@class='UIView' and ./preceding-sibling::*[@text='"+time+"']]]", 0);
			}
		}else{
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"' and ./parent::*[@class='UIView' and ./preceding-sibling::*[@text='"+time+"']]]", 0);
		}
		if(trend!=null){
			verifyColor(client,color,time,"logbooklist");
		}
	}	


	public void verifyColor(Client client, String colorCode, String time, String pageName){
		if(pageName.contains("list")){
			if(colorCode.contains("orange")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0xEF6C00' and ./following-sibling::*[@text='"+time+"']]", 0);
			}else if(colorCode.contains("green")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0x8FCB3A' and ./following-sibling::*[@text='"+time+"']]", 0);
			}else if(colorCode.contains("yellow")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0xFFBC00' and ./following-sibling::*[@text='"+time+"']]", 0);
			}else if(colorCode.contains("red")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='TabColor' and @backgroundColor='0xED1C24' and ./following-sibling::*[@text='"+time+"']]", 0);
			}
		}else{
			if(colorCode.contains("orange")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookDetailBannerView' and @backgroundColor='0xEF6C00' and ./child::*[@text='"+time+"']]", 0);
			}else if(colorCode.contains("green")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookDetailBannerView' and @backgroundColor='0x8FCB3A' and ./child::*[@text='"+time+"']]", 0);
			}else if(colorCode.contains("yellow")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookDetailBannerView' and @backgroundColor='0xFFBC00' and ./child::*[@text='"+time+"']]", 0);
			}else if(colorCode.contains("red")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='LogbookDetailBannerView' and @backgroundColor='0xED1C24' and ./child::*[@text='"+time+"']]", 0);
			}
		}
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify added scan notes
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param value
	 *            set the value
	 */
	public void verifyAddedScanOrNote(Client client, String value) {
		if(!(value.equalsIgnoreCase("LO")||value.equalsIgnoreCase("HI")||value.contains("Note"))){
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+getUnits()+"']", 0);
			if(getUnits().contains("mg")){
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"']", 0);
			}else {
				float newValue = Float.parseFloat(value);
				newValue=(newValue/18);
				System.out.println("====="+newValue);
				DecimalFormat df = new DecimalFormat("#.#");
				double value1=Double.parseDouble(df.format(newValue));
				System.out.println("====="+value1);
				client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value1+"']", 0);
			}
		}else{
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='"+value+"']", 0);
		}
	}

	/**
	 * Author: Lourde Noel Rini
	 *
	 * Method to Click calendar cancel button
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 */
	public void clickCalendarCancelButton(Client client) {
		client.click(
				"NATIVE",
				"xpath=//*[@text='Cancel' and @class='UIButtonLabel' and @onScreen='true']",
				0, 1);
		waitFor(client, 1);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Pick and verify the previous date in calendar 
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param currentDate
	 *            check current date
	 *            
	 * @param count
	 *        number of days(count)  
	 *                 
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 */
	public void verifyRequiredPreviousDateIsDisplayed(Client client,
			Date currentDate, int count) throws ParseException {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DATE, -count);
		verifyDate(client, calendar.getTime());
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Date
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 * @param date
	 *            check current date
	 *            
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 */
	public void verifyDate(Client client, Date date) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy");

		String monthTitle = dateFormat.format(date);
		System.out.println("monthTitle" + monthTitle);

		String appCalendarDate = client
				.elementGetText(
						"NATIVE",
						"xpath=//*[@class='LibreLink.RegularLabel' and @textColor='0xFFFFFF' and @onScreen='true']",
						0);
		DateFormat appFormat;
		String direction = "up";
		if (!getLanguage().contains("U.K.")) {
			appFormat = new SimpleDateFormat("MMMMM d, yyyy");

			if (appFormat.parse(appCalendarDate).before(date)) {

				direction = "down";
			}
		} else {
			appFormat = new SimpleDateFormat("d MMMMM yyyy");

			if (appFormat.parse(appCalendarDate).before(date)) {

				direction = "down";
			}
		}
		if (!client
				.isElementFound(
						"NATIVE",
						"xpath=//*[@text='"
								+ monthTitle
								+ "' and @class='LibreLink.BoldLabel' and @onScreen='true']",
								0)) {
			client.elementSwipeWhileNotFound(
					"NATIVE",
					"xpath=//*[@class='UICollectionView']",
					direction,
					300,
					1000,
					"NATIVE",
					"xpath=//*[@text='"
							+ monthTitle
							+ "' and @class='LibreLink.BoldLabel' and @onScreen='true']",
							0, 0, 25, false);
		}
		client.sleep(500);
		int titlePosition = getTextPosition(client, monthTitle, 0);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		calendar.add(Calendar.DATE, -1);		
		int oneDayBefore = calendar.get(Calendar.DATE);
		int dateCount = 0;
		if (client.isElementFound("NATIVE", "xpath=//*[@text='" + dayOfMonth
				+ "']")) {
			dateCount = client.getElementCount("NATIVE", "xpath=//*[@text='"
					+ dayOfMonth + "']");
		}
		for (int eleIndex = 0; eleIndex < dateCount; eleIndex++) {
			if (getTextPosition(client, String.valueOf(dayOfMonth), eleIndex) > titlePosition) {

				if (client.isElementFound("NATIVE", "xpath=//*[@text='"
						+ dayOfMonth + "' and @textColor='0x138BE8']", 0)) {

					client.verifyElementFound("NATIVE", "xpath=//*[@text='"
							+ dayOfMonth + "' and @textColor='0x138BE8']",
							eleIndex);
				} else {
					client.verifyElementFound("NATIVE", "xpath=//*[@text='"
							+ dayOfMonth + "' and @textColor='0x000000']",
							eleIndex);
				}
				client.verifyElementFound("NATIVE", "xpath=//*[@text='"
						+ oneDayBefore + "' and @textColor='0xAAAAAA']",
						0);
				break;
			}
		}
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Get the Y axis position of selected day
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param text
	 *            select text
	 *            
	 * @param index
	 *            set the Index
	 *  @return x
	 *  	return the text position
	 */
	public int getTextPosition(Client client, String text, int index) {
		int y = -1;
		try {
			if (client.isElementFound("NATIVE", "xpath=//*[@text='" + text
					+ "']")) {
				y = Integer.valueOf(client.elementGetProperty("NATIVE",
						"xpath=//*[@text='" + text + "']", index, "y"));
			}
		} catch (NumberFormatException nfe) {

		}
		return y;
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Date and Time in Logbook Detail page
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param date
	 *            Check the date
	 *            
	 * @param scantime
	 *        check the Scantime
	 */
	public void verifyLogbookDetailDateTime(Client client, String scantime,
			String date) {
		client.waitForElement("NATIVE", "text=Logbook Detail", 0, 10000);
		client.verifyElementFound("NATIVE", "text=" + scantime, 0);
		client.verifyElementFound("NATIVE", "text=" + date, 0);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Required Date Is Displayed
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param currentDate
	 *            check current date
	 *            
	 *  @param count 
	 *         set the count of days  
	 *                
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 */
	public void VerifyRequiredDateIsDisplayed(Client client, Date currentDate,
			int count) throws ParseException {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DATE, -count);
		verifyPickedDateIsDisplayed(client, calendar.getTime());
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify the Leap year
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *
	 * @param year
	 *        set the year
	 *        
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 */
	public void verifyLeapYear(Client client, int year) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM yyyy");
		Calendar calendar = new GregorianCalendar();
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, Calendar.APRIL);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.add(Calendar.DATE, -32);
		String monthTitle = dateFormat.format(calendar.getTime());
		String direction = "up";
		client.elementSwipeWhileNotFound("NATIVE",
				"xpath=//*[@class='UICollectionView']", direction, 300, 400,
				"TEXT", monthTitle, 0, 100, 100, true);
		int titlePosition = getTextPosition(client, monthTitle, 0);
		calendar.setTime(calendar.getTime());
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		int dateCount = 0;

		if ((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0)))
			System.out.println("Year " + year + " is a leap year");

		else {
			System.out.println("Year " + year + " is a not leap year");
		}
		if (client.isElementFound("NATIVE", "xpath=//*[@text='" + dayOfMonth
				+ "']")) {
			dateCount = client.getElementCount("NATIVE", "xpath=//*[@text='"
					+ dayOfMonth + "']");
		}
		for (int eleIndex = 0; eleIndex < dateCount; eleIndex++) {
			if (getTextPosition(client, String.valueOf(dayOfMonth), eleIndex) > titlePosition) {
				client.verifyElementFound("NATIVE", "xpath=//*[@text='"
						+ dayOfMonth + "' and @textColor='0x138BE8']", eleIndex);

				break;
			}
		}
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify LogBook displays current date 
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 *            
	 * @param systemDateTime
	 *         set systemDateTime
	 * @throws ParseException
	 * 		Throws parse exception on setting date
	 */
	public void verifyLogBookDisplaysStaticDate(Client client,
			String systemDateTime) throws ParseException {

		String appDate = client.elementGetText("NATIVE",
				"xpath=//*[@class='UILabel' and @textColor='0xFFFFFF']", 0);
		Assert.assertEquals(appDate, systemDateTime);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Calendar Date Difference
	 * 
	 * @param client
	 *            verify Leap Date Is Displayed
	 *            
	 * @param year
	 *            check date
	 *            
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 */
	public void verifyCalenderDateDifference(Client client, int year)
			throws ParseException {
		Calendar calendar = new GregorianCalendar();
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, Calendar.APRIL);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.add(Calendar.DATE, -89);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='1' and @textColor='0xFFFFFF']", 0);
		verifyDate(client, calendar.getTime());

	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Verify Data With Bold Letters
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void verifyDataWithBoldLetters(Client client) {
		client.elementSwipeWhileNotFound(
				"NATIVE",
				"xpath=//*[@class='UICollectionView']",
				"Down",
				300,
				400,
				"NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and @textColor='0xFFFFFF' and @backgroundColor='0x000000']",
				0, 100, 100, false);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@class='LibreLink.RegularLabel' and @textColor='0xFFFFFF' and @backgroundColor='0x000000']",
				0);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Click And Verify Glucose Graph
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param glucoseValue
	 *        set glucoseValue
	 */
	public void clickAndVerifyGlucoseGraph(Client client, String glucoseValue) {
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='" + glucoseValue
				+ "' and @accessibilityIdentifier='LogbookGlucoseValueLabel']",
				0, 1);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='LogbookDetailTrendArrow']",
				0);
		client.waitForElement("NATIVE", "text=Logbook Detail", 0, 10000);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='"
						+ glucoseValue
						+ "' and @accessibilityIdentifier='LogbookDetailGlucoseValueLabel']",
						0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='LibreLink.LLLineChartView']", 0);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Method to Select Date Without Bold Letter
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param date
	 *        set the date
	 */
	public void selectDateWithoutBoldLetter(Client client, String date) {
		client.click("NATIVE", "xpath=//*[@text='" + date
				+ "' and @textColor='0x000000']", 0, 1);
	}

	/**
	 * Author: Amaresh
	 * 
	 * Method to Add static Scan Data and time for real or Historic with Static time
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 *         
	 * @param type 
	 *        set the type(Historic/Realtime)
	 *        
	 * @param minutes
	 *            Select minutes
	 *            
	 * @param date           
	 *         set the date
	 *         
	 * @param value
	 *            set the value
	 *            
	 * @param hours
	 *            Select Hour
	 *            
	 * @param isTimeReqd
	 *         true/false
	 * 
	 * */

	public void addScanDataWithStaticDateAndTime(Client client, String type, String value,String date, boolean isTimeReqd, 
			int hours, int minutes) {
		clickAddSensorDataMethod(client);
		client.click("NATIVE", "text=" + type, 0, 1);
		enterBGValue(client, value);
		if(isTimeReqd){
			try {
				enterStaticTime(client, hours, minutes);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(date!=null){
			enterStaticDate(client,date);
		}
		clickAddScannedValue(client);
	}


	public void enterStaticDate(Client client,String scandate) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Calendar cal = Calendar.getInstance();
		String scanDate = client.elementGetText("NATIVE",
				"xpath=//*[@class='UIButtonLabel' and contains(@text,'-')]", 0);
		String[] date = scandate.split("-");
		int a = Integer.parseInt(date[0]);
		int b = Integer.parseInt(date[1]);
		int c = Integer.parseInt(date[2]);
		cal.set(Calendar.YEAR, a);
		cal.set(Calendar.MONTH, b-1);
		cal.set(Calendar.DATE, c);
		String dateTime = dateFormat.format(cal.getTime());
		String inputActivationDate = dateTime.replace("/", "-");
		String Date = inputActivationDate.substring(0, 10);
		String time = inputActivationDate.substring(11, 16);
		System.out.println(Date);
		String inputDate[] = Date.split("-");
		System.out.println(time);
		if(!scanDate.contains(scandate)){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='"+scanDate+"' and @class='UIButton']", 0, 1);
			client.waitForElement("NATIVE", "text=Select Scan Date:", 0, 5000);
			client.elementSetProperty("NATIVE",
					"xpath=//*[@class='UIDatePicker' and @hidden='false']", 0,
					"date", inputDate[2] + "." + inputDate[1] + "." + inputDate[0]);
			waitFor(client, 2);
			client.click("NATIVE", "accessibilityLabel=OK", 0, 1);
			client.verifyElementFound("NATIVE", "text="+Date, 0);

		}
	}


	/**
	 * Author: NagarajuKasar
	 * 
	 * Method to Verify TrashIcon
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation 
	 * @param click
	 * 			true/false
	 */

	public void verifyAndClickTrashIcon(Client client,boolean click) {
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Edit Note']", 0, 5000);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='TrashIcon']", 0);
		waitFor(client, 1);
		if(click){
			client.click("NATIVE", "xpath=//*[@accessibilityLabel='TrashIcon']", 0, 1);	
		}
	}	

	/**
	 * Author: NagarajuKasar
	 * 
	 * Method to verify Note Not Found in Logbook list
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation 
	 * @param time 
	 *        Set the time for verification
	 * @param attributesCnt
	 *        Set the Attribute count for verification        
	 */

	public void verifyElementNotFoundInLogbookList(Client client,String time, String attributesCnt) {
		if(!getLanguage().equals("English (U.S.)")){
			System.out.println("=====");
			time=time.toLowerCase();
		}
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityLabel='Logbook']", 0, 5000);
		client.verifyElementNotFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'"+attributesCnt+"') and @accessibilityIdentifier='LogbookNoteIcon' and ../parent::*[contains(@accessibilityLabel,'"+getLangPropValue("note")+", "+time+"')]]", 0);
	}	

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * attributesCnt Get the Calendar Date For LogbookDetail
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @throws ParseException
	 * 			Throws parse exception on setting date
	 * @return date	
	 * 			Returns formatted date as String
	 * 
	 */
	public String getCalendarDateForLogbookDetail(Client client) throws ParseException {
		String datefromLogbook = client.elementGetText("NATIVE",
				"xpath=//*[@class='UILabel' and @textColor='0xFFFFFF']", 0);
		DateFormat deviceFormat, appDateFormat = null;
		Date deviceDate = null;
		if (!getCountryCode().contains("United Kingdom")) {
			deviceFormat = new SimpleDateFormat("MMMM dd, yyyy");
			deviceDate = deviceFormat.parse(datefromLogbook);
			appDateFormat = new SimpleDateFormat("E, MMM d");

		} else {
			deviceFormat = new SimpleDateFormat("d MMMMM yyyy");
			deviceDate = deviceFormat.parse(datefromLogbook);
			appDateFormat = new SimpleDateFormat("E d MMM");
		}
		return appDateFormat.format(deviceDate);

	}

}
