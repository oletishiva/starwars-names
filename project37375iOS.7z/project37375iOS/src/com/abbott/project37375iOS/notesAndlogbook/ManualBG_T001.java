package com.abbott.project37375iOS.notesAndlogbook;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class ManualBG_T001 extends NoteHelper {

	@Test
	public void test_T001_AddManualBGResult() throws Exception {
		String date=null;
		
		/**
		 * 
		 * @stepId Pre-Condition
		 * @Reqt 
		 * @Expected  LibreLink application is installed successfully. 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		changeTimeZone(client, getDefaultTimeZone());
		setTheDateAndTime(client, 14, 9, 2017, null);
		loadTestData(client, "MOCK_2", "ADC", "1dayLow2High.json");
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS908
		 * @Expected  The Manual BG Page is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step1);
		navigateToScreen(client, "Logbook");
		date=getCalendarDate(client);
		clickBloodDropIcon(client);
		verifyPageTitles(client, "Blood Glucose Result");
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1182_SDAIUIRS909_SDAIUIRS259
		 * @Expected  A manual BG '20' mg/dL on 9/14/2017 at 00:00 displayed on Logbook Page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step2);
		setBGR(client, "20");
		verifyselectedBGRTime(client, date ,00, 00, null);
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);
		verifyLogBookBGR(client, "20", "00:00");
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1182_SDAIUIRS909_SDAIUIRS259
		 * @Expected  A manual BG '500' mg/dL displayed on top of the list on 9/13/2017 at 23:59 on Logbook Page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step3);
		clickCalanderLeftButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		date=getCalendarDate(client);
		clickBloodDropIcon(client);
		setBGR(client, "500");
		openBGRTimePicker(client);
		verifyselectedBGRTime(client, date,23, 59, null);
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		verifyLogBookBGR(client, "500", "23:59");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1182_SDAIUIRS909_SDAIUIRS259
		 * @Expected  A manual BG '499' mg/dL displayed on 9/13/2017 at 21:30
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step4);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickBloodDropIcon(client);
		setBGR(client, "499");
		openBGRTimePicker(client);
		verifyselectedBGRTime(client, date, 21, 30, null);
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		verifyLogBookBGR(client, "499", "21:30");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Pre-Condition
		 * @Reqt 
		 * @Expected  LibreLink application is installed successfully. 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
        launch(client);
        navigateToScreen(client, "Logbook");

		
		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1219_SDAIUIRS1220
		 * @Expected  The Logbook distinguishes manually entered blood glucose values for 500,499,21 mg/dL from scan results
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step5);
		clickCalanderLeftButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		date=getCalendarDate(client);
		clickBloodDropIcon(client);
		setBGR(client, "21");
		openBGRTimePicker(client);
		verifyselectedBGRTime(client, date, 9, 31, "PM");
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		verifyLogBookBGR(client, "21", "9:31 PM");
		verifyLogBookBGR(client, "499", "9:30 PM");
		verifyLogBookBGR(client, "500", "11:59 PM");
		capturescreenshot(client, getStepID(), true);
		
		
		
		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1182_SDAIUIRS909_SDAIUIRS259
		 * @Expected A manual BG '50' mg/dL displayed on top of the list on 6/17/2017 at 12:00AM
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step6);
		clickCalendar(client);
		pickAndVerifyPreviousDateIsDisplayed(client, getDeviceDate(client), 89);
		date=getCalendarDate(client);
		clickBloodDropIcon(client);
		setBGR(client, "50");
		openBGRTimePicker(client);
		verifyselectedBGRTime(client, date, 12, 00, "AM");
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 89);
		verifyLogBookBGR(client, "50", "12:00 AM");
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1182_SDAIUIRS909_SDAIUIRS259
		 * @Expected  2 manual BG '50' mg/dL displayed from list on 6/17/2017 both at 12:00AM
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step7);
		clickBloodDropIcon(client);
		setBGR(client, "50");
		openBGRTimePicker(client);
		verifyselectedBGRTime(client, date, 12, 00, "AM");
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 89);
		verifyLogBookBGR(client, "50", "12:00 AM");
		verifyNoOfBGValue(client, "50","12:00 AM", 2);
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1219
		 * @Expected  1 manual BG '50' mg/dL displayed on the list on 6/17/2017 at 12:00PM  PDT or PST; 2 manual BG '50' mg/dL displayed on the list on 6/17/2017 at 12:00AM PDT or PST
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step8);
		clickBloodDropIcon(client);
		setBGR(client, "50");
		openBGRTimePicker(client);
		verifyselectedBGRTime(client, date, 12, 00, "PM");
		clickOnButtonOption(client, "DONE", true);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 89);
		verifyLogBookBGR(client, "50", "12:00 PM");
		verifyNoOfBGValue(client, "50","12:00 AM", 2);
		verifyNoOfBGValue(client, "50","12:00 PM", 1);
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1188
		 * @Expected A error message 'Value should be a whole number between 20 and 500' is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step9);
		clickBloodDropIcon(client);
		setBGR(client, "19");
		clickOnButtonOption(client, "DONE", true);
		verifyBGError(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);
		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1188
		 * @Expected A error message 'Value should be a whole number between 20 and 500' is displayed 
		 * 
		 **/
		setStepID(LibrelinkConstants.ManualBG_T001_Step10);
		setBGR(client, "501");
		clickOnButtonOption(client, "DONE", true);
		verifyBGError(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

	
		debugDrawerClearData(client);
		selectingSASMode(client, "DEFAULT");
		currentSystemTime(client);
        
	}
}
		

	


	
	

