package com.abbott.project37375iOS.notesAndlogbook;

import org.junit.Test;
import com.abbott.project37375iOS.main.LibrelinkConstants;


public class Notes_T001_Adding_Remove_attributes extends NoteHelper {
	String logbookDate = null;
	
	@Test
	public void test_T001_Adding_Remove_attribute() throws Exception {
		

		/**
		 * 
		 * @stepId Pre Condition
		 * @Reqt
		 * @Expected Package Name need to be updated as per build and set the
		 *           time to current time
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setAndGetCarbUnit(client, "grams");
		loadTestData(client, "MOCK_2", "ADC",  "1dayLow2High.json");

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS893
		 * @Expected Add Note Page is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step1);
		navigateToScreen(client, "Logbook");
		logbookDate = getCalendarDate(client);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);
		createNewNote(client, logbookDate, "00.30");
		verifyPageTitles(client, "Add Note");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS850
		 * @Expected The Note entry displayed the date and time of a Note
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		
		
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step2);
		verifyAddNotePageDateTime(client,logbookDate,"00:30");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS897
		 * @Expected Verify The Note dialog provides a means to add the Food attribute
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step3);
		selectAndVerifyNoteAttribute(client, "Food", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS898
		 * @Expected Breakfast, Lunch, Dinner or Snack options are displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step4);
		verifyFoodAttributeContent(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected Verify Carb amount 400 grams is set for Breakfast
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step5);
		clickAndSetFoodAttribute(client, "Breakfast", "400");
		verifyFoodEntry(client, "Breakfast", "grams", "400");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS904
		 * @Expected The Note entry provides a means to add the Exercise
		 *           attribute of a note is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step6);
		selectAndVerifyNoteAttribute(client, "Exercise", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS905
		 * @Expected Low, Medium , High Intensity are displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step7);
		verifyExerciseContents(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS905 SDAIUIRS906
		 * @Expected New Note created with exercise attribute Low intensity with
		 *           no duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step8);
		addNoteForExercise(client, "Low Intensity", 0, 0);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "00:30");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "grams", "400");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 0, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected Verify Carb amount 400 grams is set for Lunch .
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step9);
		createNewNote(client, getCalendarDate(client), "02.00");
		clickAndSetFoodAttribute(client, "Lunch", "400");
		verifyFoodEntry(client, "Lunch", "grams", "400");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS905 SDAIUIRS906
		 * @Expected New Note created with exercise attribute Medium intensity																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																														ity
		 *           with no duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step10);
		addNoteForExercise(client, "Medium Intensity", 0, 0);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "02:00");
		verifyFoodInLogBookDetailPage(client, "Lunch", "grams", "400");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 0, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected Verify Carb amount 400 grams is set for Dinner
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step11);
		createNewNote(client, getCalendarDate(client), "3.30");
		clickAndSetFoodAttribute(client, "Dinner", "400");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "03:30");
		verifyFoodInLogBookDetailPage(client, "Dinner", "grams", "400");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS905 SDAIUIRS906
		 * @Expected The Note edited with exercise attribute High intensity with
		 *           no duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step12);
		clickCreatedNote(client, "03:30");
		editNote(client,"03:30");
		addNoteForExercise(client, "High Intensity", 0, 0);
		clickOnButtonOption(client, "DONE", true);
		verifyFoodInLogBookDetailPage(client, "Dinner", "grams", "400");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 0, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1134
		 * @Expected The Note can't created with food attribute 100.5 or
		 *           401grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step13_1);
		createNewNote(client, getCalendarDate(client), "5.00");
		clickAndSetFoodAttribute(client, "Snack", "401");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step13_2);
		clickAndSetFoodAttribute(client, "Snack", "100.5");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		clickOnButtonOption(client, "CANCEL", true);
		waitFor(client, 2);
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected New Note created with food attribute Snack 400 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step14);
		createNewNote(client, getCalendarDate(client), "5.00");
		clickAndSetFoodAttribute(client, "Snack", "400");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "05:00");
		verifyFoodInLogBookDetailPage(client, "Snack", "grams", "400");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected Verify Min Carb amount 0 grams is set for Lunch
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step15);
		createNewNote(client, getCalendarDate(client), "6.30");
		clickAndSetFoodAttribute(client, "Lunch", "0");
		verifyFoodEntry(client, "Lunch", "grams", "0");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS905 SDAIUIRS906
		 * @Expected New Note created with exercise attribute Low '12' hrs '59'
		 *           mins duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step16);
		addNoteForExercise(client, "Low Intensity", 12, 59);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "06:30");
		verifyFoodInLogBookDetailPage(client, "Lunch", "grams", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 12, 59);
		swipetoSeeNotesContent(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected New Note created with food attribute Dinner 0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step17);
		createNewNote(client, getCalendarDate(client), "8.00");
		clickAndSetFoodAttribute(client, "Dinner", "0");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "08:00");
		verifyFoodInLogBookDetailPage(client, "Dinner", "grams", "0");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS905 SDAIUIRS906
		 * @Expected New Note created with exercise attribute Medium '12' hrs
		 *           '59' mins duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step18);
		editNote(client,"08:00");
		addNoteForExercise(client, "Medium Intensity", 12, 59);
		clickOnButtonOption(client, "DONE", true);
		verifyFoodInLogBookDetailPage(client, "Dinner", "grams", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 12, 59);
		swipetoSeeNotesContent(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1134
		 * @Expected The Note can't created with food attribute 100.5 or
		 *           401grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step19_1);
		createNewNote(client, getCalendarDate(client), "9.30");
		clickAndSetFoodAttribute(client, "Lunch", "401");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step19_2);
		clickAndSetFoodAttribute(client, "Lunch", "100.5");
		verifyFoodError(client, "grams");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected New Note created with food attribute Snack 0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step20);
		clickAndSetFoodAttribute(client, "Snack", "0");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "09:30");
		verifyFoodInLogBookDetailPage(client, "Snack", "grams", "0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAIUIRS905 SDAIUIRS906
		 * @Expected New Note created with exercise attribute High '12' hrs '59'
		 *           mins duration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step21);
		clickCreatedNote(client, "09:30");
		editNote(client,"09:30");
		addNoteForExercise(client, "High Intensity", 12, 59);
		clickOnButtonOption(client, "DONE", true);
		verifyFoodInLogBookDetailPage(client, "Snack", "grams", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 12, 59);
		swipetoSeeNotesContent(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1134
		 * @Expected New Note created with food attribute Breakfast 0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step22);
		createNewNote(client, getCalendarDate(client), "11.00");
		clickAndSetFoodAttribute(client, "Breakfast", "0");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "11:00");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "grams", "0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 23
		 * @Reqt SDAIUIRS902
		 * @Expected Long-Acting Insulin attribute cab be selected from note entry.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step23);
		createNewNote(client, getCalendarDate(client), "13.30");
		selectAndVerifyNoteAttribute(client, "Long-Acting Insulin", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 24
		 * @Reqt SDAIUIRS900
		 * @Expected Note entry provides a means to add the Rapid-Acting Insulin
		 *           attribute of a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step24);
		unSelectNoteAttribute(client, "Long-Acting Insulin");
		selectAndVerifyNoteAttribute(client, "Rapid-Acting Insulin", true);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 25
		 * @Reqt SDAIUIRS849_SDAIUIRS901_SDAIUIRS1201
		 * @Expected New Note created with Rapid-Acting Insulin attribute 0.1
		 *           units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step25);
		addNoteForRapidActingInsulin(client, "0.1");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "13:30");
		verifyInsulinLogBookDetailPage(client, "Rapid", "0.1");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 26
		 * @Reqt SDAIUIRS849_SDAIUIRS901_SDAIUIRS903_SDAIUIRS1201_SDAIUIRS1202
		 * @Expected New Note created with both Insulin attribute 200 units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step26);
		createNewNote(client, getCalendarDate(client), "15.00");
		addNoteForRapidActingInsulin(client, "200");
		addNoteForLongActingInsulin(client, "200");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "15:00");
		verifyInsulinLogBookDetailPage(client, "Rapid", "200");
		verifyInsulinLogBookDetailPage(client, "Long", "200");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 27
		 * @Reqt SDAIUIRS901_SDAIUIRS903_SDAIUIRS1201_SDAIUIRS1202
		 * @Expected New Note created with both Insulin attribute 199.9 units
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step27);
		createNewNote(client, getCalendarDate(client), "16.30");
		addNoteForRapidActingInsulin(client, "199.9");
		addNoteForLongActingInsulin(client, "199.9");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "16:30");
		verifyInsulinLogBookDetailPage(client, "Rapid", "199.9");
		verifyInsulinLogBookDetailPage(client, "Long", "199.9");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 28
		 * @Reqt SDAIUIRS903 SDAIUIRS1202
		 * @Expected New Note created with Long-Acting Insulin attribute 0.1
		 *           unit
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step28);
		createNewNote(client, getCalendarDate(client), "18.00");
		addNoteForLongActingInsulin(client, "0.1");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "18:00");
		verifyInsulinLogBookDetailPage(client, "Long", "0.1");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 29
		 * @Reqt SDAIUIRS901_SDAIUIRS903_SDAIUIRS1201_SDAIUIRS1202
		 * @Expected The Note can't be created with Insulin attribute '0' ,
		 *           '200.1', '5.01'
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_1);
		createNewNote(client, getCalendarDate(client), "18.00");
		addNoteForLongActingInsulin(client, "0");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_2);
		addNoteForLongActingInsulin(client, "200.1");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_3);
		addNoteForLongActingInsulin(client, "5.01");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_4);
		unSelectNoteAttribute(client, "Long-Acting Insulin");
		addNoteForRapidActingInsulin(client, "0");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_5);
		addNoteForRapidActingInsulin(client, "200.1");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step29_6);
		addNoteForRapidActingInsulin(client, "5.01");
		verifyInsulinError(client);
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		clickOnButtonOption(client, "CANCEL", true);

		/**
		 * 
		 * @stepId Step 30
		 * @Reqt SDAIUIRS1179
		 * @Expected Rapid-Acting Insulin attribute is removed from the edited note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step30);
		clickCreatedNote(client, "15:00");
		editNote(client,"15:00");
		unSelectNoteAttribute(client, "Rapid-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		verifyInsulinLogBookDetailPage(client, "Long", "200");
		verifyInsulinNotFound(client, "Rapid", "200");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 31
		 * @Reqt SDAIUIRS1180
		 * @Expected Long-Acting Insulin attribute from note is removed from the edited note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step31);
		clickCreatedNote(client, "16:30");
		editNote(client,"16:30");
		unSelectNoteAttribute(client, "Long-Acting Insulin");
		clickOnButtonOption(client, "DONE", true);
		verifyInsulinLogBookDetailPage(client, "Rapid", "199.9");
		verifyInsulinNotFound(client, "Long", "199.9");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 32
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135_SDAIUIRS905_SDAIUIRS906
		 * @Expected New Note created with food attribute Lunch 0 svg(or ptn for UK) and with
		 *           Exercise attribute High Intensity 2 hrs
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step32);
		setAndGetCarbUnit(client, "servings");
		navigateToScreen(client, "Logbook");
		createNewNote(client, getCalendarDate(client), "20.00");
		clickAndSetFoodAttribute(client, "Lunch", "0");
		addNoteForExercise(client, "High Intensity", 2, 0);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "20:00");
		verifyFoodInLogBookDetailPage(client, "Snack", "servings", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 2, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 33
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135_SDAIUIRS905_SDAIUIRS906
		 * @Expected New Note created with food attribute Breakfast 0 svg(or ptn for UK) and
		 *           with Exercise attribute Medium 1 hour
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step33);
		createNewNote(client, getCalendarDate(client), "21.30");
		clickAndSetFoodAttribute(client, "Breakfast", "0");
		addNoteForExercise(client, "Medium Intensity", 1, 0);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "21:30");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "servings", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 1, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 34
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135_SDAIUIRS905_SDAIUIRS906
		 * @Expected New Note created with food attribute Snack 0 svg(or ptn for UK) and with
		 *           Exercise attribute Low 12 hrs
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step34);
		createNewNote(client, getCalendarDate(client), "23.30");
		clickAndSetFoodAttribute(client, "Snack", "0");
		addNoteForExercise(client, "Low Intensity", 12, 0);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "23:30");
		verifyFoodInLogBookDetailPage(client, "Snack", "servings", "0");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 12, 0);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 35
		 * @Reqt SDAIUIRS850
		 * @Expected The Note entry displays today at 23:00
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step35);
		logbookDate = getCalendarDate(client);
		createNewNote(client, logbookDate, "23.00");
		verifyPageTitles(client, "Add Note");
		verifyAddNotePageDateTime(client, logbookDate, "23:00");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 36
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135
		 * @Expected _New Note created with food attribute Dinner 0 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step36);
		clickAndSetFoodAttribute(client, "Dinner", "0");
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "23:00");
		verifyFoodInLogBookDetailPage(client, "Dinner", "servings", "0");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 37
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135
		 * @Expected The Note can't created with food attribute '0.4' , '40.1',
		 *           '40.5' servings(or portions for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_1);
		createNewNote(client, getCalendarDate(client), "23.00");
		clickAndSetFoodAttribute(client, "Breakfast", "0.4");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_2);
		clickAndSetFoodAttribute(client, "Breakfast", "40.5");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_3);
		clickAndSetFoodAttribute(client, "Breakfast", "40.1");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_4);
		clickAndSetFoodAttribute(client, "Dinner", "0.4");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_5);
		clickAndSetFoodAttribute(client, "Dinner", "40.5");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step37_6);
		clickAndSetFoodAttribute(client, "Dinner", "40.1");
		verifyFoodError(client, "servings");
		capturescreenshot(client, getStepID(), true);
		clickErrorOk(client);
		clickOnButtonOption(client, "CANCEL", true);

		/**
		 * 
		 * @stepId Step 38
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135_SDAIUIRS905 SDAIUIRS906
		 * @Expected New Note created with food attribute Lunch 40 svg(or ptn for UK) & with
		 *           Exercise attribute High 1 min
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step38);
		clickCalanderLeftButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "21:30");
		clickOnButtonOption(client, "ADD NOTE", true);
		clickAndSetFoodAttribute(client, "Lunch", "40");
		addNoteForExercise(client, "High Intensity", 0, 1);
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "21:30");
		verifyFoodInLogBookDetailPage(client, "Lunch", "servings", "40");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 0, 1);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 39
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135_SDAIUIRS905_SDAIUIRS906
		 * @Expected New Note created with food attribute Dinner 40 svg(or ptn for UK) & with
		 *           Exercise attribute medium 59 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step39);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "15:00");
		clickOnButtonOption(client, "ADD NOTE", true);
		clickAndSetFoodAttribute(client, "Dinner", "40");
		addNoteForExercise(client, "Medium Intensity", 0, 59);
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "15:00");
		verifyFoodInLogBookDetailPage(client, "Dinner", "servings", "40");
		verifyExerciseIntensityInLogBookDetailPage(client, "Medium", 0, 59);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 40
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135_SDAIUIRS905_SDAIUIRS906
		 * @Expected New Note created with food attribute Snack 40 svg(or ptn for UK) and with
		 *           Exercise attribute Low 11 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step40);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "13:59");
		clickOnButtonOption(client, "ADD NOTE", true);
		clickAndSetFoodAttribute(client, "Snack", "40");
		addNoteForExercise(client, "Low Intensity", 0, 11);
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "13:59");
		verifyFoodInLogBookDetailPage(client, "Snack", "servings", "40");
		verifyExerciseIntensityInLogBookDetailPage(client, "Low", 0, 11);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 41
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135
		 * @Expected New Note created with food attribute Breakfast 40 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step41);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "18:30");
		clickOnButtonOption(client, "ADD NOTE", true);
		clickAndSetFoodAttribute(client, "Breakfast", "40");
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "18:30");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "servings", "40");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 42
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135
		 * @Expected New Note created with food attribute Breakfast 10.5 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step42);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "11:30");
		clickOnButtonOption(client, "ADD NOTE", true);
		clickAndSetFoodAttribute(client, "Breakfast", "10.5");
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "11:30");
		verifyFoodInLogBookDetailPage(client, "Breakfast", "servings", "11.5");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 43
		 * @Reqt SDAIUIRS894_SDAIUIRS907
		 * @Expected Note at 11:30 is edited with Comment of 256 characters 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step43);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "11:30");
		editNote(client,"11:30");
		scrollToBottomAddNotePage(client);
		enterNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS);
		clickOnButtonOption(client, "DONE", true);
		swipetoSeeNotesContent(client);
		verifyNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 44
		 * @Reqt SDAIUIRS899_SDAIUIRS848_SDAIUIRS1135
		 * @Expected New Note created with food attribute Lunch 39.5 svg(or ptn for UK)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step44);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "07:59");
		clickOnButtonOption(client, "ADD NOTE", true);
		clickAndSetFoodAttribute(client, "Lunch", "39.5");
		clickOnButtonOption(client, "DONE", true);
		clickOnBackIcon(client);
		clickCreatedNote(client, "07:59");
		verifyFoodInLogBookDetailPage(client, "Lunch", "servings", "39.5");
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 45
		 * @Reqt SDAIUIRS907
		 * @Expected Note at 7:59 is edited with Comment including 256 characters 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step45);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "07:59");
		editNote(client,"07:59");
		scrollToBottomAddNotePage(client);
		enterNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS + "A");
		clickOnButtonOption(client, "DONE", true);
		swipetoSeeNotesContent(client);
		verifyNotesComments(client,
				LibrelinkConstants.TWOFIFTYSIX_CHARACTERS_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 46
		 * @Reqt SDAIUIRS907
		 * @Expected Comment with special characters displayed in the
		 *           Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step46);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "03:59");
		clickOnButtonOption(client, "ADD NOTE", true);
		scrollToBottomAddNotePage(client);
		enterNotesComments(client, LibrelinkConstants.SPL_COMMENTS);
		clickOnButtonOption(client, "DONE", true);
		verifyNotesComments(client, LibrelinkConstants.SPL_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);

		/**
		 * 
		 * @stepId Step 47
		 * @Reqt SDAIUIRS893
		 * @Expected The Logbook List View provides a means to invoke the Note
		 *           entry feature to add a note.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step47);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		createNewNote(client, getCalendarDate(client), "3.00");
		verifyPageTitles(client, "Add Note");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 48
		 * @Reqt SDAIUIRS907
		 * @Expected Comment with numbers, upper case, lower case characters,
		 *           spaces, 3 Line returns displayed in the Note entry
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step48);
		enterNotesComments(client, LibrelinkConstants.NEW_LINE_NUMBER_COMMENTS);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "03:00");
		verifyNotesComments(client, LibrelinkConstants.NEW_LINE_NUMBER_COMMENTS);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 49
		 * @Reqt SDAIUIRS1178
		 * @Expected The Food attribute of the edited note(11:30) is removed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step49);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		clickCreatedNote(client, "11:30");
		capturescreenshot(client, getStepID().replace("Step49", "Step49.1")+"Before Removing Food attribute", true);
		editNote(client,"11:30");
		unSelectNoteAttribute(client, "Food");
		clickOnButtonOption(client, "DONE", true);
		verifyNoFoodInLogBookDetailPage(client, "Food");
		capturescreenshot(client, getStepID().replace("Step49", "Step49.2"), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 50
		 * @Reqt SDAIUIRS1181
		 * @Expected The Exercise attribute of the edited note(21:30) is removed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step50);
		clickCalanderRightButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 0);
		clickCreatedNote(client, "21:30");
		swipetoSeeNotesContent(client);
		swipetoSeeNotesContent(client);
		capturescreenshot(client, getStepID().replace("Step50", "Step50.1")+"Before Removing Exercise attribute", true);
		editNote(client,"21:30");
		unSelectNoteAttribute(client, "Exercise");
		clickOnButtonOption(client, "DONE", true);
		verifyExerciseIntensityRemovedInLogBookDetailPage(client, "Medium");
		swipetoSeeNotesContent(client);
		capturescreenshot(client, getStepID().replace("Step50", "Step50.2"), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 51
		 * @Reqt SDAIUIRS905_SDAIUIRS906
		 * @Expected New Note created with High Intensity 1 hr and 1 min at 23:30
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Notes_T001_Adding_Remove_attributes_Step51);
		clickCalanderLeftButton(client, 1);
		verifyRequiredDateIsDisplayed(client, getDeviceDate(client), 1);
		createNewNote(client, getCalendarDate(client), "23.00");
		addNoteForExercise(client, "High Intensity", 1, 1);
		clickOnButtonOption(client, "DONE", true);
		clickCreatedNote(client, "23:00");
		verifyExerciseIntensityInLogBookDetailPage(client, "High", 1, 1);
		capturescreenshot(client, getStepID(), true);
	
		
		selectingSASMode(client, "DEFAULT");
		currentSystemTime(client);
	}
	
	
}
