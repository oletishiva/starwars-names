package com.abbott.project37375iOS.notesAndlogbook;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Logbook_T001_Logbook_Navigation.class, Logbook_T002_Graph_Axis_Display.class,
		Logbook_T003_Logbook_Glucose_Graph_for_90_days.class, ManualBG_T001.class,
		Notes_T001_Adding_Remove_attributes.class, Notes_T002_Home_MyGlucose_Logbook_DailyReport.class })
public class AllTests {

}
