package com.abbott.project37375iOS.homescreenAndscanning;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.abbott.project37375iOS.main.PreRequisite;

@RunWith(Suite.class)
@Suite.SuiteClasses({PreRequisite.class,HomeScreen_T001_Sensor_Status_WithoutData.class,
	HomeScreen_T002_Sensor_Status_WithData.class,HomeScreen_T003_LastScan_UOM_Average_percentage_Axis.class,
	Scanning_T001_Low_and_High_Glucose_Alarm.class,Scanning_T002_Low_and_High_Projected_Glucose_Alarm.class})
public class TestSuite {
  //nothing
}
