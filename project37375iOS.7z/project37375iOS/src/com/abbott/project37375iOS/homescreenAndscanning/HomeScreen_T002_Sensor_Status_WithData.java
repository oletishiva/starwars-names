package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class HomeScreen_T002_Sensor_Status_WithData extends HomeScreenAndScanningHelper {

	@Test
	public void test_HomeScreen_T002_Sensor_Status_WithData() throws Exception {
				
		
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS852,SDAIUIRS865,SDAIUIRS1271
		 * @Expected Sensor warmup remaining time displayed on the home screen with Graph
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step1);
		setTheDateAndTime(client,7,9,2017,"12:00");	
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,0,0,0,"1/14");
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Historic","200",true,10,54);
		bgValueWithStaticTime(client,"Realtime","100",true,11,30);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		verifySensorWarmupTimeWithData(client,"57 minutes");
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Sensor warmup remaining time  displayed on the home screen: 30 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step2);
		setTheTimeAlone(client, "12:28");
		launch(client);
		verifySensorWarmupTimeWithData(client,"30 minutes");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Sensor warmup remaining time  displayed on the home screen: 29 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step3);  	
		verifySensorWarmupTimeWithData(client,"29 minutes");
		capturescreenshot(client,getStepID(),true); 

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Sensor warmup remaining time displayed on the home screen: 29 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/		
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step4);
		waitFor(client,10);
		if(client.isElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'29')]",0)){
			verifySensorWarmupTimeWithData(client,"29 minutes");
		}else{
			verifySensorWarmupTimeWithData(client,"28 minutes");
		}
		capturescreenshot(client,getStepID(),true); 


		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS852
		 * @Expected Sensor warmup remaining time displayed on the home screen: 1 minute
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step5);
		setTheTimeAlone(client, "12:58");
		launch(client);		
		verifySensorWarmupTimeWithData(client,"1 minute");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS852,SDAIUIRS856
		 * @Expected Sensor life on the home screen displayed: 14 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step6);
		waitFor(client,60);
		verifySensorLife(client,"days",14);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS874
		 * @Expected Home screen displays a message instructing the user to scan their sensor
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step7);
		setTheDateAndTime(client,19,9,2017,"13:00");	
		verifyScannewSensor(client);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS852,SDAIUIRS856
		 * @Expected Sensor life on the home screen displayed: 2 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step8);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Realtime","100",false,13,00);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		verifySensorLife(client,"days",2);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step9);
		//Manual Verification
		capturescreenshot(client,getStepID(),true);


		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS852,SDAIUIRS857
		 * @Expected Sensor life on the home screen displayed: 24 hours
		 * @Dependancy NA
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step10);
		setTheDateAndTime(client,20,9,2017,"11:58");	
		verifySensorLife(client,"hours",24);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS852,SDAIUIRS857,SDAIUIRS865
		 * @Expected Sensor life on the home screen displayed: 2 hours with Graph
		 * @Dependancy NA
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step11);
		setTheDateAndTime(client,21,9,2017,"10:56");
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Historic","100",true,10,20);
		bgValueWithStaticTime(client,"Realtime","150",true,10,55);
		scanMockSensor(client,null);
		clickOnBackIcon(client);		
		verifySensorLife(client,"hours",2);
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		sensorEndingSoonPopUp(client,"hour");

		/**
		 * 
		 * @stepId Step12
		 * @Reqt SDAIUIRS852,SDAIUIRS858,SDAIUIRS865
		 * @Expected Sensor life on the home screen displayed: 60 mins with Graph
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step12);		
		verifySensorLife(client,"minutes",60);
		sensorEndingSoonPopUp(client,"hour");
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS852,SDAIUIRS858
		 * @Expected Sensor life on the home screen displayed: 1min
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step13);
		setTheTimeAlone(client, "11:58");
		launch(client);	
		verifySensorLife(client,"minute",1);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS855
		 * @Expected App UI notifies the user within 1 minute after sensor expiration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step14);	
		waitFor(client, 60);
		verifySensorExpiredMessage(client);	
		capturescreenshot(client,getStepID(),true);
		clickOnButtonOption(client,"OK",true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS875,SDAIUIRS865
		 * @Expected Scan new Sensor button is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step15);		
		verifyScanNewSensorButton(client);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS875
		 * @Expected Home screen displays a message instructing the user to scan a new sensor to activate it.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step16);		
		setTheDateAndTime(client,22,9,2017,"10:54");	
		navigateToScreen(client, "Home");
		waitFor(client, 10);
		clickOnButtonOption(client, "NEXT", true);
		verifyScanInstructionMessage(client);	
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step17);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,0,0,0,"1/14");
		openDebugDrawer(client);
		addScanData(client, "Realtime", null, null, null, true, 0, 0,-10, false);
		scanMockSensor(client,null);
		clickOnBackIcon(client);		
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		
		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step18);
		advanceTime(client,23,46);
		launch(client);
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is not displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step19);
		waitFor(client, 120);
		verifyGlucoseGraph(client,false);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS865
		 * @Expected A glucose graph is displayed
		 * @Dependancy NA
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step20);
		openDebugDrawer(client);
		bgValueWithStaticTime(client, "Historic", "100", false, 0, 0);
		scanMockSensor(client,null);
		clickOnBackIcon(client);		
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 21	
		 * @Reqt SDAIUIRS865
		 * @Expected A glucose graph is displayed
		 * @Dependancy NA
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step21);
		advanceTime(client, 23, 57);
		launch(client);
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS865
		 * @Expected A glucose graph is not displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_Step22);
		client.waitForElementToVanish("NATIVE", "xpath=//*[@accessibilityLabel='100 %']", 0, 60000);
		verifyGlucoseGraph(client,false);
		capturescreenshot(client,getStepID(),true);
		
		
		
		selectingSASMode(client,"DEFAULT");
        currentSystemTime(client);
	}

}
