package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class HomeScreen_T003_LastScan_UOM_Average_percentage_Axis extends
		HomeScreenAndScanningHelper {

	@Test
	public void test_HomeScreen_T003_LastScan_UOM_Average_percentage_Axis()
			throws Exception {
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS860,SDAIUIRS1221
		 * @Expected Home Screen displays the most recent scan result 500 mg/dL
		 *           or 27.8 mmol/L for LAST SCAN
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step1);
		changeTimeZone(client, LibrelinkConstants.USZone);
		setTheDateAndTime(client,0,0,0,"00:11");
		loadTestData(client, "MOCK_2", "ADC","BG40-500-Calc39-501.json"); 
			if (getUnits().equalsIgnoreCase("mg/dL")) {
				verifyLastScan(client, "500 mg/dL", null);
			} else if (getUnits().equalsIgnoreCase("mmol/L")) {
				verifyLastScan(client, "27.8 mmol/L", null);
			}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS861
		 * @Expected Home Screen displays the time of most recent scan for LAST SCAN: 23:59
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step2);
		verifyLastScan(client, null, "23:59");
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS866
		 * @Expected X-axis displays 24-hour period ending at the current
		 *           time.(24 hour format)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step3);
		// MANUAL VERIFICATION
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAIUIRS867
		 * @Expected Y-axis from 0 to 500 mg/dL or 0-27 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step4);
		// MANUAL VERIFICATION
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 5
		 * @Reqt SDAIUIRS861
		 * @Expected Home Screen displays the time of most recent scan for LAST
		 *           SCAN: 11:59 pm
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step5);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		reLaunch(client);
		verifyLastScan(client, null, "11:59 pm");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 6
		 * @Reqt SDAIUIRS866
		 * @Expected X-axis displays 24-hour period ending at the current time
		 *           in 12 hour format
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step6);
		// MANUAL VERIFICATION
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 7
		 * @Reqt SDAIUIRS861
		 * @Expected Home Screen displays the time of most recent scan for LAST SCAN: 2:59 am
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step7);
		changeTimeZone(client, LibrelinkConstants.ESTZone);
		reLaunch(client);
		verifyLastScan(client, null, "2:59 am");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 8
		 * @Reqt SDAIUIRS861
		 * @Expected Home Screen displays the time of most recent scan for LAST SCAN: 10:59 pm
		 * @Dependancy NA
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step8);
		changeTimeZone(client, LibrelinkConstants.AKDTZone);
		reLaunch(client);
		verifyLastScan(client, null, "10:59 pm");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 9
		 * @Reqt SDAIUIRS860
		 * @Expected Home Screen displays the most recent scan result HI for LAST SCAN
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step9);
		changePhoneHourTimeFormat(client,
				LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		changeTimeZone(client, LibrelinkConstants.USZone);
		reLaunch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "501", null, null, false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		verifyLastScan(client, "HI", null);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 10
		 * @Reqt SDAIUIRS860 
		 * @Expected Home Screen displays the most recent scan result LO for LAST SCAN
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step10);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "39", null, null, false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		verifyLastScan(client, "LO", null);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 11
		 * @Reqt SDAIUIRS860,SDAIUIRS1221
		 * @Expected Home Screen displays the most recent scan result 40 mg/dL or 2.2 mmol/L for LAST SCAN
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step11);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "40", null, null, false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLastScan(client, "40 mg/dL", null);
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyLastScan(client, "2.2 mmol/L", null);
		}
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 12
		 * @Reqt SDAIUIRS864 
		 * @Expected Home screen displays: Average = 111 mmg/dL or 6.2 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step12);	
		setTheDateAndTime(client,0,0,0,"12:00");	
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client ,"Target Glucose Range");
		if (getUnits().equals("mg/dL")) {
			verifyandsetTGfromSettings(client, 70, 180);
		} else if (getUnits().equals("mmol/L")) {
			verifyandsetTGfromSettings(client, 3.9, 10.0);
		}
		
		loadTestData(client, "MOCK_2", "ADC",
				"Home_Ave_Percent.json");
		
		navigateToScreen(client, "Home");
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyAvgGlucose(client, "111 mg/dL");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyAvgGlucose(client, "6.2 mmol/L");
		}
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS866
		 * @Expected X-axis displays 24-hour period ending at the current time.(24 hour format)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step13);
		// MANUAL VERIFICATION
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 14
		 * @Reqt SDAIUIRS867
		 * @Expected Y-axis from 0 to 350 mg/dL or 0-21 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step14);
		// MANUAL VERIFICATION
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 15
		 * @Reqt SDAIUIRS863 
		 * @Expected Home screen displays: Time In Target =  100%
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step15);		
		verifyTimeintargetinHome(client, "100 %");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 16
		 * @Reqt SDAIUIRS863 
		 * @Expected Home screen displays: Time In Target =  0%
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step16);
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client ,"Target Glucose Range");
		if (getUnits().equals("mg/dL")) {
			verifyandsetTGfromSettings(client, 70, 71);
		} else if (getUnits().equals("mmol/L")) {
			verifyandsetTGfromSettings(client, 3.9, 4.0);
		}
		navigateToScreen(client, "Home");		
		verifyTimeintargetinHome(client, "0 %");
		capturescreenshot(client, getStepID(), true);
		/**
		 *
		 * @stepId Step 17
		 * @Reqt SDAIUIRS863 
		 * @Expected Home screen displays: Time In Target =  50%
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T003_LastScan_UOM_Average_percentage_Axis_Step17);		
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client ,"Target Glucose Range");
		if (getUnits().equals("mg/dL")) {
			verifyandsetTGfromSettings(client, 70, 120);
		} else if (getUnits().equals("mmol/L")) {
			verifyandsetTGfromSettings(client, 3.9, 6.7);
		}
		navigateToScreen(client, "Home");
		verifyTimeintargetinHome(client, "50 %");
		capturescreenshot(client, getStepID(), true);
	
		selectingSASMode(client,"DEFAULT");
		changeTimeZone(client, getDefaultTimeZone());
		currentSystemTime(client);
	}
}
