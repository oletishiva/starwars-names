package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class HomeScreen_T001_Sensor_Status_WithoutData_US10d extends HomeScreenAndScanningHelper {

	@Test
	public void test_HomeScreen_T001_Sensor_Status_WithoutData_US10d() throws Exception {
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS852,SDAIUIRS1276
		 * @Expected  Sensor Ready time 00:00 and Sensor warmup remaining time 12 hrs 0 mins displayed on the home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step1);	
		setTheDateAndTime(client,7,9,2017,"11:59");	
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,0,0,0,"12/11");
		verifySensorWarmupTime(client, "12 hrs 0 mins","00:00");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS852,SDAIUIRS859,SDAIUIRS1276
		 * @Expected Sensor Ready time 00:00 and Sensor warmup remaining time 11 hrs 30 mins displayed on the home screen 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step2);
		setTheTimeAlone(client, "12:28");
		launch(client);
		verifySensorWarmupTime(client, "11 hrs 30 mins","00:00");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS852,SDAIUIRS859,SDAIUIRS1276
		 * @Expected Sensor Ready time 12:00 am and Sensor warmup remaining time 11 hrs 29 mins displayed on the home screen 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step3);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		launch(client);
		verifySensorWarmupTime(client, "11 hrs 29 mins","12:00 am");
		capturescreenshot(client,getStepID(),true); 

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAIUIRS852,SDAIUIRS859,SDAIUIRS1276
		 * @Expected Sensor Ready time 12:00 am and Sensor warmup remaining time 11 hrs 29/28 mins displayed on the home screen 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/		
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step4);
		if(client.isElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'29 mins remaining')]",0)){
			verifySensorWarmupTime(client, "11 hrs 29 mins","12:00 am");
		}else{
			verifySensorWarmupTime(client, "11 hrs 28 mins","12:00 am");
		}
		
		capturescreenshot(client,getStepID(),true); 

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS852
		 * @Expected Sensor warmup remaining time displayed on the home screen: 1min
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step5);
		setTheDateAndTime(client,7,9,2017,"23:58") ;	
		verifySensorWarmupTime(client, "1 min","00:00");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS852,SDAIUIRS856
		 * @Expected Sensor life on the home screen displayed: 10 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step6);
		waitFor(client,60);
		sensorReadyPopUp(client);
		verifySensorLife(client,"days",10);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS852,SDAIUIRS856,SDAIUIRS874
		 * @Expected Sensor life on the home screen displayed: 2 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step7);
		setTheDateAndTime(client,16,9,2017,"13:00");		
		verifySensorLife(client,"days",2);
		verifyScannewSensor(client);
		capturescreenshot(client,getStepID(),true);


		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS852,SDAIUIRS857
		 * @Expected Sensor life on the home screen displayed: 24 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step8);
		setTheDateAndTime(client,17,9,2017,"11:59");	
		sensorEndingSoonPopUp(client,"day");
		verifySensorLife(client,"hours",24);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS852,SDAIUIRS857
		 * @Expected Sensor life on the home screen displayed: 2 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step9);
		setTheDateAndTime(client,18,9,2017,"10:58");		
		verifySensorLife(client,"hours",2);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step10
		 * @Reqt SDAIUIRS852,SDAIUIRS858
		 * @Expected Sensor life on the home screen displayed: 60 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step10);
		waitFor(client,40);	
		verifySensorLife(client,"minutes",60);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS852,SDAIUIRS858,SDAIUIRS874
		 * @Expected Sensor life on the home screen displayed: 1min
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step11);
		setTheTimeAlone(client, "11:58");
		launch(client);
		verifySensorLife(client,"minute",1);
		verifyScannewSensor(client);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS875
		 * @Expected Home screen displays scan new sensor button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_US10d_Step12);		
		waitFor(client,60);		
		verifyApplyANewSensor(client);
		clickOnButtonOption(client, "NEXT", true);
		verifyScanNewSensorButton(client);
		capturescreenshot(client,getStepID(),true);
		
		selectingSASMode(client,"DEFAULT");
        currentSystemTime(client);
	}

}
