package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class Scanning_T001_Low_and_High_Glucose_Alarm extends
		HomeScreenAndScanningHelper {

	@Test
	public void test_Scanning_T001_Low_and_High_Glucose_Alarm()
			throws Exception {

		/**
		 * @stepId Pre-Condition Update the Time Format
		 * 
		 * @Dependancy Script fails if the Set-Up file is not updated with build
		 *             details
		 */
		setTheDateAndTime(client, 0, 0, 0, "12:00");
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1127
		 * @Expected My Glucose screen is displayed the glucose value as 69 mg/dL or 3.8 mmol/L with LOW GLUCOSE message with ! symbol.
		 *           Glucose message with caution symbol
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step1);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "69", null, "LOW_GLUCOSE", false, 0, 0,
				0, false);
		scanMockSensor(client,null);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "69", "LOW GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.8", "LOW GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1127
		 * @Expected The app displays a pop up with low glucose warning message
		 *           and recommending to check glucose again after some time
		 *           with options CANCEL and SET.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step2);
		verifyAlertPopUp(client, "low");
		capturescreenshot(client, getStepID(), true);

		/** 
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1127
		 * @Expected Pop up disappeared and My Glucose screen remains same with
		 *           69 mg/dL or 3.8 mmol/L glucose value
		 * @Dependancy Script cannot proceed if this step fails 
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step3);
		clickOnButtonOption(client, "CANCEL", true);
		verifyAlertPopUpDisappeared(client,"low");

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "69", "LOW GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.8", "LOW GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1127
		 * @Expected Reminder screen is displayed on clicking SET from Low
		 *           Glucose warning dialog box
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step4);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1127
		 * @Expected Set Reminder screen displays option to set reminder time,
		 *           CANCEL and START button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step5);
		verifyAddReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1127
		 * @Expected App navigated to My Glucose screen and My Glucose screen
		 *           remains same with 69 mg/dL or 3.8 mmol/L glucose value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step6);
		clickOnButtonOption(client, "CANCEL", true);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "69", "LOW GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.8", "LOW GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1127
		 * @Expected Alarm time drop down displayed the alarm times as 15 mins
		 *           and 30 mins and able to select any one of it
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step7);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		verifyAlarmTime(client, "Low");
		selectLowReminderTime(client, 30);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1127
		 * @Expected Alarm set for 15 mins and the Reminders screen displayed
		 *           Check Glucose reminder with timer reminder started from 15
		 *           mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step8);
		selectLowReminderTime(client, 15);
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "14:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1127
		 * @Expected The app displayed the Timer Expired notification with Check
		 *           Glucose
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step9);
		advanceTime(client, 0, 13);
		waitFor(client, 2);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1127
		 * @Expected Alarm Check Glucose reminder displays 30 mins count down
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step10);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "45", null, "LOW_GLUCOSE", false, 0, 0,
				0, false);
		scanMockSensor(client,null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectLowReminderTime(client, 30);
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "29:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1127
		 * @Expected Timer expired notification is displayed with message Check
		 *           Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step11);
		moveApptoBackground(client);
		advanceTime(client, 0, 28);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1127
		 * @Expected My Glucose screen is displayed the glucose value as LO with
		 *           LOW GLUCOSE (OUT OF RANGE) message with caution symbol
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step12);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "39", null, "LOW_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);		
		verifyMyGlucosePage(client, "LO", "LO");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1127
		 * @Expected The app displays a pop up with low glucose warning message and The Timer Reminder set is not displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step13);
		clickAlertIcon(client);
		verifyLOHIAlertPopUp(client, "low");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);
		
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1127
		 * @Expected My Glucose screen is displayed the glucose value as 40mg/dL or  2.2 mmol/L with LOW GLUCOSE  message with caution symbol
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step14);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "40", null, "LOW_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "40", "LOW GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "2.2", "LOW GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS1127
		 * @Expected Alarm time drop down displayed the alarm times as 15 mins and 30 mins and able to select any one of it.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step15);
		clickAlertIcon(client);
		verifyAlertPopUp(client, "low");
		capturescreenshot(client, "Step15_1_SDAIUIRS1127_Low Glucose warning message is displayed", true);
		clickSetCheckGlucoseReminder(client);
		verifyAlarmTime(client, "Low");
		selectLowReminderTime(client, 30);
		capturescreenshot(client, getStepID().replace("Step15", "Step15_2"), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS1127
		 * @Expected Reminders screen displayed Check Glucose reminder with timer reminder started from 30 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step16);
		selectLowReminderTime(client, 30);
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "29:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS1127
		 * @Expected My Glucose screen is displayed the glucose value as 70 mg/dL or  3.9 mmol/L with no LOW GLUCOSE
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step17);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "70", null, null, false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "70", null);
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.9", null);
		}
		client.verifyElementNotFound("NATIVE", "xpath=//*[@accessibilityLabel='LOW GLUCOSE' and @onScreen='true']", 0);
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS1128
		 * @Expected My Glucose screen is displayed the glucose value as 355 mg/dL or 19.7 mmol/L with HIGH GLUCOSE message with caution symbol
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step18);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "355", null, "HIGH_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "355", "HIGH GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "19.7", "HIGH GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1128
		 * @Expected The app displayed a pop up with high glucose warning
		 *           message and recommending to check glucose again after some
		 *           time with options CANCEL and SET
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step19);
		verifyAlertPopUp(client, "high");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS1128
		 * @Expected Pop up disappeared and My Glucose screen remains same with 355 mg/dL or 19.7 mmol/L glucose value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step20);
		clickOnButtonOption(client, "CANCEL", true);
		verifyAlertPopUpDisappeared(client,"high");
		
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "355", "HIGH GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "19.7", "HIGH GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAIUIRS1128
		 * @Expected Reminder screen is displayed on clicking SET from High Glucose warning dialog box
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step21);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS1128
		 * @Expected Set Reminder screen displays option to set reminder time, CANCEL and START button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step22);
		verifyAddReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 23
		 * @Reqt SDAIUIRS1128
		 * @Expected App navigated to My Glucose screen and My Glucose screen remains same with 355 mg/dL or 19.7 mmol/L glucose value
		 *           Check Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step23);
		clickOnButtonOption(client, "CANCEL", true);
		
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "355", "HIGH GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "19.7", "HIGH GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 24
		 * @Reqt SDAIUIRS1128
		 * @Expected Alarm time drop down displayed the alarm times as 1hr, 2hrs, 3hrs and 4hrs and able to select any one of it
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step24);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		verifyAlarmTime(client, "High");
		selectHighReminderTime(client, "2");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 25
		 * @Reqt SDAIUIRS1128
		 * @Expected Alarm set for 1hr and the Reminders screen displayed Check Glucose reminder with timer reminder started from 1hr
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step25);
		selectHighReminderTime(client, "1");
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "59:");
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 26
		 * @Reqt SDAIUIRS1128
		 * @Expected 1 hour Timer expired notification is displayed with message
		 *           Check Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step26);
		advanceTime(client, 0, 59);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 *
		 * @stepId Step 27
		 * @Reqt SDAIUIRS1128
		 * @Expected 2 hours Timer expired notification is displayed with
		 *           message Check Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step27);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "241", null, "HIGH_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectHighReminderTime(client, "2");
		clickOnButtonOption(client, "START", true);		
		advanceTime(client, 1, 59);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");
		

		/**
		 *
		 * @stepId Step 28
		 * @Reqt SDAIUIRS1128
		 * @Expected 3 hours Timer expired notification is displayed with
		 *           message Check Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step28);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "500", null, "HIGH_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectHighReminderTime(client, "3");
		clickOnButtonOption(client, "START", true);
		advanceTime(client, 2, 59);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");


		/**
		 *
		 * @stepId Step 29
		 * @Reqt SDAIUIRS1128
		 * @Expected My Glucose screen is displayed the glucose value as HI with HIGH GLUCOSE(OUT OF RANGE)  message with caution symbol, The Timer Reminder set is not displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step29);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "501", null, "HIGH_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		verifyMyGlucosePage(client, "HI", "HI");
		clickAlertIcon(client);
		verifyLOHIAlertPopUp(client, "high");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"OK",true);

		/**
		 * 
		 * @stepId Step 30
		 * @Reqt SDAIUIRS1128
		 * @Expected My Glucose screen is displayed the glucose value as 401 mg/dL or  22.3 mmol/L with HIGH GLUCOSE  message with caution symbol
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step30);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "401", null, "HIGH_GLUCOSE", false, 0,
				0, 0, false);
		scanMockSensor(client,null);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "401", "HIGH GLUCOSE");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "22.3", "HIGH GLUCOSE");
		}
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 31
		 * @Reqt SDAIUIRS1128
		 * @Expected Alarm time drop down displayed the alarm times as 1hour,
		 *           2hours, 3hours and 4hours and able to select any one of it
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step31);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		verifyAlarmTime(client, "High");
		selectHighReminderTime(client, "2");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 *
		 * @stepId Step 32
		 * @Reqt SDAIUIRS1128
		 * @Expected 4 hours alarm Timer expired notification is displayed with message Check Glucose
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step32);
		selectHighReminderTime(client, "4");
		clickOnButtonOption(client, "START", true);
		moveApptoBackground(client);
		advanceTime(client, 3, 59);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");
		
		/**
		 *
		 * @stepId Step 33
		 * @Reqt SDAIUIRS1128
		 * @Expected My Glucose screen is displayed the glucose value as 240 mg/dL or  13.3 mmol/L without message
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.Scanning_T001_Low_and_High_Glucose_Alarm_Step33);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "240", null, "GLUCOSE_OK", false, 0,
				0, 0, false);
		scanMockSensor(client,null);
		
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "240", null);
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "13.3", null);
		}
		client.verifyElementNotFound("NATIVE", "xpath=//*[@accessibilityLabel='HIGH GLUCOSE' and @onScreen='true']", 0);
		capturescreenshot(client, getStepID(), true);
		
		selectingSASMode(client,"DEFAULT");
     currentSystemTime(client);
	}
}
