package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class HomeScreen_T002_Sensor_Status_WithData_US10d extends HomeScreenAndScanningHelper {

	@Test
	public void test_HomeScreen_T002_Sensor_Status_WithData_US10d() throws Exception {
						
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS852,SDAIUIRS865,SDAIUIRS1271
		 * @Expected Sensor warmup time remaining '12 hours' displayed on  bottom of the home screen with Graph.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step1);
		setTheDateAndTime(client,7,9,2017,"11:57");	
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,0,0,0,"12/11");
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Historic","200",true,10,54);
		bgValueWithStaticTime(client,"Realtime","100",true,11,30);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		verifySensorWarmupTimeWithData(client,"12 hours");
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Sensor warmup time remaining displayed on bottom of the home screen: 11 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step2);
		setTheTimeAlone(client, "13:56");
		launch(client);
		verifySensorWarmupTimeWithData(client,"11 hours");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Sensor warmup time remaining displayed on bottom of the home screen: 10 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step3);  
		waitFor(client, 60);
		verifySensorWarmupTimeWithData(client,"10 hours");
		capturescreenshot(client,getStepID(),true); 

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Sensor warmup time remaining displayed on bottom of the home screen: 60 minutes
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/		
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step4);
		setTheTimeAlone(client, "22:57");
		launch(client);		
		verifySensorWarmupTimeWithData(client,"60 minutes");
		capturescreenshot(client,getStepID(),true); 


		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS852
		 * @Expected Sensor warmup remaining time displayed on the home screen: 1 minute
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step5);
		setTheTimeAlone(client, "23:56");
		launch(client);				
		verifySensorWarmupTimeWithData(client,"1 minute");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS852,SDAIUIRS856
		 * @Expected Sensor life on the home screen displayed: 10 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step6);
		waitFor(client,60);
		verifySensorLife(client,"days",10);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS874
		 * @Expected Sensor life on the home screen displayed: 2 DAYS A glucose graph is NOT displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step7);
		setTheDateAndTime(client,16,9,2017,"12:58");	
		launch(client);		
		verifySensorLife(client,"days",2);
		verifyGlucoseGraph(client,false);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS852,SDAIUIRS856
		 * @Expected Sensor life on the home screen displayed: 2 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step8);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Realtime","100",false,13,00);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		verifySensorLife(client,"days",2);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step9);
		//Manual Verification
		capturescreenshot(client,getStepID(),true);


		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS852,SDAIUIRS857
		 * @Expected Sensor life on the home screen displayed: 24 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step10);
		setTheDateAndTime(client,17,9,2017,"11:58");	
		launch(client);
		verifySensorLife(client,"hours",24);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS852,SDAIUIRS857,SDAIUIRS865
		 * @Expected Sensor life on the home screen displayed: 2 hours with Graph
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step11);
		setTheDateAndTime(client,18,9,2017,"10:54");
		launch(client);		
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Historic","100",true,10,20);
		bgValueWithStaticTime(client,"Realtime","150",true,10,55);
		scanMockSensor(client,null);
		clickOnBackIcon(client);		
		verifySensorLife(client,"hours",2);
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		sensorEndingSoonPopUp(client,"hour");

		/**
		 * 
		 * @stepId Step12
		 * @Reqt SDAIUIRS852,SDAIUIRS858,SDAIUIRS865
		 * @Expected Sensor life on the home screen displayed: 60 mins with Graph
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step12);		
		verifySensorLife(client,"minutes",60);
		sensorEndingSoonPopUp(client,"hour");
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS852,SDAIUIRS858
		 * @Expected Sensor life on the home screen displayed: 1 minute
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step13);
		setTheTimeAlone(client, "11:55");
		launch(client);			
		verifySensorLife(client,"minute",1);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS855
		 * @Expected App UI notifies the user within 1 minute after sensor expiration
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step14);	
		waitFor(client, 60);
		verifySensorExpiredMessage(client);	
		capturescreenshot(client,getStepID(),true);
		clickOnButtonOption(client,"OK",true);
		
		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS875,SDAIUIRS865
		 * @Expected Scan new Sensor button is displayed 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step15);		
		verifyScanNewSensorButton(client);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS875
		 * @Expected Home screen displays scan new sensor button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step16);		
		setTheDateAndTime(client,19,9,2017,"10:54");
		navigateToScreen(client, "Home");
		waitFor(client,10);
		launch(client);
		client.waitForElement("NATIVE", "xpath=//*[@accessibilityIdentifier='NewSensorApply']", 0, 10000);
		clickOnButtonOption(client, "NEXT", true);
		verifyScanInstructionMessage(client);	
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step17);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,0,0,0,"12/11");
		openDebugDrawer(client);
		addScanData(client, "Realtime", null, null, null, true, 0, 0,-10, false);
		scanMockSensor(client,null);
		clickOnBackIcon(client);		
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step18);
		advanceTime(client,23,46);
		launch(client);
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1271
		 * @Expected A glucose graph is not displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step19);
		waitFor(client, 120);
		verifyGlucoseGraph(client,false);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS865
		 * @Expected A glucose graph is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step20);
		openDebugDrawer(client);
		bgValueWithStaticTime(client, "Historic", "100", false, 0, 0);
		scanMockSensor(client,null);
		clickOnBackIcon(client);		
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 21	
		 * @Reqt SDAIUIRS865
		 * @Expected A glucose graph is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step21);
		advanceTime(client, 23, 57);
		launch(client);
		verifyGlucoseGraph(client,true);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS865
		 * @Expected A glucose graph is not displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T002_Sensor_Status_WithData_US10d_Step22);
		client.waitForElementToVanish("NATIVE", "xpath=//*[@accessibilityLabel='100 %']", 0, 60000);
		verifyGlucoseGraph(client,false);
		capturescreenshot(client,getStepID(),true);
		
		
		
		selectingSASMode(client,"DEFAULT");
        currentSystemTime(client);
	}

}
