package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class Scanning_T002_Low_and_High_Projected_Glucose_Alarm extends
HomeScreenAndScanningHelper {

	@Test
	public void test_Scanning_T002_Low_and_High_Projected_Glucose_Alarm_condition()
			throws Exception {

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1129
		 * @Expected My Glucose screen displays glucose value as 70 mg/dL or 3.9
		 *           mmol/L with Glucose going low message message with caution
		 *           symbol.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step1);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "70", "FALLING", "PROJECTED_LOW_GLUCOSE",
				false, 0, 0, 0, false);
		scanMockSensor(client, null);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "70", "GLUCOSE GOING LOW");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.9", "GLUCOSE GOING LOW");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1129
		 * @Expected The app is displayed a pop up with low glucose warning
		 *           message and recommending to check glucose again after some
		 *           time with options CANCEL and SET
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step2);
		verifyAlertPopUp(client, "low");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1129
		 * @Expected Pop up disappeared and My Glucose screen remains same with
		 *           70 mg/dL or 3.9 mmol/L projected glucose value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step3);
		clickOnButtonOption(client, "CANCEL", true);
		verifyAlertPopUpDisappeared(client,"low");

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "70", "GLUCOSE GOING LOW");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.9", "GLUCOSE GOING LOW");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1129
		 * @Expected Reminder screen is displayed on clicking SET from Low
		 *           Glucose warning dialog box
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step4);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1129
		 * @Expected Set Reminder screen displays option to set reminder time,
		 *           CANCEL and START button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step5);
		verifyAddReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1129
		 * @Expected App navigated to My Glucose screen and My Glucose screen
		 *           remains same with 70 mg/dL or 3.9 mmol/L projected glucose
		 *           value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step6);
		clickOnButtonOption(client, "CANCEL", true);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "70", "GLUCOSE GOING LOW");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "3.9", "GLUCOSE GOING LOW");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1129
		 * @Expected Alarm time drop down displayed the alarm times as 15 mins
		 *           and 30 mins and able to select any one of it
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step7);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		verifyAlarmTime(client, "Low");
		selectLowReminderTime(client, 30);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1129
		 * @Expected Alarm set for 15 mins and the Reminder screen displayed
		 *           Check Glucose reminder with timer reminder started from 15
		 *           mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step8);
		selectLowReminderTime(client, 15);
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "14:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1129
		 * @Expected Timer expired notification is displayed      
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step9);
		advanceTime(client, 0, 14);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1129
		 * @Expected Timer expired notification is displayed with message Check
		 *           Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step10);
		launch(client);
		selectSkipForDebugging(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "50", null, "PROJECTED_LOW_GLUCOSE",
				false, 0, 0, 0, false);
		scanMockSensor(client, null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectLowReminderTime(client, 30);
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "29:");
		advanceTime(client, 0, 28);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1130
		 * @Expected My Glucose screen displayed the glucose value as 240 mg/dL
		 *           or 13.3 mmol/L with GLUCOSE GOING HIGH message with caution
		 *           symbol
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step11);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "240", "RISING", "PROJECTED_HIGH_GLUCOSE",
				false, 0, 0, 0, false);
		scanMockSensor(client, null);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "240", "GLUCOSE GOING HIGH");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "13.3", "GLUCOSE GOING HIGH");
		}

		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1130
		 * @ExpectedThe app displayed a pop up with high glucose warning message
		 *              and recommending to check glucose again after some time
		 *              with options CANCEL and SET
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step12);
		verifyAlertPopUp(client, "high");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1130
		 * @Expected Pop up disappeared and My Glucose screen remains same with
		 *           240 mg/dL or 13.3 mmol/L projected glucose value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step13);
		clickOnButtonOption(client, "CANCEL", true);
		verifyAlertPopUpDisappeared(client,"high");

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "240", "GLUCOSE GOING HIGH");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "13.3", "GLUCOSE GOING HIGH");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1130
		 * @Expected Reminder screen is displayed on clicking SET from Low
		 *           Glucose warning dialog box
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step14);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS1130
		 * @Expected Add Reminder screen displays option to set reminder time,
		 *           CANCEL and START button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step15);
		verifyAddReminder(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS1130
		 * @Expected App navigated to My Glucose screen and My Glucose screen
		 *           remains same with 240 mg/dL or 13.3 mmol/L projected
		 *           glucose value
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step16);
		clickOnButtonOption(client, "CANCEL", true);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyMyGlucosePage(client, "240", "GLUCOSE GOING HIGH");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyMyGlucosePage(client, "13.3", "GLUCOSE GOING HIGH");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS1130
		 * @Expected Alarm time dropdown displayed the alarm times as 1hr, 2hrs,
		 *           3hrs and 4hrs and able to select any one of it
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step17);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		verifyAlarmTime(client, "High");
		selectHighReminderTime(client, "2");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS1130
		 * @Expected Alarm set for 1hr and the Reminder screen displayed Check
		 *           Glucose reminder with timer reminder started from 1hr
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step18);
		selectHighReminderTime(client, "1");
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		verifyCheckGlucoseReminderCountdown(client, "59:");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUIRS1130
		 * @Expected Timer expired notification is displayed with message Check
		 *           Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step19);
		advanceTime(client, 0, 58);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS1130
		 * @Expected Timer expired notification is displayed with message Check
		 *           Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step20);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "410", null, "PROJECTED_HIGH_GLUCOSE",
				false, 0, 0, 0, false);
		scanMockSensor(client, null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectHighReminderTime(client, "2");
		clickOnButtonOption(client, "START", true);
		advanceTime(client, 1, 58);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAIUIRS1130
		 * @Expected Timer expired notification is displayed with message Check
		 *           Glucose.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step21);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "480", null, "PROJECTED_HIGH_GLUCOSE",
				false, 0, 0, 0, false);
		scanMockSensor(client, null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectHighReminderTime(client, "3");
		clickOnButtonOption(client, "START", true);
		advanceTime(client, 2, 58);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");

		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS1130
		 * @Expected Once the alarm become current, the app displayed the Timer
		 *           Expired notification with message Check Glucose
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step22);
		launch(client);
		debugDrawerClearData(client);
		selectingSASMode(client, "MOCK_1");
		openDebugDrawer(client);
		addScanData(client, "Realtime", "420", null, "PROJECTED_HIGH_GLUCOSE",
				false, 0, 0, 0, false);
		scanMockSensor(client, null);
		clickAlertIcon(client);
		clickSetCheckGlucoseReminder(client);
		waitFor(client, 1);
		selectHighReminderTime(client, "4");
		clickOnButtonOption(client, "START", true);
		clickOnBackIcon(client);
		navigateToScreen(client, "Reminders");
		client.verifyElementFound("NATIVE", "partial_text=3:5", 0);
		advanceTime(client,3,59);
		verifyTimerExpiredNotification(client);
		capturescreenshot(client, getStepID(), true);
		clearSingleNotification(client, "Timer Expired");


		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 23
			 * @Reqt SDAIUIRS1190,SDAISRS395
			 * @Expected My Glucose screen displayed result with Non-Actionable
			 *           indication icon
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step23);
			launch(client);
			debugDrawerClearData(client);
			openDebugDrawer(client);
			addScanData(client, "Realtime", "69", "FALLING_QUICKLY", null, false, 0, 0, 0, true);
			scanMockSensor(client, null);
			verifyandClickNonActionable(client, false);
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 24
			 * @Reqt SDAIUIRS1190
			 * @Expected Non actionable information dialog pops up
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step24);
			verifyandClickNonActionable(client, true);
			capturescreenshot(client, getStepID(), true);
			clickOnButtonOption(client, "OK", true);

		}else{
			showNotApplicableScreenShot(client,"Step 23 & 24_Non-Actionable Scenario_NotApplicable");
			launch(client);
			debugDrawerClearData(client);
			openDebugDrawer(client);
			addScanData(client, "Realtime", "69", "FALLING_QUICKLY", null, false, 0, 0, 0, false);
			scanMockSensor(client, null);
		}

		if (getUnits().equalsIgnoreCase("mmol/L")) {
			/**
			 * 
			 * @stepId Step 25
			 * @Reqt SDAIUIRS1227
			 * @Expected The software displays the numeric glucose result digits
			 *           after the decimal separator in a smaller font than the
			 *           digits before the decimal separator
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step25);
			//IMAGE VERIFICATION
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 26
			 * @Reqt SDAIUIRS1227
			 * @Expected The software displays the numeric glucose result digits
			 *           after the decimal separator in a smaller font than the
			 *           digits before the decimal separator
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.Scanning_T002_Low_and_High_Projected_Glucose_Alarm_Step26);

			launch(client);
			debugDrawerClearData(client);
			openDebugDrawer(client);
			addScanData(client, "Realtime", "75", "FALLING","PROJECTED_LOW_GLUCOSE", false, 0, 0, 0,
					false);
			scanMockSensor(client, null);
			//IMAGE VERIFICATION
			capturescreenshot(client, getStepID(), true);

		}else{
			showNotApplicableScreenShot(client,"Step 25 & 26_NotApplicable_For mg/dL build");
		}

		selectingSASMode(client,"DEFAULT");
		currentSystemTime(client);
	}

}
