package com.abbott.project37375iOS.homescreenAndscanning;


import java.text.ParseException;


import com.abbott.project37375iOS.main.BaseHelper;
import com.experitest.client.Client;

public class HomeScreenAndScanningHelper extends BaseHelper {

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Add Scan Data By Passing Parameters
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param dataType
	 *            entering scanType (Historic or Real time)
	 * @param value
	 *            Scan value
	 * @param trend
	 *            Trend value
	 * @param alarm
	 *            alarm value
	 * @param isTimeReqd
	 *            true to set time
	 * @param days
	 *            set days
	 * @param hours
	 *            set hours
	 * @param minutes
	 *            set minutes
	 * @param isNonActionable
	 *            true to set Non-Actionable
	 */
	public void addScanData(Client client, String dataType, String value,
			String trend, String alarm, boolean isTimeReqd, int days,
			int hours, int minutes, boolean isNonActionable) {

		clickAddSensorDataMethod(client);

		selectScanType(client, dataType);

		if (value != null) {
			enterScanValue(client, value);
		}
		if (trend != null) {
			enterTrendValue(client, trend);
		}
		if (alarm != null) {
			enterAlarmValue(client, alarm);
		}
		if (isNonActionable) {
			clickNonActionable(client);
		}
		if (isTimeReqd) {
			try {
				enterScanActivationDateAndTime(client, days, hours, minutes);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		clickAddScannedValue(client);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * select Scan Type
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param scanType
	 *            entering scanType(Historic or Real time)
	 * 
	 */
	public void selectScanType(Client client, String scanType) {
		client.waitForElement("NATIVE", "text=Add Sensor Data", 0, 10000);
		client.verifyElementFound("NATIVE", "text=" + scanType, 0);
		client.click("NATIVE", "accessibilityLabel=" + scanType, 0, 1);

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Enter Scan Value
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param value
	 *            Scan value
	 * 
	 */
	public void enterScanValue(Client client, String value) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@class='_UITextFieldContentView' and @onScreen='true']",
				0, 10000);
		client.elementSendText(
				"NATIVE",
				"xpath=//*[@class='_UITextFieldContentView' and @onScreen='true']",
				0, "" + value);
		client.sleep(1000);
		client.click("NATIVE", "xpath=//*[@accessibilityLabel='Done']", 0, 1);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='ADD' and @top='true']", 0,
				10000);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Enter Trend Value
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param trend
	 *           click on Trend 
	 * 
	 */
	public void enterTrendValue(Client client, String trend) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='STABLE' and @class='UIButton']",
				0, 10000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='STABLE' and @class='UIButton']",
				0, 1);
		client.sleep(2000);
		client.click("NATIVE", "text=" + trend, 0, 1);
		waitFor(client,1);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Enter Alarm Value
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param alarm
	 *          click on  Alarm value
	 * 
	 */
	public void enterAlarmValue(Client client, String alarm) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='GLUCOSE_OK' and @class='UIButtonLabel']",
				0, 10000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='GLUCOSE_OK' and @class='UIButtonLabel']",
				0, 1);
		client.sleep(2000);
		client.click("NATIVE", "text=" + alarm, 0, 1);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Click on NonActionable
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * 
	 */
	public void clickNonActionable(Client client) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='nonActionable:' and @class='UISwitch']",
				0, 10000);
		client.click(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='nonActionable:' and @class='UISwitch']",
				0, 1);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify the alert details in My glucose screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param GlucoseValue
	 *            scanned glucose value
	 * @param AlertType
	 *            set alert type
	 */
	public void verifyMyGlucosePage(Client client, String GlucoseValue,
			String AlertType) {
		navigateToMyGlucosePage(client);

		if (AlertType != null) {
            client.verifyElementFound("NATIVE", 
            		"xpath=//*[@accessibilityIdentifier='light_event_warning' and @onScreen='true']", 0);
			if (AlertType.equals("HI") || AlertType.equals("LO")) {
				client.verifyElementFound("NATIVE",
						"xpath=//*[contains(@text,'" + AlertType + "')]", 0);
				client.verifyElementFound("NATIVE",
						"xpath=//*[contains(@text,'(OUT OF RANGE)')]", 0);
			} else {
				client.verifyElementFound("NATIVE", "text=" + AlertType, 0);
			}
		}
		verifyGlucoseValueandUnitsMyGlucose(client, GlucoseValue);

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Alert Pop-Up
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param AlertType
	 *            set alert type High glucose / Low Glucose
	 */
	public void verifyAlertPopUp(Client client, String AlertType) {
		clickAlertIcon(client);
		String key;
		if (getNAIconConfig().equalsIgnoreCase("yes") && AlertType.equalsIgnoreCase("low")) {
			key = AlertType + "GlucoseCheckBloodGlucose";
		}else{
			key = AlertType + "GlucoseIsDangerous";
		}
		String Alert = getLangPropValue(key);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"
				+ Alert + "')]", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[contains(@text,'${glucoseWarningReminderPrompt}')]",
				0);
		client.verifyElementFound("NATIVE", "text=CANCEL", 0);
		client.verifyElementFound("NATIVE", "text=SET", 0);

	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify Alert Pop-Up for LO or HI
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param AlertType
	 *            set alert type High for HI / Low for LO
	 */
	public void verifyLOHIAlertPopUp(Client client, String AlertType) {
		clickAlertIcon(client);
		String key;
		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			key = AlertType + "GlucoseCheckBloodGlucose";
		}else{
			key = AlertType + "GlucoseIsDangerous";
		}
		
		String Alert = getLangPropValue(key);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'"
				+ Alert + "')]", 0);
        clickOnButtonOption(client,"OK",false);
        client.verifyElementNotFound("NATIVE", "text=SET", 0);


	}


	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify Alert PopUp Disappeared
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param AlertType
	 *            Alert type name low/high
	 */
	public void verifyAlertPopUpDisappeared(Client client, String AlertType) {
		client.verifyElementNotFound(
				"NATIVE",
				"xpath=//*[@class='_UITextContainerView' and @onScreen='true']",
				0);
		String key;
		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			key = AlertType + "GlucoseCheckBloodGlucose";
		}else{
			key = AlertType + "GlucoseIsDangerous";
		}
		String Alert = getLangPropValue(key);
		client.verifyElementNotFound("NATIVE", "xpath=//*[contains(@text,'"
				+ Alert + "')]", 0);
	}

	

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Add Reminder
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 */
	public void verifyAddReminder(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Add Reminder']", 0, 5000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='UIPickerTableView']", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=CANCEL", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=START", 0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify the alarm time screen
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * 
	 * @param glucoseType
	 *            Glucose type low / high
	 */
	public void verifyAlarmTime(Client client, String glucoseType) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='ReminderHourPicker' and @class='UIPickerView']",
				0, 10000);
		if (glucoseType.equalsIgnoreCase("Low")) {
			client.verifyElementFound("NATIVE", "text=15 mins", 0);
			client.verifyElementFound("NATIVE", "text=30 mins", 0);
		} else {
			client.verifyElementFound("NATIVE", "text=1 hr", 0);
			client.elementSwipe("NATIVE",
					"xpath=//*[@accessibilityIdentifier='ReminderHourPicker']",
					0, "Down", 250, 2000);
			client.verifyElementFound("NATIVE", "text=2 hrs", 0);

			client.elementSwipe("NATIVE",
					"xpath=//*[@accessibilityIdentifier='ReminderHourPicker']",
					0, "Down", 250, 2000);
			client.verifyElementFound("NATIVE", "text=3 hrs", 0);

			client.elementSwipe("NATIVE",
					"xpath=//*[@accessibilityIdentifier='ReminderHourPicker']",
					0, "Down", 250, 2000);
			client.verifyElementFound("NATIVE", "text=4 hrs", 0);
		}
	}

	

	/**
	 * Author: LourdeNoelRini
	 * 
	 * select High Reminder Time
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param value
	 *            set time
	 */
	public void selectHighReminderTime(Client client, String value) {
		if (value.equals("1")) {
			client.elementSwipeWhileNotFound(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='ReminderHourPicker' and @class='UIPickerView']",
					"Down", 0, 2000, "NATIVE", "xpath=//*[@text='" + value
					+ " hr']", 0, 1000, 5, true);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value
					+ " hr' and @top='true']", 0);
		} else {
			client.elementSwipeWhileNotFound(
					"NATIVE",
					"xpath=//*[@accessibilityIdentifier='ReminderHourPicker' and @class='UIPickerView']",
					"Down", 0, 2000, "NATIVE", "xpath=//*[@text='" + value
					+ " hrs']", 0, 1000, 5, true);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value
					+ " hrs' and @top='true']", 0);
		}
	}

	

	/**
	 * Author: LourdeNoelRini
	 * 
	 * click CheckGlucose in Reminders
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 */
	public void clickCheckGlucoseinReminders(Client client) {
		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='Check Glucose']", 0, 1);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * verify NonActionable icon and verify pop up
	 * 
	 * @param client
	 *            Integrate SeeTestAutomation
	 * @param click
	 *            true to click the icon
	 */
	
	public void verifyandClickNonActionable(Client client, boolean click) {
		verifyPageTitles(client, "My Glucose");
		if (click) {
			client.click("NATIVE",
					"xpath=//*[@accessibilityIdentifier='NonActionable']", 0, 1);
			client.verifyElementFound("NATIVE", "text=${checkBloodGlucoseTitle}",
					0);
			client.verifyElementFound(
					"NATIVE",
					"text=${checkBloodGlucoseMessage}",
					0);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='OK']", 0);
		} else {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityIdentifier='NonActionable']", 0);
		}
	}


	
	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Scan new Sensor
	 * 
	 * @param client
	 *           Integrate SeeTestAutomation
	 */
	public void verifyScannewSensor(Client client) {
		closeDebugDrawer(client);
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo' and @onScreen='true']",
				0, 65000);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='NewSensorScan' and @onScreen='true']",
				0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Your Sensor is ready to be used.' and @onScreen='true']",
				0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Apply A New Sensor screen
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void verifyApplyANewSensor(Client client) {
		closeDebugDrawer(client);
		client.waitForElement("NATIVE",
				"xpath=//*[contains(@text,'Apply a new Sensor' and @onScreen='true']",
				0, 65000);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='NewSensorApply' and @onScreen='true']",
				0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='Apply a new Sensor. The Sensor should only be applied to the back of your upper arm.' and @onScreen='true']",
				0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='HOW TO APPLY A SENSOR' and @onScreen='true']",
				0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify to Last Scan value and Scan time
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param scanvalue
	 *            Scan value
	 * @param scantime
	 *            Scan time
	 */
	public void verifyLastScan(Client client, String scanvalue, String scantime) {
		client.waitForElement("NATIVE",
				"xpath=//*[@text='LAST SCAN' and @onScreen='true']", 0, 65000);

		if (scanvalue != null) {
			client.waitForElement("NATIVE", "xpath=//*[contains(@text,'" + scanvalue + "')]", 0, 20000);
			client.verifyElementFound("NATIVE","xpath=//*[contains(@text,'" + scanvalue + "')]", 0);
		}

		if (scantime != null) {
			client.waitForElement("NATIVE", "xpath=//*[contains(@text,'" + scantime + "')]", 0, 180000);
			client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'" + scantime + "')]", 0);
		}
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Average Glucose
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param value
	 *            Average value
	 */
	public void verifyAvgGlucose(Client client, String value) {
		client.waitForElement("NATIVE",
				"xpath=//*[@text='AVERAGE' and @onScreen='true']", 0, 10000);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value
				+ "' and @onScreen='true']", 0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Time in Target Glucose value in HomeScreen
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param value
	 *          verify  target value
	 */
	public void verifyTimeintargetinHome(Client client, String value) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo' and @onScreen='true']",
				0, 10000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='TIME IN TARGET' and @onScreen='true']", 0);

		client.verifyElementFound("NATIVE", "xpath=//*[@text='" + value
				+ "' and @onScreen='true']", 0);

	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * Verify Sensor Life
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 * @param timeLine
	 *            time can in days / hours / minutes
	 * @param value
	 *            number of days / hours / minutes
	 * 
	 */
	public void verifySensorLife(Client client, String timeLine, int value) {
		timeLine = timeLine.toUpperCase();
		closeDebugDrawer(client);
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityIdentifier='sensorLife' and @text='SENSOR ENDS IN: "
						+ value + " " + timeLine + "']", 0, 360000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='sensorLife' and @text='SENSOR ENDS IN: "
						+ value + " " + timeLine + "']", 0);
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * 
	 * Verify Sensor Ready Pop Up
	 * 
	 * @param client
	 *        Integrate SeeTestAutomation
	 *          
	 */
	public void sensorReadyPopUp(Client client) {
		if (client.isElementFound("NATIVE",
				"xpath=//*[@text='Sensor Ready' and @onScreen='true']", 0)) {
			client.verifyElementFound(
					"NATIVE",
					"xpath=//*[@text='Your Sensor is ready to be used' and @onScreen='true']",
					0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@text='OK' and @onScreen='true']", 0);
			client.click("NATIVE",
					"xpath=//*[@text='OK' and @onScreen='true']", 0, 1);
		}
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * 
	 * Verify Sensor Ending Soon Pop Up
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param value
	 *         set the value
	 */        
	public void sensorEndingSoonPopUp(Client client, String value) {
		if (client.isElementFound("NATIVE",
				"xpath=//*[@text='Replace Sensor in 1 " + value
				+ "' and @onScreen='true']", 0)) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@text='Replace Sensor in 1 " + value
					+ "' and @onScreen='true']", 0);
			client.verifyElementFound("NATIVE",
					"xpath=//*[@text='OK' and @onScreen='true']", 0);
			client.click("NATIVE",
					"xpath=//*[@text='OK' and @onScreen='true']", 0, 1);
		}
	}

	/**
	 * Author: LourdeNoelRini
	 * 
	 * 
	 * Verify Scan New Sensor Button
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void verifyScanNewSensorButton(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@text='SCAN NEW SENSOR' and @onScreen='true']", 0,
				60000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='SCAN NEW SENSOR' and @onScreen='true']", 0);

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Verify Sensor Expired Message
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void verifySensorExpiredMessage(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='YOUR SENSOR HAS ENDED' and @accessibilityIdentifier='sensorLife']", 0,
				60000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='YOUR SENSOR HAS ENDED' and @accessibilityIdentifier='sensorLife']", 0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * 
	 * Verify Glucose Graph
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 * @param status
	 *        if true verify the graph        
	 */
	public void verifyGlucoseGraph(Client client,boolean status) {
		if(status){
			client.waitForElement("NATIVE","xpath=//*[@class='LibreLink.LLLineChartView']", 0,120000);
			client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='LAST 24 HOURS']", 0);
		}else{	
			client.waitForElementToVanish("NATIVE", "xpath=//*[@class='LibreLink.LLLineChartView']", 0, 360000);
			if(!client.isElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='libreLinkNavItemLogo']", 0)){
				launch(client);
			}
		}

	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * 
	 * Verify Scan Instruction Message
	 * 
	 * @param client
	 *          Integrate SeeTestAutomation
	 */
	public void verifyScanInstructionMessage(Client client) {		
		client.waitForElement("NATIVE","xpath=//*[@accessibilityLabel='SCAN NEW SENSOR']", 0,60000);
		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='SCAN NEW SENSOR']", 0);
		client.verifyElementFound("NATIVE","xpath=//*[@accessibilityLabel='HOW TO SCAN A SENSOR']", 0);

	}
	
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify sensor Warm up completion and remaining time
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param timeRemaining
	 * 		verify warm time remaining
	 * @param readyTime
	 * 		verify warm completion time
	 * @since 1/1/2018
	 */
	
	public void verifySensorWarmupTime(Client client, String timeRemaining, String readyTime) {
		closeDebugDrawer(client);
				client.verifyElementFound("NATIVE",
						"xpath=//*[@text='Sensor ready at:' and @top='true']", 0);

				
				client.waitForElement(
							"NATIVE",
							"xpath=//*[@text='("+timeRemaining+" remaining)' and @class='UILabel' and @onScreen='true']",
							0, 240000);
				client.verifyElementFound(
							"NATIVE",
							"xpath=//*[@text='("+timeRemaining+" remaining)' and @class='UILabel' and @onScreen='true']",
							0);

				if (readyTime != null) {
					client.verifyElementFound("NATIVE",
							"xpath=//*[@text='"+readyTime+"' and @class='LibreLink.BoldLabel' and @onScreen='true']", 0);
				}
		}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify sensor Warm up remaining time when there is glucose data
	 * 
	 * @param client
	 *         Integrate SeeTestAutomation
	 * @param timeRemaining
	 * 		verify warm time remaining
	 * @since 1/1/2018
	 */
	
	public void verifySensorWarmupTimeWithData(Client client, String timeRemaining) {
		client.waitForElement(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='sensorLife' and @onScreen='true' and contains(@text,'"+timeRemaining+"')]",
				0, 240000);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='sensorLife' and @onScreen='true' and contains(@text,'Sensor can be used in')]",
				0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityIdentifier='sensorLife' and @onScreen='true' and contains(@text,'"+timeRemaining+"')]",
				0);

		}

	// End of Helper

}
