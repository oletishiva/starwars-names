package com.abbott.project37375iOS.homescreenAndscanning;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class HomeScreen_T001_Sensor_Status_WithoutData extends HomeScreenAndScanningHelper {

	@Test
	public void test_HomeScreen_T001_Sensor_Status_WithoutData() throws Exception {
		
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS852,SDAIUIRS1276
		 * @Expected Warmup completion time 13:00 and Sensor warmup remaining time 60 mins displayed on the home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step1);
		setTheDateAndTime(client,7,9,2017,"11:59");				
		selectingSASMode(client, "MOCK_1");
		editConfiguration(client,0,0,0,"1/14");
		verifySensorWarmupTime(client, "60 mins","13:00");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Warmup completion time 13:00 and Sensor warmup remaining time 30 mins displayed on the home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step2);
		setTheTimeAlone(client, "12:28");
		launch(client);
		verifySensorWarmupTime(client, "30 mins","13:00");
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Warmup completion time 1:00 pm and Sensor warmup remaining time 29 mins displayed on the home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step3);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWELVE_HOUR_FORMAT);
		launch(client);
		verifySensorWarmupTime(client, "29 mins","1:00 pm");
		capturescreenshot(client,getStepID(),true); 

		/**
		 *
		 * @stepId Step 4
		 * @Reqt SDAIUIRS852,SDAIUIRS859
		 * @Expected Warmup completion time 1:00 pm and Sensor warmup remaining time 29 mins displayed on the home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/		
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step4);
		if(client.isElementFound("NATIVE", "xpath=//*[contains(@accessibilityLabel,'29 mins remaining')]",0)){
			verifySensorWarmupTime(client, "29 mins","1:00 pm");
		}else{
			verifySensorWarmupTime(client, "28 mins","1:00 pm");
		}
		capturescreenshot(client,getStepID(),true); 

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS852
		 * @Expected Warmup completion time 13:00 and Sensor warmup remaining time 1 min displayed on the home screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step5);
		changePhoneHourTimeFormat(client, LibrelinkConstants.TWENTYFOUR_HOUR_FORMAT);
		setTheTimeAlone(client, "12:58");
		launch(client);
		verifySensorWarmupTime(client, "1 min",null);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS852,SDAIUIRS856
		 * @Expected Sensor life on the home screen displayed: 14 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step6);
		waitFor(client,60);
		sensorReadyPopUp(client);
		verifySensorLife(client,"days",14);
		capturescreenshot(client,getStepID(),true);
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS852,SDAIUIRS856,SDAIUIRS874
		 * @Expected Sensor life on the home screen displayed: 2 days
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step7);
		setTheDateAndTime(client,19,9,2017,"13:00");		
		verifySensorLife(client,"days",2);
		verifyScannewSensor(client);
		capturescreenshot(client,getStepID(),true);


		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS852,SDAIUIRS857
		 * @Expected Sensor life on the home screen displayed: 24 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step8);
		setTheDateAndTime(client,20,9,2017,"11:59");	
		sensorEndingSoonPopUp(client,"day");
		verifySensorLife(client,"hours",24);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS852,SDAIUIRS857
		 * @Expected Sensor life on the home screen displayed: 2 hours
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step9);
		setTheDateAndTime(client,21,9,2017,"10:58");		
		verifySensorLife(client,"hours",2);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step10
		 * @Reqt SDAIUIRS852,SDAIUIRS858
		 * @Expected Sensor life on the home screen displayed: 60 mins
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step10);
		waitFor(client,40);	
		verifySensorLife(client,"minutes",60);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS852,SDAIUIRS858,SDAIUIRS874
		 * @Expected Sensor life on the home screen displayed: 1min
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step11);
		setTheTimeAlone(client, "11:58");
		launch(client);
		verifySensorLife(client,"minute",1);
		verifyScannewSensor(client);
		capturescreenshot(client,getStepID(),true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS875
		 * @Expected Home screen displays scan new sensor button
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.HomeScreen_T001_Sensor_Status_WithoutData_Step12);		
		waitFor(client,60);		
		verifyApplyANewSensor(client);
		clickOnButtonOption(client, "NEXT", true);
		verifyScanNewSensorButton(client);
		capturescreenshot(client,getStepID(),true);
		
		selectingSASMode(client,"DEFAULT");
        currentSystemTime(client);
	}

}
