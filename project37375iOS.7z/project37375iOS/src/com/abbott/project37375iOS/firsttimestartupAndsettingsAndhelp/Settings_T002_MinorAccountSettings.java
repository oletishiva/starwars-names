package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class Settings_T002_MinorAccountSettings extends FirstSequenceAndSettingsHelper {

	@Test
	public void test_T002_MinorAccountSettings() throws Exception {

		setEmail();
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1238
		 * @Expected First Name,Last Name,Date of Birth are displayed on App's New Account registration page
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step1); 
		getStarted(client, true);
		clickOnButtonOption(client, "NEXT", true);
		clickAndAcceptPage(client, "Terms of Use");
		clickAndAcceptPage(client, "Privacy Notice");
		verifyCreateAccountScreen(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1238
		 * @Expected Date of birth is used to set up your LibreView account and
		 *           not to determine whether the App is appropriate for your
		 *           use.Please consult the App user's manual before using the
		 *           App' displayed ";
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step2);
		createMinorAccountDetails(client,"Mock","User");
		clickOnButtonOption(client, "NEXT", true);
		verifyMinorWarningMessage(client);
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAUISRS1238
		 * @Expected Parent/Guardian Account Login page is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step3);
		clickOnButtonOption(client, "OK", true);
		verifyParentGuardianAccountpage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAUISRS1238
		 * @Expected Unit of Measure screen is displayed without any account creation errors.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step4);
		minorLoginDetails(client,"Parentfirst","Parentlast",getEmail(),LibrelinkConstants.CURRENT_PASSWORD,LibrelinkConstants.CURRENT_PASSWORD,true);
		clickOnCreateAccount(client);
		verifyUOMPage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAUISRS1238
		 * @Expected HOME screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step5);
		defaultSettings(client,"grams");
		allowNotifications(client);
		verifyHomePageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS925, SDAIUIRS926
		 * @Expected The App Navigates to Account Settings screen and has an
		 *           option to modify the fields
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step6);
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client, "Account Settings");
		verifyMinorAccountSettings(client);
		capturescreenshot(client, getStepID(), true);
		
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS925, SDAIUIRS926
		 * @Expected Date of birth is used to set up your LibreView account and
		 *           not to determine whether the App is appropriate for your
		 *           use.Please consult the user's manual page of app before using the
		 *           App.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step7);
		client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Up", 0, 500);
		enterAgePickDOB(client, "3");
		sendValidPasswordAndSubmit(client,"Abbott@123");
		verifyMinorWarningMessage(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS925, SDAIUIRS926
		 * @Expected The App is accepting the changes and displayed the settings page.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step8);
		clickOnButtonOption(client, "OK", true);
		 verifyPageTitles(client, "Settings");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS925, SDAIUIRS926
		 * @Expected The following fields are editable First Name,Last
		 *           Name,Parent/Legal Guardian First Name,Parent/Legal Guardian
		 *           Last Name";
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step9);
		navigateToSubMenuScreens(client, "Account Settings");
		updateMinorAccountSettings(client);
		sendValidPasswordAndSubmit(client,"Abbott@123");
		clickOnButtonOption(client, "OK", true);
		verifyPageTitles(client, "Settings");	
		capturescreenshot(client, getStepID(), true);
		navigateToSubMenuScreens(client, "Account Settings");
		verifyUpdateMinorAccountSettings(client);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS926
		 * @Expected The App Navigates to Account Password Screen and has the
		 *           fields Current Password,New Password,Confirm
		 *           password.SUBMIT button is disabled
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step10);
		navigateToSubMenuScreens(client, "Account Password");
		verifyAccountPasswordPage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step11);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.NEW_PASSWORD,
				LibrelinkConstants.INVALID_PASSWORD);
		verifyPasswordMismatchError(client,"passwordMismatchErrorMessage");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step12);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.CHAR_PASSWORD,
				LibrelinkConstants.CHAR_PASSWORD);
		verifyAccountPasswordInCorrectErrors(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step13);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.NUMBER_PASSWORD,
				LibrelinkConstants.NUMBER_PASSWORD);
		verifyAccountPasswordInCorrectErrors(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step14);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.CAPS_PASSWORD,
				LibrelinkConstants.CAPS_PASSWORD);
		verifyAccountPasswordInCorrectErrors(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step15);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.LOWER_PASSWORD,
				LibrelinkConstants.LOWER_PASSWORD);
		verifyAccountPasswordInCorrectErrors(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step16);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.SEVEN_CHAR_PASSWORD,
				LibrelinkConstants.SEVEN_CHAR_PASSWORD);
		verifyAccountPasswordInCorrectErrors(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected Error message is displayed and App does not allow the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step17);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.THIRTYSEVEN_CHAR_PASSWORD,
				LibrelinkConstants.THIRTYSEVEN_CHAR_PASSWORD);
		verifyAccountPasswordInCorrectErrors(client);
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client, "OK", true);

		/**
		 * 
		 * @stepId Step 18
		 * @Reqt SDAIUIRS926, SDAIUIRS1255
		 * @Expected App does allows the user to change the password.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step18);
		changePassword(client, LibrelinkConstants.CURRENT_PASSWORD,
				LibrelinkConstants.THIRTYSIX_CHAR_PASSWORD,
				LibrelinkConstants.THIRTYSIX_CHAR_PASSWORD);
		verifyPageTitles(client, "Settings");
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 19
		 * @Reqt SDAIUISRS926
		 * @Expected The App allows the user to Log in.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step19);
		logOutUser(client);
		clickSignInButton(client,true);
		signInClick(client, getEmail(),LibrelinkConstants.THIRTYSIX_CHAR_PASSWORD, false);
		capturescreenshot(client, getStepID(), true);

		
		
		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUISRS926
		 * @Expected Selected Country with Unit of Measurement
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step20);
		submitSignIn(client);
		clickAndAcceptPage(client,"Terms of Use");
		clickAndAcceptPage(client,"Privacy Notice");
		verifyUOMPage(client);
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAIUISRS926,SDAUISRS1238
		 * @Expected HOME screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T002_MinorAccountSettings_Step21);
		defaultSettings(client,"grams");
		allowNotifications(client);
		verifyHomePageDetails(client);
		capturescreenshot(client, getStepID(), true);


	}
	

}
