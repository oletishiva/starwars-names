package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.abbott.project37375iOS.main.PreRequisite;

@RunWith(Suite.class)
@Suite.SuiteClasses({PreRequisite.class,FirstTimeStartup_T001_AppTourScreens_SignIn.class, FirstTimeStartup_T002_TermsOfUseandPrivacyNotice.class,FirstTimeStartup_T003_StartUpSettings_NewAdultAccount.class,
	FirstTimeStartup_T004_StartUpSettings_NewMinorAccount.class,Settings_T001_AppSettings.class,Settings_T002_MinorAccountSettings.class,
	Settings_T003_AdultAccountSettings.class,UIHelp_T001_Help_About_Content.class})
public class TestSuite {
  //nothing
}
