package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;

import org.junit.Assert;

import com.abbott.project37375iOS.main.BaseHelper;
import com.experitest.client.Client;

public class HelpHelper extends BaseHelper {


	/**
	 * Author: LourdeNoelRini 
	 * 
	 * Verify Application Version
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 */
	
	public void verifyApplicationVersion(Client client) {
		client.verifyElementFound("NATIVE", "accessibilityLabel=Software Version:", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UITableViewLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[@text='Software Version:']] ", 0);
		String appversion = client.elementGetText("NATIVE",
				"xpath=//*[@class='UITableViewLabel' and @knownSuperClass='UILabel' and ./preceding-sibling::*[@text='Software Version:']] ", 0);
		Assert.assertEquals(appversion,getAppversion());
	}
	
	
	/**
	 * Author: LourdeNoelRini 
	 * 
	 * Verify UDI information
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	
	public void verifyUDI(Client client) {
		
		if (getCountryCode().equals("United States")) {
			client.verifyElementFound("NATIVE", "xpath=//*[@text='UDI:' and @onScreen='true']", 0);
			client.verifyElementFound("NATIVE", "xpath=//*[@text='"+getAppudi()+"' and @onScreen='true']", 0);
							
		} else if (getCountryCode().equals("United Kingdom")) {
			client.verifyElementNotFound("NATIVE",  "xpath=//*[@text='UDI:' and @onScreen='true']", 0);
			
		}

	}
	
	/**
	 * Author: ShabinaSherif 
	 * 
	 * Verify CE and Website Information
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	
	public void verifyCEWebSite(Client client) {
		
		if (getCountryCode().equals("United States")) {
			client.runNativeAPICall("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "invokeMethod:'{\"selector\":\"pl_scrollToBottom:\",\"arguments\":[\"true\"]}'");
			client.verifyElementNotFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CELogo' and @hidden='false']", 0);
			client.runNativeAPICall("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "invokeMethod:'{\"selector\":\"pl_scrollToTop:\",\"arguments\":[\"true\"]}'");
					
		} else if (getCountryCode().equals("United Kingdom")) {
			client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Down", 100, 1000, "NATIVE", "xpath=//*[@accessibilityIdentifier='CELogo' and @onScreen='true']", 0, 1000, 2, false);
			client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityIdentifier='CELogo' and @onScreen='true']", 0);
			
		}
		    client.elementSwipeWhileNotFound("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", "Down", 100, 1000, "NATIVE", "xpath=//*[@text='https://www.abbott.com/patents' and @onScreen='true']", 0, 1000, 2, false);
	        client.verifyElementFound("NATIVE", "text=Patent Website:", 0);
	        client.verifyElementFound("NATIVE", "xpath=//*[@text='https://www.abbott.com/patents' and @onScreen='true']", 0);

	}
	

	/**
	 * Author: LourdeNoelRini 
	 * 
	 * verify user's manual Guide
	 *         
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	
	public void verifyUsersManualGuide(Client client) {	
		waitForProgress(client);
		client.waitForElementToVanish(
				"NATIVE",
				"xpath=//*[@text='${progressDownloadingUserGuide}' and @top='true']",
				0, 80000);
		waitFor(client,10);
		client.verifyElementFound("NATIVE", "xpath=//*[@accessibilityLabel='User’s Manual' and @class='UILabel']", 0);
		
	}
	

	/**
	 * Author: Amaresh
	 * 
	 * Verify How to Apply new sensor steps
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	
	public void verifyHowToApplyNewSensorSteps(Client client) {
		client.waitForElement("NATIVE", "text=STEP 1", 0, 1000);
		client.verifyElementFound("NATIVE", "text=STEP 1", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[contains(@text,'Select site on back of upper arm.')]",0);
		
		client.verifyElementFound("NATIVE", 
                "xpath=//*[contains(@text,'"+getLangPropValue("applySensorSubTextStep1")+"')]",0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 2", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Clean site with alcohol wipe. Allow site to dry before proceeding.']",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 3", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='Peel lid completely off Sensor Pack.']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 4", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='Unscrew cap from Sensor Applicator.']", 0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 5", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Line up dark mark on Sensor Applicator with dark mark on Sensor Pack. On a hard surface, press down firmly on Sensor Applicator until it comes to a stop.']",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 6", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Lift Sensor Applicator out of Sensor Pack.']",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 7", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Sensor Applicator is ready to apply Sensor. Do not touch inside Sensor Applicator or put it back into Sensor Pack.']",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 8", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Place Sensor Applicator over site and push down firmly to apply Sensor.']",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 9", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Gently pull Sensor Applicator away from your body.']",
				0);

		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 10", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Make sure Sensor is secure. Discard used Sensor Applicator and Sensor Pack according to local regulations.']",
				0);

	}
	
	
	
	/**
	 * Author: Amaresh
	 * 
	 * Verify  How to Scan a sensor Pages
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */
	
	public void verifyHowToScanSensorPages(Client client) {
		client.waitForElement("NATIVE", "text=STEP 1", 0, 10000);
		client.verifyElementFound("NATIVE", "text=STEP 1", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=Tap the scan button before scanning your Sensor.",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 2", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=Hold the top of your iPhone near the Sensor.",
				0);
		swipePage(client, "Right");
		client.verifyElementFound("NATIVE", "text=STEP 3", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@text='Your iPhone will vibrate and make a sound (if sounds are enabled) after scanning the Sensor.']",
				0);

	}
	

}
