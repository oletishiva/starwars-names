package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;


public class Settings_T001_AppSettings extends FirstSequenceAndSettingsHelper {

	@Test
	public void test_T001_AppSettings() throws Exception {
		String verifyTG = null;
	
		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1144,SDAIUIRS1253
		 * @Expected The App Navigates to Target Glucose Range screen and has an
		 *           option to set the Target Glucose Range.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step1);
		navigateToScreen(client, "Settings");
		navigateToSubMenuScreens(client, "Target Glucose Range");
		verifyPageTitles(client,"Target Glucose Range");
		capturescreenshot(client, getStepID(), true);

		
		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1144,SDAIUIRS1253,SDAISRS172
		 * @Expected The App Allows the user to set the Upper Value between
		 *           71-180 mg/dL or 4.0 -10.0 mmol/L
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step2);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHighGlucoseRange(client,70);
		}else{
			verifyHighGlucoseRange(client,3.9);
		}
		capturescreenshot(client, getStepID(), true);
		

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1144,SDAIUIRS1253,SDAISRS172
		 * @Expected The App is Allowed the user to set the Upper Value between (101-180 mg/dL or 5.7-10.0 mmol/L)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step3);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyHighGlucoseRange(client,100);
		}else{
			verifyHighGlucoseRange(client,5.6);
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1144,SDAIUIRS1253,SDAISRS172
		 * @Expected The App is allowed the user to set the Lower Value between (70 -179 mg/dL or 3.9 - 9.9 mmol/L)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step4);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLowGlucoseRange(client,180);
		}else{
			verifyLowGlucoseRange(client,10.0);
		}
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1144,SDAIUIRS1253,SDAISRS172
		 * @Expected 'The App is allowed the user to set the Lower Value as ( 70 mg/dL or 3.9 mmol/L)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step5);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLowGlucoseRange(client,71);
		}else{
			verifyLowGlucoseRange(client,4.0);
		}
		capturescreenshot(client, getStepID(), true);
	

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS1144,SDAIUIRS1253,SDAISRS172
		 * @Expected The App is Allowed the user to set the Lower Value  between ( 70 -139 mg/dL or 3.9 - 7.7 mmol/L)
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step6);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLowGlucoseRange(client,140);
		}else{
			verifyLowGlucoseRange(client,7.7);
		}
		capturescreenshot(client, getStepID(), true);
		clickOnBackIcon(client);
		
		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS1145
		 * @Expected The App Navigates to Carbohydrate Units screen and has an option to set the Carbohydrate Units as grams or servings
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step7);
		navigateToSubMenuScreens(client, "Carbohydrate Units");
		verifyCarbohydrateOptions(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS1145, SDAISRS830
		 * @Expected grams UOM is selected & serving size selection is disabled.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step8);
		selectCarbohydrateUnits(client,"grams");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS1145, SDAIUIRS1146, SDAISRS830 
		 * @Expected servings UOM is selected & the App allows the user to set 1 serving as 10 -15 grams, in 0.5 grams increments.  ( For UK build, it is 1 portions as 10-15 grams, in 0.5 grams increments).
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step9);
		selectCarbohydrateUnits(client,"servings");
		capturescreenshot(client, getStepID(), true);
		clickOnButtonOption(client,"SAVE", true);
		
		if(getTextToSpeech().equalsIgnoreCase("yes")){
		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS1245
		 * @Expected 'Text to Speech' feature is 'on' is displayed on App Settings screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step10);
		
		navigateToSubMenuScreens(client ,"Text to Speech");
		selectspeechOption(client, "on");
		clickOnButtonOption(client,"SAVE", true);
		verifySpeechSettings(client, "on");
		capturescreenshot(client, getStepID(), true);
		
		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS1246
		 * @Expected Text to Speech feature is 'off' is displayed on App Settings screen
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step11);
		navigateToSubMenuScreens(client ,"Text to Speech");
		selectspeechOption(client, "off");
		clickOnButtonOption(client,"SAVE", true);
		verifySpeechSettings(client, "off");
		capturescreenshot(client, getStepID(), true);

		}else{
			showNotApplicableScreenShot(client,"Step10 & 11_NotApplicable_For US Build_Text to Speech");
		}
		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS1144, SDAIUIRS1145,SDAIUIRS1246
		 * @Expected The App Settings screen is displayed the following parameters:Target Glucose Range with range 100-140 mg/dL ( or 5.6-7.8  mmol/L);Carbohydrate Units with UOM as servings.(  or Portion For UK Build );Text to Speech  Setting is set to 'off'.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step12);
		if (getUnits().equals("mg/dL")) {
			verifyandsetTGfromSettings(client, 100, 140);
			verifyTG= "100 - 140 mg/dL";
		} else if (getUnits().equals("mmol/L")) {
			verifyandsetTGfromSettings(client, 5.6, 7.8);
			verifyTG= "5.6 - 7.8 mmol/L";
		}
		verifySettingsPage(client, "off", "servings",15.0, verifyTG);
		capturescreenshot(client, getStepID(), true);
	
		
		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS1144, SDAIUIRS1145, SDAIUIRS1245,SDAIUIRS1246,SDAISRS172, SDAISRS830
		 * @Expected The App Settings screen is displayed the following parameters,Target Glucose Range with range 140-160 mg/dL ( or 7.8-8.9  mmol/L),Carbohydrate Units with UOM as grams,Text to Speech setting is set to 'on'
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.Settings_T001_AppSettings_Step13);
		if (getUnits().equals("mg/dL")) {
			verifyandsetTGfromSettings(client, 140, 160);
			verifyTG= "140 - 160 mg/dL";
		} else if (getUnits().equals("mmol/L")) {
			verifyandsetTGfromSettings(client, 7.8, 8.9);
			verifyTG= "7.8 - 8.9 mmol/L";
		}
		navigateToSubMenuScreens(client ,"Carbohydrate Units");
		selectCarbohydrateUnits(client,"grams");
		clickOnButtonOption(client,"SAVE", true);
		if(getTextToSpeech().equalsIgnoreCase("yes")){
		navigateToSubMenuScreens(client ,"Text to Speech");
		selectspeechOption(client, "on");
		clickOnButtonOption(client,"SAVE", true);
		}
		verifySettingsPage(client,"on", "grams",0, verifyTG);
		capturescreenshot(client, getStepID(), true);

	}
	


}
