package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class FirstTimeStartup_T001_AppTourScreens_SignIn extends
FirstSequenceAndSettingsHelper {


	@Test
	public void test_T001_AppTourScreens_SignIn() throws Exception {
		setEmail();

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS937_SDAIUIRS1237
		 * @Expected LibreLink welcome screen is displayed with Splash Screen App Tour 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step1);
		librelinkWelcomePage(client);
		verifyGetStartedNowandSignIn(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1237
		 * @Expected The text Check your glucose with your smartphone Statement gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step2);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 2);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS1237
		 * @Expected The text You can have quick access to your glucose information Statement gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step3);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 3);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS1237
		 * @Expected The text You can gain insights to help you make more informed decisions Statement gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step4);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 4);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS1237
		 * @Expected The text You can share your glucose information with your health care professional and loved ones Statement gets displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step5);
		swipeWelcomescreen(client);
		verifyAppTourScreens(client, 5);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS938
		 * @Expected Confirm Country page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step6);
		getStarted(client,true);
		verifyConfirmCountryPage(client);
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS938
		 * @Expected Terms of Use page gets displayed without check glucose icon.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step7);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Terms of Use");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS938
		 * @Expected Privacy Notice page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step8);
		clickOnButtonOption(client,"ACCEPT",true);
		clickOnButtonOption(client,"ACCEPT",true);
		verifyPageTitles(client,"Privacy Notice");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 9
		 * @Reqt SDAIUIRS938
		 * @Expected Create New Account page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step9);
		clickOnButtonOption(client,"ACCEPT",true);
		clickOnButtonOption(client,"ACCEPT",true);
		verifyPageTitles(client,"Create New Account");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 10
		 * @Reqt SDAIUIRS938
		 * @Expected Account Login Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step10);
		createNewAccountDetails(client,"Test","User","10","19","1970");
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Account Login");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 11
		 * @Reqt SDAIUIRS938
		 * @Expected Unit of Measurement Screen Page gets displayed without check glucose icon.
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step11);		
		adultLoginDetails(client,getEmail(),LibrelinkConstants.CURRENT_PASSWORD,LibrelinkConstants.CURRENT_PASSWORD,true);		
		clickOnCreateAccount(client);
		verifyPageTitles(client,"Unit of Measurement");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 12
		 * @Reqt SDAIUIRS938
		 * @Expected Target Glucose Range Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step12);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Target Glucose Range");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 13
		 * @Reqt SDAIUIRS938
		 * @Expected Carbohydrate Units Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step13);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Carbohydrate Units");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 14
		 * @Reqt SDAIUIRS938
		 * @Expected Welcome Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step14);
		selectCarbohydrateUnits(client,"grams");
		clickOnButtonOption(client,"DONE",true);
		verifyPageTitles(client,"Welcome!");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 15
		 * @Reqt SDAIUIRS938
		 * @Expected My Glucose Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step15);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"My Glucose");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 16
		 * @Reqt SDAIUIRS938
		 * @Expected Glucose Background Color Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step16);
		clickOnButtonOption(client,"NEXT",true);
		client.verifyElementFound("NATIVE", "text=${backgroundGlucoseColorsTitle}", 0);
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);


		/**
		 * 
		 * @stepId Step 17
		 * @Reqt SDAIUIRS938
		 * @Expected Glucose Trend Arrow gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step17);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Glucose Trend Arrow");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 18
			 * @Reqt SDAIUIRS938
			 * @Expected Treatment Decisions page 1 gets displayed without check glucose icon
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step18);
			clickOnButtonOption(client,"NEXT",true);
			verifyPageTitles(client,"Treatment Decisions");
			verifyCheckGlucoseIcon(client,false);
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 19
			 * @Reqt SDAIUIRS938
			 * @Expected Treatment Decisions page 2 gets displayed without check glucose icon
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step19);
			clickOnButtonOption(client,"NEXT",true);
			verifyPageTitles(client,"Treatment Decisions");
			verifyCheckGlucoseIcon(client,false);
			capturescreenshot(client, getStepID(), true);

		}else{
			showNotApplicableScreenShot(client,"Step18 & 19_Treatment Decisions Info screen_Not applicable for Non US build");
		}

		/**
		 * 
		 * @stepId Step 20
		 * @Reqt SDAIUIRS938
		 * @Expected LibreLink Home Page gets displayed with scan data and check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step20);
		clickOnButtonOption(client,"DONE",true);
		allowNotifications(client);
		verifyHomePageDetails(client);
		selectingSASMode(client, "MOCK_1");
		if(getCountryCode().contains("United States")){
			editConfiguration(client,-1,0,0,"12/11");
		}
		openDebugDrawer(client);
		bgValueWithStaticTime(client,"Realtime","100",false,0,0);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLastScanInHomePage(client,"100");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyLastScanInHomePage(client,"5.6");
		}
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 21
		 * @Reqt SDAIUIRS940
		 * @Expected Sign In Page gets displayed. Check Glucose button is not available
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step21);
		logOutUser(client);
		clickSignInButton(client,true);
		verifyCheckGlucoseIcon(client,false);
		verifyPageTitles(client,"Sign In");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 22
		 * @Reqt SDAIUIRS940
		 * @Expected Terms of Use Page gets displayed. Check Glucose button is not available
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step22);
		signInClick(client, getEmail(),LibrelinkConstants.CURRENT_PASSWORD, true);
		verifyPageTitles(client,"Terms of Use");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 23
		 * @Reqt SDAIUIRS937
		 * @Expected Privacy Notice Page gets displayed. Check Glucose button is not available
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step23);
		clickOnButtonOption(client,"ACCEPT",true);
		clickOnButtonOption(client,"ACCEPT",true);
		verifyPageTitles(client,"Privacy Notice");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 24
		 * @Reqt SDAIUIRS937
		 * @Expected Unit of Measurement Page gets displayed. Check Glucose button is not available
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step24);
		clickOnButtonOption(client,"ACCEPT",true);
		clickOnButtonOption(client,"ACCEPT",true);
		verifyPageTitles(client,"Unit of Measurement");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 25
		 * @Reqt SDAIUIRS937, SDAIUIRS938
		 * @Expected Target Glucose Range Page gets displayed without check glucose icon. 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step25);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Target Glucose Range");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 26
		 * @Reqt SDAIUIRS937
		 * @Expected Carbohydrate Units Page gets displayed . Check Glucose button is not available 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step26);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Carbohydrate Units");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 27
		 * @Reqt SDAIUIRS937 SDAIUIRS1292
		 * @Expected Welcome Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step27);
		selectCarbohydrateUnits(client,"grams");
		clickOnButtonOption(client,"DONE",true);
		verifyPageTitles(client,"Welcome!");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);
		if (getSafetyConfig().equalsIgnoreCase("yes")) {
		verifySafetyInfo(client);
		capturescreenshot(client, "Step27_1_SDAIUIRS1292_Safety Information link is displayed", true);
		clickOnBackIconWebView(client);
		
		}else{
			showNotApplicableScreenShot(client,"Step27_1_SDAIUIRS1292_Safety Information screen_Not applicable as per Configuration for that build");
		}

		/**
		 * 
		 * @stepId Step 28
		 * @Reqt SDAIUIRS937
		 * @Expected My Glucose Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step28);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"My Glucose");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 29
		 * @Reqt SDAIUIRS937
		 * @Expected Glucose Background Color Page gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step29);
		clickOnButtonOption(client,"NEXT",true);
		client.verifyElementFound("NATIVE", "text=${backgroundGlucoseColorsTitle}", 0);
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 30
		 * @Reqt SDAIUIRS937
		 * @Expected Glucose Trend Arrow gets displayed without check glucose icon
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step30);
		clickOnButtonOption(client,"NEXT",true);
		verifyPageTitles(client,"Glucose Trend Arrow");
		verifyCheckGlucoseIcon(client,false);
		capturescreenshot(client, getStepID(), true);

		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			/**
			 * 
			 * @stepId Step 31
			 * @Reqt SDAIUIRS937
			 * @Expected Treatment Decisions page 1 gets displayed without check glucose icon
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step31);
			clickOnButtonOption(client,"NEXT",true);
			verifyPageTitles(client,"Treatment Decisions");
			verifyCheckGlucoseIcon(client,false);
			capturescreenshot(client, getStepID(), true);

			/**
			 * 
			 * @stepId Step 32
			 * @Reqt SDAIUIRS937
			 * @Expected Treatment Decisions page 2 gets displayed without check glucose icon
			 * @Dependancy Script cannot proceed if this step fails
			 * 
			 **/
			setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step32);
			clickOnButtonOption(client,"NEXT",true);
			verifyPageTitles(client,"Treatment Decisions");
			verifyCheckGlucoseIcon(client,false);
			capturescreenshot(client, getStepID(), true);
		}else{
			showNotApplicableScreenShot(client,"Step31 & 32_Treatment Decisions Info screen_Not applicable for Non US build");
		}

		/**
		 * 
		 * @stepId Step 33
		 * @Reqt SDAIUIRS937, SDAIUIRS938
		 * @Expected Home Page gets displayed with scan data 
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T001_AppTourScreens_SignIn_Step33);
		clickOnButtonOption(client,"DONE",true);
		allowNotifications(client);
		verifyHomePageDetails(client);
		capturescreenshot(client, "Step33_1_SDAIUIRS937 SDAIUIRS938_Home Screen displays Apply a new sensor message", true);
		clickOnButtonOption(client,"NEXT",true);
		verifyHowToScanNewSensorLink(client, false);
		capturescreenshot(client, "Step33_2_SDAIUIRS937 SDAIUIRS938_Home Screen displays Scan new sensor button with no message", true);
		selectingSASMode(client, "MOCK_1");
		if(getCountryCode().contains("United States")){
			editConfiguration(client,-1,0,0,"12/11");
		}
		openDebugDrawer(client);
		bgValueWithStaticTime(client, "Realtime", "100", false, 0, 0);
		scanMockSensor(client,null);
		clickOnBackIcon(client);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLastScanInHomePage(client,"100");
		} else if (getUnits().equalsIgnoreCase("mmol/L")) {
			verifyLastScanInHomePage(client,"5.6");
		}
		capturescreenshot(client, getStepID().replace("Step33", "Step33_3"), true);


	}

}