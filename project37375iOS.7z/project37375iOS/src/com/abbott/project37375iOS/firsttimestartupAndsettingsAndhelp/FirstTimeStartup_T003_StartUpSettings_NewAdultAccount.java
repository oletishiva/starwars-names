package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;

import org.junit.Test;

import com.abbott.project37375iOS.main.LibrelinkConstants;

public class FirstTimeStartup_T003_StartUpSettings_NewAdultAccount extends
FirstSequenceAndSettingsHelper {

	@Test
	public void test_T003_StartUpSettings_Auto_NewAdultAccount()
			throws Exception {

		setEmail();

		/**
		 * 
		 * @stepId Step 1
		 * @Reqt SDAIUIRS1238_SDAIUIRS1239
		 * @Expected Create New Account screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step1);
		getStarted(client, true);
		verifyPageTitles(client, "Confirm Country");
		clickOnButtonOption(client, "NEXT", true);
		clickAndAcceptPage(client, "Terms of Use");
		clickAndAcceptPage(client, "Privacy Notice");
		verifyCreateAccountScreenisEditable(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 2
		 * @Reqt SDAIUIRS1238_SDAIUIRS1239
		 * @Expected adult Account Login screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step2);
		createNewAccountDetails(client, "Tester", "Adult", "5", "17", "1960");
		clickOnButtonOption(client, "NEXT", true);
		verifyAdultAccountLoginScreenisEditable(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 3
		 * @Reqt SDAIUIRS943
		 * @Expected Unit of Measurement screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step3);
		adultLoginDetails(client, getEmail(), LibrelinkConstants.CURRENT_PASSWORD, LibrelinkConstants.CURRENT_PASSWORD, true);
		clickOnCreateAccount(client);
		verifyUnitOfMeasurementPageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 4
		 * @Reqt SDAIUIRS943
		 * @Expected Target Glucose Range screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step4);
		clickOnButtonOption(client, "NEXT", true);
		verifyPageTitles(client, "Target Glucose Range");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 5
		 * @Reqt SDAIUIRS943
		 * @Expected Unit of Measurement screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step5);
		clickOnBackIcon(client);
		verifyPageTitles(client, "Unit of Measurement");
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 6
		 * @Reqt SDAIUIRS943
		 * @Expected Target Glucose Range screen is displayed with details
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step6);
		clickOnButtonOption(client, "NEXT", true);
		verifyTargetGlucoseRangePageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 7
		 * @Reqt SDAIUIRS943
		 * @Expected App doesn't allow us to set both low and high target glucose range as same
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step7);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyGlucoseRangeDifference(client,120);
		} else {
			verifyGlucoseRangeDifference(client,6.7);
		}		
		capturescreenshot(client, getStepID(), true);

		/**
		 * 
		 * @stepId Step 8
		 * @Reqt SDAIUIRS943
		 * @Expected App allows to choose Glucose Ranges Low between (70mg/dL to
		 *           179mg/dL and High between 71 mg/dL to 180 mg/dL( or Low
		 *           between 3.9mmol/L to 9.9mmol/L , High between 4.0mmol/L to
		 *           10.0mmol/L for mmol/L build
		 * @Dependancy Script cannot proceed if this step fails
		 * 
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step8);
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifyLowGlucoseRange(client,180);
			verifyHighGlucoseRange(client,70);
		} else {
			verifyLowGlucoseRange(client,10.0);
			verifyHighGlucoseRange(client,3.9);
		}

		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 9
		 * @Reqt SDAIUIRS943
		 * @Expected Carbohydrate Units screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step9);
		clickOnButtonOption(client, "NEXT", true);
		verifyPageTitles(client, "Carbohydrate Units");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 10
		 * @Reqt SDAIUIRS943
		 * @Expected App navigates back to Target Glucose Range screen
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step10);
		clickOnBackIcon(client);
		verifyPageTitles(client, "Target Glucose Range");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 11
		 * @Reqt SDAIUIRS943
		 * @Expected Carbohydrate Units screen is displayed with details
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step11);
		clickOnButtonOption(client, "NEXT", true);
		carbohydrateUnitsPageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 12
		 * @Reqt SDAIUIRS943
		 * @Expected Serving Bar allows the user to select the values from 10.0 grams to 15.0 grams
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step12);
		selectCarbohydrateUnits(client, "servings");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 13
		 * @Reqt SDAIUIRS943
		 * @Expected servings text and serving bar is disabled
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step13);
		selectCarbohydrateUnits(client, "grams");
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 14
		 * @Reqt SDAIUIRS1292
		 * @Expected Welcome Page with Safety Information is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step14);
		clickOnButtonOption(client, "DONE", true);
		verifyWelcomeScreen(client);
		capturescreenshot(client, getStepID(), true);
		
		if (getSafetyConfig().equalsIgnoreCase("yes")) {
		/**
		 *
		 * @stepId Step 14.1
		 * @Reqt SDAIUIRS1292
		 * @Expected Safety Information is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step14_1);
		verifySafetyInfo(client);
		capturescreenshot(client, getStepID(), true);
		clickOnBackIconWebView(client);
		
		}else{
			showNotApplicableScreenShot(client,"Step14_1_SDAIUIRS1292_Safety Information screen_Not applicable as per Configuration for that build");
		}
		
		/**
		 *
		 * @stepId Step 15
		 * @Reqt SDAIUIRS1217
		 * @Expected My Glucose Page is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step15);
		clickOnButtonOption(client, "NEXT", true);
		verifyMyGlucoseInfoPage(client, true);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 16
		 * @Reqt SDAIUIRS1293
		 * @Expected Glucose Background Color Page is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step16);
		clickOnButtonOption(client, "NEXT", true);
		verifyGlucoseBackgroundColor(client, true);
		capturescreenshot(client, getStepID(), true);


		/**
		 *
		 * @stepId Step 17
		 * @Reqt SDAIUIRS1247
		 * @Expected Glucose Trend Arrow screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step17);		
		clickOnButtonOption(client, "NEXT", true);
		verifyGlucoseTrendArrow(client,true);
		capturescreenshot(client, getStepID(), true);

		if (getNAIconConfig().equalsIgnoreCase("yes")) {
			/**
			 *
			 * @stepId Step 18
			 * @Reqt SDAIUIRS1294
			 * @Expected Treatment Decisions Page 1 is displayed
			 * @Dependancy Script cannot proceed if this step fails
			 *
			 **/
			setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step18);
			clickOnButtonOption(client, "NEXT", true);
			verifyTreatmentDecisionScreen1(client, true);
			capturescreenshot(client, getStepID(), true);

			/**
			 *
			 * @stepId Step 19
			 * @Reqt SDAIUIRS1295
			 * @Expected Treatment Decisions Page 2 is displayed
			 * @Dependancy Script cannot proceed if this step fails
			 *
			 **/
			setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step19);
			clickOnButtonOption(client, "NEXT", true);
			verifyTreatmentDecisionScreen2(client, true);
			capturescreenshot(client, getStepID(), true);

		}else{
			showNotApplicableScreenShot(client,"Step18 & 19_SDAIUIRS1294_SDAIUIRS1295 Treatment Decisions Info screen_Not applicable for Non US build");
		}

		/**
		 *
		 * @stepId Step 20
		 * @Reqt SDAIUIRS943
		 * @Expected LibreLink Home Screen is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step20);
		clickOnButtonOption(client, "DONE", true);
		allowNotifications(client);
		verifyHomePageDetails(client);
		capturescreenshot(client, getStepID(), true);

		/**
		 *
		 * @stepId Step 21
		 * @Reqt SDAIUIRS943
		 * @Expected LibreLink Home Page is displayed
		 * @Dependancy Script cannot proceed if this step fails
		 *
		 **/
		setStepID(LibrelinkConstants.FirstTimeStartup_T003_StartUpSettings_Auto_NewAdultAccount_Step21);
		navigateToScreen(client, "Settings");
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			verifySettingsPage(client, "off", "grams",0, "70 - 180 mg/dL");
		} else {
			verifySettingsPage(client, "off", "grams",0, "3.9 - 10.0 mmol/L");
		}
		capturescreenshot(client, getStepID(), true);


	}

}