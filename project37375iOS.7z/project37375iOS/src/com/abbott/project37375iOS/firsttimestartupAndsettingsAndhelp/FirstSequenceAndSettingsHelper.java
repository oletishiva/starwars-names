package com.abbott.project37375iOS.firsttimestartupAndsettingsAndhelp;

import org.junit.Assert;

import com.abbott.project37375iOS.main.BaseHelper;
import com.experitest.client.Client;

public class FirstSequenceAndSettingsHelper extends BaseHelper {

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Verify Account Setting Page
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 */

	public void verifyAccountSettings(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"text=Changing any of the information below will update your account.",
				0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=First Name", 0);
		client.click("NATIVE", "accessibilityLabel=First Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Last Name", 0);
		client.click("NATIVE", "accessibilityLabel=Last Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Date of Birth",
				0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='_UIDatePickerView' and @onScreen='true']", 0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);

		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Country of Residence", 0);
		client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);

		client.verifyElementFound("NATIVE", "accessibilityLabel=Email", 0);
		client.click("NATIVE", "accessibilityLabel=Email", 0, 1);
		Assert.assertEquals(false, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Password", 0);
		client.click("NATIVE", "accessibilityLabel=Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Verify if keyboard is opened or not
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 * 
	 * @return keyboard
	 * 		Keyboard opened true/false
	 */
	public boolean isKeyboardOpened(Client client) {
		boolean keyboard = client.isElementFound("NATIVE",
				"xpath=//*[@class='UIKeyboardAutomatic' and @onScreen='true']",
				0);
		if (keyboard == true) {
			client.closeKeyboard();
		} else {
			keyboard = false;
		}
		return keyboard;
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Verify the account password page
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */
	public void verifyAccountPasswordPage(Client client) {
		client.waitForElement("NATIVE", "accessibilityLabel=Account Password",
				0, 10000);
		client.verifyElementFound("NATIVE", "text=${changePasswordTopText}",0);		 
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Current Password", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=New Password",
				0);
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Confirm Password", 0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='SUBMIT']",
				0);
		client.verifyElementFound(
				"NATIVE",
				"xpath=//*[@accessibilityLabel='CANCEL']",
				0);

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * Change the current password
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param currentPassword
	 *            LibrelinkConstants.CURRENT_PASSWORD
	 *            
	 * @param newPassword
	 *            LibrelinkConstants.NEW_PASSWORD
	 *            
	 * @param confirmNewPassword
	 *            LibrelinkConstants.NEW_PASSWORD
	 *            
	 */

	public void changePassword(Client client, String currentPassword,
			String newPassword, String confirmNewPassword ) {
		enterValue(client,"Current Password",currentPassword);
		enterValue(client,"New Password",newPassword);
		enterValue(client,"Confirm Password",confirmNewPassword);
		client.closeKeyboard();
		clickOnButtonOption(client, "SUBMIT", true);
		waitForProgress(client);

	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * select speech option
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param switchStatus
	 *            set on/off
	 */

	public void selectspeechOption(Client client, String switchStatus) {
		client.verifyElementFound("NATIVE", "accessibilityLabel="+switchStatus, 0);
		client.click("NATIVE", "accessibilityLabel="+switchStatus, 0, 1);
		if(switchStatus.equals("on")){
		Assert.assertTrue("1".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='on']]",
						0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
		}else{
			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='on']]",
							0,
							"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
		}
	
	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify speech Settings in App settings page
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param switchStatus
	 *            set on/off
	 */

	public void verifySpeechSettings(Client client, String switchStatus) {
		client.verifyElementFound("NATIVE", "accessibilityLabel=Settings",
				0);
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Text to Speech", 0);

		client.verifyElementFound("NATIVE",
				"accessibilityLabel="+switchStatus, 0);

	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Minor To Adult Account Error
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 * 
	 */

	public void verifyMinorToAdultAcctError(Client client) {
		client.waitForElement("NATIVE",
				"xpath=//*[@class='UIView' and @onScreen='true']", 0, 1000);
		client.verifyElementFound("NATIVE", "text=${invalidProfileDOB}", 0);
		clickOnButtonOption(client, "OK", false);
	}



	/**
	 * Author: NagarajuKasarla
	 * 
	 * send Valid Password And Submit
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param password
	 * 			enter the password
	 * 
	 */

	public void sendValidPasswordAndSubmit(Client client,String password) {
		client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Down", 0, 500);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.elementSendText("NATIVE", "xpath=//*[@knownSuperClass='UITextField' and @placeholder='Password']", 0,
				password);
		client.closeKeyboard();
		waitFor(client,3);
		clickOnButtonOption(client, "SUBMIT", true);
		waitForProgress(client);
		waitFor(client,1);
	}



	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify UOM Page
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * 
	 */

	public void verifyUOMPage(Client client) {
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Unit of Measurement", 0);
		client.verifyElementFound("NATIVE", "text=" + getUnits(), 0);
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify App Setings
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param speech
	 *        verify speech option ON/OFF
	 *        
	 * @param carbohydrateUnit
	 *         verify carbohydrateUnit option mgdl/mmmol
	 *         
	 * @param targetglucoserange
	 * 			verify TargetGlucoseRange option 
	 * 
	 * @param gramValue
	 * 			verify gramvalue in the page
	 */

	public void verifySettingsPage(Client client, String speech,
			String carbohydrateUnit, double gramValue, String targetglucoserange) {
		client.waitForElement("NATIVE",
				"xpath=//*[@accessibilityLabel='Settings']", 0, 1000);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='APP SETTINGS']", 0);

		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Unit of Measurement']", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=" + getUnits(),
				0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Target Glucose Range']", 0);

		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='"+targetglucoserange+"' and @text='"+targetglucoserange+"']",0);

		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Carbohydrate Units']", 0);
		if (carbohydrateUnit.equalsIgnoreCase("grams")) {
			client.verifyElementFound("NATIVE","accessibilityLabel=grams",0);
		} else {
			String servingsvalue = getLangPropValue("servings");
			client.verifyElementFound("NATIVE","text="+servingsvalue+" (1 "+servingsvalue.substring(0, (servingsvalue.length()-1))+" = "+gramValue+" grams)",0);
		}     
		if(getTextToSpeech().equalsIgnoreCase("yes")){
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='Text to Speech']", 0);
		client.verifyElementFound("NATIVE", "accessibilityLabel=" + speech, 0);
		}

	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Account Password mismatch Errors
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param errorStringId
	 * 			enter error message 
	 * 
	 */

	public void verifyPasswordMismatchError(Client client, String errorStringId) {
		
		client.verifyElementFound(
				"NATIVE",
				"text=${"+errorStringId+"}",
				0);
	}
	
	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Account Password Errors
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyAccountPasswordInCorrectErrors(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"text=Please enter a valid password. Passwords must be 8–36 characters and contain at least 1 digit, 1 upper case letter, and 1 lower case letter.",
				0);
	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Parent/Guardian Account page
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyParentGuardianAccountpage(Client client) {
		client.waitForElement("NATIVE",
				"accessibilityLabel=Parent/Guardian Account Login", 0, 1000);
		client.verifyElementFound(
				"NATIVE",
				"accessibilityLabel=This user is a minor. A parent or guardian must complete the account to use this software.",
				0);
	}


	/**
	 * Author: NagarajuKasarla
	 * 
	 * Verify Minor Account Setting Page
	 * 
	 * @param client
	 *  		Integrate SeeTestAutomation
	 */

	public void verifyMinorAccountSettings(Client client) {
		client.verifyElementFound(
				"NATIVE",
				"accessibilityLabel=Changing any of the information below will update your account.",
				0);
		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Minor First Name", 0);
		client.click("NATIVE", "accessibilityLabel=Minor First Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Minor Last Name", 0);
		client.click("NATIVE", "accessibilityLabel=Minor Last Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Date of Birth",
				0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);

		client.verifyElementFound("NATIVE", "accessibilityLabel=Country of Residence", 0);
		client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);

		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Parent/Legal Guardian First Name", 0);
		client.click("NATIVE",
				"accessibilityLabel=Parent/Legal Guardian First Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE",
				"accessibilityLabel=Parent/Legal Guardian Last Name", 0);
		client.click("NATIVE",
				"accessibilityLabel=Parent/Legal Guardian Last Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Down", 0, 500);

		client.verifyElementFound("NATIVE", "accessibilityLabel=Email", 0);
		client.click("NATIVE", "accessibilityLabel=Email", 0, 1);
		Assert.assertEquals(false, isKeyboardOpened(client));

		client.elementSwipe("NATIVE", "xpath=//*[@class='UITableView' and @onScreen='true']", 0, "Down", 0, 500);

		client.verifyElementFound("NATIVE", "accessibilityLabel=Password", 0);
		client.click("NATIVE", "accessibilityLabel=Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));
		client.closeKeyboard();

	}

	/**
	 * Author: ShabinaSherif
	 * 
	 * Update Minor Account Settings
	 * 
	 * @param client
	 *  		Integrate SeeTestAutomation
	 */

	public void updateMinorAccountSettings(Client client) {
		enterValue(client,"Minor First Name","UpdatedFirstName");
		enterValue(client,"Minor Last Name","UpdatedLastName");
		enterValue(client,"Parent/Legal Guardian First Name","UpdatedParentFirstName");
		enterValue(client,"Parent/Legal Guardian Last Name","UpdatedParentLastName");
		
	}
	
	/**
	 * Author: ShabinaSherif
	 * 
	 * Verify updated Minor Account Settings 
	 * 
	 * @param client
	 *  		Integrate SeeTestAutomation
	 */

	public void verifyUpdateMinorAccountSettings(Client client) {
		client.verifyElementFound("NATIVE", "text=UpdatedFirstName", 0);
		client.verifyElementFound("NATIVE", "text=UpdatedLastName", 0);
		client.verifyElementFound("NATIVE", "text=UpdatedParentFirstName", 0);
		client.verifyElementFound("NATIVE", "text=UpdatedParentLastName", 0);
		
	}

	/**
	 * Author: Lourde Noel Rini 
	 * 
	 * Verify carbohydrate Units Page Contents
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void carbohydrateUnitsPageDetails(Client client) {
		verifyPageTitles(client, "Carbohydrate Units");
        client.verifyElementFound("NATIVE", "text=${carbohydrateUnitsTopText}", 0);
		verifyCarbohydrateOptions(client);

		Assert.assertTrue("0".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./following-sibling::*[@text='${servings}'] and ./parent::*[@class='UITableViewCellContentView']]",
						0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
		Assert.assertTrue("0".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='grams']]",
						0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

		verifyButtonStatus(client, "DONE", false);
		Assert.assertTrue("0".equals(client
				.runNativeAPICall("NATIVE", "xpath=//*[@text='DONE']", 0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
	}

	/**
	 * Author: NagarajuKasarla
	 * 
	 * verify Carbohydrate Options
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyCarbohydrateOptions(Client client) {
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@accessibilityLabel='grams']]", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@class='UIImageView' and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@accessibilityLabel='${servings}']]", 0); 
	}

	
	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify Country Page Details
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyCountryPageDetails(Client client) {
		client.waitForElement("NATIVE", "text=Confirm Country", 0, 2000);
		verifyPageTitles(client, "Confirm Country");
		client.verifyElementFound(
				"NATIVE",
				"text=Your country is used during app setup and to ensure your data is stored properly.",
				0);
		client.verifyElementFound("NATIVE",
				"text=Your country has been identified as", 0);
		client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);
		client.verifyElementFound("NATIVE",
				"text=${countryOfOriginExplanation}", 0);
		verifyButtonStatus(client, "NEXT", true);
	}
	

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify Unit Of Measurement Page details
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyUnitOfMeasurementPageDetails(Client client) {
		client.verifyElementFound("NATIVE", "text=Unit of Measurement", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=Your glucose unit of measurement is automatically set based on your country.",
				0);
		client.verifyElementFound("NATIVE", "text=Your country is", 0);
		client.verifyElementFound("NATIVE", "text=" + getCountryCode(), 0);
		client.verifyElementFound("NATIVE", "text=Your unit of measurement is",
				0);
		client.verifyElementFound("NATIVE", "text=" + getUnits(), 0);
		verifyButtonStatus(client, "NEXT", true);
	}


	/**
	 * Author: Lourde Noel Rini / Shabina
	 * 
	 * Verify Target Glucose Range Page details
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 */

	public void verifyTargetGlucoseRangePageDetails(Client client) {
		client.verifyElementFound("NATIVE", "text=Target Glucose Range", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=Your target glucose range will be displayed on various graphs, and can be changed by going to Settings. Check with your health care professional if you do not know it.",
				0);
		client.verifyElementFound("NATIVE", "text=" + getUnits(), 0);

		if (getUnits().equalsIgnoreCase("mg/dL")) {
			Assert.assertEquals(100, findTargetGlucose(client, 0),0);
			Assert.assertEquals(140, findTargetGlucose(client, 1),0);
		}
		else if (getUnits().equalsIgnoreCase("mmol/L")) {
			Assert.assertEquals(5.6, findTargetGlucose(client, 0),0);
			Assert.assertEquals(7.8, findTargetGlucose(client, 1),0);
		}
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='NEXT']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='BackArrow']", 0);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify Check glucose sensor icon is displayed or not
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param available
	 *         true/false
	 */

	public void verifyCheckGlucoseIcon(Client client, boolean available) {

		if (available) {
			client.verifyElementFound("NATIVE",
					"xpath=//*[@accessibilityLabel='SensorIcon' and @onScreen='true']", 0);
		} else {
			client.verifyElementNotFound("NATIVE",
					"xpath=//*[@accessibilityLabel='SensorIcon' and @onScreen='true']", 0);
		}
	}


	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify Terms of Use \ Privacy Policy page Pop up
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param page
	 *            Terms of Use or Privacy Policy
	 *            
	 */

	public void verifyPagePopUp(Client client, String page) {
		client.waitForElement("NATIVE",
                "xpath=//*[@accessibilityLabel='ACCEPT' and @onScreen='true']",
                0, 2000);

		client.click("NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @onScreen='true']",
				0, 1);
		waitFor(client,1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@text='I have read and explicitly accept the "
						+ page + ".' and @onScreen='true']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='CANCEL' and @enabled='true' and @onScreen='true']", 0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityLabel='ACCEPT' and @enabled='true' and @onScreen='true']", 0);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify create account Page contents are editable
	 * 
	 * @param client
	 * 		Integrate SeeTestAutomation
	 */

	public void verifyCreateAccountScreenisEditable(Client client) {
		waitFor(client,1);
		client.verifyElementFound("NATIVE", "text=Create New Account", 0);
		client.verifyElementFound("NATIVE",
				"text=${sensorUserPrompt}", 0);        
		client.verifyElementFound("NATIVE", "accessibilityLabel=First Name", 0);
		client.click("NATIVE", "accessibilityLabel=First Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Last Name", 0);
		client.click("NATIVE", "accessibilityLabel=Last Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Date of Birth",
				0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@class='_UIDatePickerView' and @onScreen='true']", 0);
		client.click("NATIVE", "accessibilityLabel=Date of Birth", 0, 1);

		verifyButtonStatus(client, "NEXT", false);
	}

	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Verify Adult account Login Page is editable
	 * 
	 * @param client
	 *			Integrate SeeTestAutomation
	 */

	public void verifyAdultAccountLoginScreenisEditable(Client client) {
		client.waitForElement("NATIVE", "text=Account Login", 0, 5000);
		client.verifyElementFound(
				"NATIVE",
				"text=Create your LibreView account for use with FreeStyle LibreLink and any other compatible apps.",
				0);


		client.verifyElementFound("NATIVE", "accessibilityLabel=Email", 0);
		client.click("NATIVE", "accessibilityLabel=Email", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Password", 0);
		client.click("NATIVE", "accessibilityLabel=Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Confirm Password", 0);
		client.click("NATIVE", "accessibilityLabel=Confirm Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound(
				"NATIVE",
				"text=${changePasswordTopText}",
				0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']", 0);
		client.verifyElementFound(
				"NATIVE",
				"accessibilityLabel=Please send me information about Abbott Diabetes Care and other Abbott products and services. (You can unsubscribe at any time.)",
				0);
		client.verifyElementFound("NATIVE", "text=CREATE ACCOUNT", 0);
	}

	/**
	 * Author: Lourde Noel Rini
	 *
	 * Verify Parent Account Login Screen is Editable
	 *
	 * @param client
	 *		Integrate SeeTestAutomation
	 */

	public void verifyParentAccountLoginScreenisEditable(Client client) {
		client.waitForElement("NATIVE", "text=Parent/Guardian Account Login",
				0, 5000);
		client.verifyElementFound(
				"NATIVE",
				"text=This user is a minor. A parent or guardian must complete the account to use this software.",
				0);

		client.verifyElementFound("NATIVE", "accessibilityLabel=Parent/Legal Guardian First Name", 0);
		client.click("NATIVE", "accessibilityLabel=Parent/Legal Guardian First Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Parent/Legal Guardian Last Name", 0);
		client.click("NATIVE", "accessibilityLabel=Parent/Legal Guardian Last Name", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Email", 0);
		client.click("NATIVE", "accessibilityLabel=Email", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Password", 0);
		client.click("NATIVE", "accessibilityLabel=Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));

		client.verifyElementFound("NATIVE", "accessibilityLabel=Confirm Password", 0);
		client.click("NATIVE", "accessibilityLabel=Confirm Password", 0, 1);
		Assert.assertEquals(true, isKeyboardOpened(client));


		client.verifyElementFound(
				"NATIVE",
				"text=${changePasswordTopText}",
				0);
		client.verifyElementFound("NATIVE",
				"xpath=//*[@accessibilityIdentifier='CheckboxUnchecked']", 0);
		client.verifyElementFound(
				"NATIVE",
				"text=Please send me information about Abbott Diabetes Care and other Abbott products and services. (You can unsubscribe at any time.)",
				0);
		client.verifyElementFound("NATIVE", "text=CREATE ACCOUNT", 0);
	}

	/**
	 * Author: Amaresh/Shabina
	 *
	 * Verify Minor Warning Message
	 *
	 * @param client
	 *			Integrate SeeTestAutomation
	 */

	public void verifyMinorWarningMessage(Client client) {
		client.verifyElementFound("NATIVE", "text=${tooYoungWarningMessage}", 0);
		client.verifyElementFound("NATIVE", "text=CANCEL", 0);
		client.verifyElementFound("NATIVE", "xpath=//*[@text='OK']", 0);
	}


	/**
	 * Author: Lourde Noel Rini / Shabina
	 * 
	 * Verify Low Glucose Range
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param highTGValue
	 * 			high target glucose range
	 * 
	 */

	public void verifyLowGlucoseRange(Client client, double highTGValue) {
		double lowPointLowTGValue =0;
		double highPointLowTGValue =0;
		double beyondLowPointHighTGValue =0;
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			lowPointLowTGValue = 70;
			highPointLowTGValue=highTGValue-1;
			beyondLowPointHighTGValue = 69;
		}else{
			lowPointLowTGValue = 3.9;
			highPointLowTGValue=((highTGValue*10)-1)/10;
			beyondLowPointHighTGValue = 3.8;
		}
		swipeTargetGlucose(client, findTGIndex(highTGValue,1), 1);
		swipeTargetGlucose(client, findTGIndex(highPointLowTGValue,0), 0);
		Assert.assertEquals(highPointLowTGValue, findTargetGlucose(client, 0),0.0);
		swipeTargetGlucose(client, 0, 0);
		Assert.assertEquals(lowPointLowTGValue, findTargetGlucose(client, 0),0.0);
		client.verifyElementNotFound("NATIVE",
				"xpath=//*[@accessibilityLabel='"+beyondLowPointHighTGValue+"']", 0);
	}

	/**
	 * Author: Lourde Noel Rini / Shabina
	 * 
	 * Verify High Glucose Range
	 * 
	 * @param client
	 *    Integrate SeeTestAutomation
	 * @param lowTGValue
	 * 			low target glucose range
	 * 
	 */

	public void verifyHighGlucoseRange(Client client, double lowTGValue) {
		double lowPointHighTGValue =0;
		double highPointHighTGValue =0;
		double beyondhighPointHighTGValue =0;
		if (getUnits().equalsIgnoreCase("mg/dL")) {
			lowPointHighTGValue = lowTGValue +1;
			highPointHighTGValue=180;
			beyondhighPointHighTGValue = 181;
		}else{
			lowPointHighTGValue = ((lowTGValue*10)+1)/10;
			highPointHighTGValue=10.0;
			beyondhighPointHighTGValue = 10.1;
		}
		swipeTargetGlucose(client, findTGIndex(lowTGValue,0), 0);
		swipeTargetGlucose(client, findTGIndex(lowPointHighTGValue,1), 1);
		Assert.assertEquals(lowPointHighTGValue, findTargetGlucose(client, 1),0.0);
		swipeTargetGlucose(client, findTGIndex(highPointHighTGValue,1), 1);
		Assert.assertEquals(highPointHighTGValue, findTargetGlucose(client, 1),0.0);
		client.verifyElementNotFound("NATIVE",
				"xpath=//*[@accessibilityLabel='"+beyondhighPointHighTGValue+"']", 0);

	}


	/**
	 * Author: Lourde Noel Rini / Shabina
	 * 
	 * Verify Start and end Glucose Range Difference
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param setHigh
	 *            set the highest unit
	 * 
	 */

	public void verifyGlucoseRangeDifference(Client client, double setHigh) {

		if (getUnits().equalsIgnoreCase("mg/dL")) {

			int highindexvalue = (int) (setHigh - 71);

			swipeTargetGlucose(client, highindexvalue, 1);                                
			int setlowVal = highindexvalue + 1;                                         
			swipeTargetGlucose(client, setlowVal, 0);

		} else {

			int highindexvalue = (int) (setHigh * 10);
			int sethighindexvalue = highindexvalue - 40;

			swipeTargetGlucose(client, sethighindexvalue, 1);
			int setlowVal = sethighindexvalue + 1;
			swipeTargetGlucose(client, setlowVal, 0);
		}

		double low = findTargetGlucose(client, 0);                                          
		double high = findTargetGlucose(client, 1);
		Assert.assertNotEquals(low, high);
		Assert.assertEquals(findTGIndex(high,1),findTGIndex(low,0));
		
	}


	
	/**
	 * Author: Lourde Noel Rini
	 * 
	 * Select Grams/servings in carbohydrate Units Page
	 * 
	 * @param client
	 * 			Integrate SeeTestAutomation
	 * @param units
	 *            Select either Grams/Servings
	 *          
	 */

	public void selectCarbohydrateUnits(Client client, String units) {

		client.click("NATIVE", "text=${" + units + "}", 0, 1);
		Assert.assertTrue("1".equals(client
				.runNativeAPICall(
						"NATIVE",
						"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='${"
								+ units + "}']]", 0,
						"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

		if (units.equalsIgnoreCase("Grams")) {
			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='UIImageView' and @height>0 and ./following-sibling::*[@text='${servings}'] and ./parent::*[@class='UITableViewCellContentView']]",
							0,
							"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));

			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='LibreLink.ServingSizeTableCell']",
							0,
							"invokeMethod:'{\"selector\":\"isUserInteractionEnabled\",\"arguments\":[]}'")));

		} else {

			Assert.assertTrue("1".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='LibreLink.ServingSizeTableCell']",
							0,
							"invokeMethod:'{\"selector\":\"isUserInteractionEnabled\",\"arguments\":[]}'")));

			Assert.assertTrue("0".equals(client
					.runNativeAPICall(
							"NATIVE",
							"xpath=//*[@class='UIImageView' and @height>0 and ./parent::*[@class='UITableViewCellContentView'] and ./following-sibling::*[@text='grams']]",
							0,
							"invokeMethod:'{\"selector\":\"isHighlighted\",\"arguments\":[]}'")));
			
			setServingsValue(client, 10.0);
			setServingsValue(client, 12.5);
			setServingsValue(client, 15.0);
		
			
		}
	}
	

}

